#include "mytcpthread.h"

MyTcpThread::MyTcpThread(QObject *parent) : QThread(parent)
{

}

void MyTcpThread::setSocketDescriptor(qintptr descriptor)
{
    socketDescriptor = descriptor;
}

void MyTcpThread::setDataThread(RecvDataHandleThread *thread)
{
    dataThread = thread;
}

void MyTcpThread::run()
{
    if(getDataHandleWorker()){
        qDebug("getDataHandleWorker success - %p",dataWorker);
        socketManager = new SocketManager(socketDescriptor);
        connect(socketManager,SIGNAL(recvDataSignal(QByteArray,QTcpSocket*)),dataWorker,SLOT(recvDataSlot(QByteArray,QTcpSocket*)));
        connect(dataWorker,SIGNAL(msgHandledSignal(QByteArray,QTcpSocket*)),socketManager,SLOT(writeDataSlot(QByteArray,QTcpSocket*)));
    }
    exec();
}

bool MyTcpThread::getDataHandleWorker()
{
    while (true) {
        dataWorker = dataThread->getWorker();
        if(dataWorker){
            return true;
        }
        msleep(100);
    }
}
