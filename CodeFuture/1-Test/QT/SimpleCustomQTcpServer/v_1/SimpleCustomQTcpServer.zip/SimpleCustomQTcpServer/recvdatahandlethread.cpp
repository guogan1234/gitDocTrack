#include "recvdatahandlethread.h"
#include <QDebug>

RecvDataHandleThread::RecvDataHandleThread(QObject *parent) : QThread(parent)
{
    init();
}

RecvDataHandleWorker *RecvDataHandleThread::getWorker()
{
    if(bRun){
        return worker;
    }else {
        return NULL;
    }
}

void RecvDataHandleThread::run()
{
    qDebug("RecvDataHandleThread::run");
    worker = new RecvDataHandleWorker();
    bRun = true;
    qDebug("worker - %p",worker);
    exec();
    qDebug("---RecvDataHandleThread::run exit---");
}

void RecvDataHandleThread::init()
{
    initParam();
}

void RecvDataHandleThread::initParam()
{
    bRun = false;
}
