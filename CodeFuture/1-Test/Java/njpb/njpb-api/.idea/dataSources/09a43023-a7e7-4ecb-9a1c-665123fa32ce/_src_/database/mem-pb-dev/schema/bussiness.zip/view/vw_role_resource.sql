CREATE VIEW vw_role_resource AS
SELECT res.id,
    res.resource_code,
    res.resource_name,
    r.id AS role_id,
    res.create_time,
    res.create_by,
    res.remove_time
   FROM ((bussiness.sys_resource res
     JOIN bussiness.sys_role_resource srr ON (((srr.remove_time IS NULL) AND (srr.resource_id = res.id))))
     JOIN bussiness.sys_role r ON (((r.remove_time IS NULL) AND (r.id = srr.role_id))))