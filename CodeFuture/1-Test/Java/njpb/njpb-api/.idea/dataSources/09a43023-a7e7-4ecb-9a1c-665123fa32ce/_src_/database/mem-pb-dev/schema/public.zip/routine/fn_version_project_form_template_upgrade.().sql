CREATE FUNCTION fn_version_project_form_template_upgrade () RETURNS trigger
	LANGUAGE plpgsql
AS $$

BEGIN

  -- obj_form_template
  INSERT INTO public.sys_version_project(project_id, version_type_id, create_by) 
    SELECT aftp.project_id, 100::integer, NEW.last_update_by 
      FROM forms.asso_form_template_project aftp WHERE aftp.template_id = NEW.id AND aftp.is_delete IS NULL;

  RETURN NEW;

END;


$$
