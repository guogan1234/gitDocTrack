CREATE VIEW vw_auth_resource AS
SELECT DISTINCT res.id,
    res.resource_code,
    res.resource_type AS resource_type_id,
    usr.id AS user_id,
    usr.user_account,
    res.create_time,
    res.create_by,
    res.remove_time
   FROM ((((bussiness.sys_resource res
     JOIN bussiness.sys_role_resource srr ON (((srr.remove_time IS NULL) AND (srr.resource_id = res.id))))
     JOIN bussiness.sys_role r ON (((r.remove_time IS NULL) AND (r.id = srr.role_id))))
     JOIN bussiness.sys_user_role sur ON (((sur.remove_time IS NULL) AND (sur.role_id = r.id))))
     JOIN bussiness.sys_user usr ON (((usr.remove_time IS NULL) AND (usr.id = sur.user_id))))