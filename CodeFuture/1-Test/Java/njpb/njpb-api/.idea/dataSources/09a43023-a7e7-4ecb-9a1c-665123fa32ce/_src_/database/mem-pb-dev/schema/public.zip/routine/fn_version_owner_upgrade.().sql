CREATE FUNCTION fn_version_owner_upgrade () RETURNS trigger
	LANGUAGE plpgsql
AS $$

BEGIN


  --NEW.last_update_time = now(); -- table column last_update_time
  INSERT into public.sys_version_owner(owner_id,create_by) values (1, NEW.last_update_by);

  RETURN NEW;



END;


$$
