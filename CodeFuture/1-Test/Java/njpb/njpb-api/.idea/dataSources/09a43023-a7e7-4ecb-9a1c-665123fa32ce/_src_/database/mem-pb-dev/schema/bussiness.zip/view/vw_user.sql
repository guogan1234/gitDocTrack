CREATE VIEW vw_user AS
SELECT t.role_ids,
    u.id,
    u.user_account,
    u.user_name,
    u.user_password,
    u.user_surname,
    u.user_status,
    u.user_type,
    u.corp_id,
    u.user_phone,
    u.whitelist,
    u.user_group,
    u.create_time,
    u.create_by,
    u.last_update_time,
    u.last_update_by,
    u.remove_time,
    u.user_email,
    u.user_qq,
    u.user_wechart
   FROM (bussiness.sys_user u
     LEFT JOIN ( SELECT sur.user_id AS asso_user_id,
            array_to_string(array_agg(sur.role_id), ','::text) AS role_ids
           FROM (bussiness.sys_user_role sur
             LEFT JOIN bussiness.sys_role sr ON (((sr.remove_time IS NULL) AND (sr.id = sur.role_id))))
          WHERE ((sr.remove_time IS NULL) AND (sur.remove_time IS NULL))
          GROUP BY sur.user_id) t ON ((t.asso_user_id = u.id)))