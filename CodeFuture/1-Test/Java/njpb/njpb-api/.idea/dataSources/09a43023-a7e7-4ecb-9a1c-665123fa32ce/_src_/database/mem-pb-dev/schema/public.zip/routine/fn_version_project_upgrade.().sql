CREATE FUNCTION fn_version_project_upgrade () RETURNS trigger
	LANGUAGE plpgsql
AS $$

BEGIN

  --obj_estate, asso_form_template_project
  INSERT into public.sys_version_project(project_id, version_type_id, create_by) values (NEW.project_id, 100, NEW.last_update_by);

  RETURN NEW;

END;


$$
