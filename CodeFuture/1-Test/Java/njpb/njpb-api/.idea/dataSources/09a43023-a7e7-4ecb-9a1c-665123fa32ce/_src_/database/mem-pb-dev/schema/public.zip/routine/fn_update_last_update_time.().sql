CREATE FUNCTION fn_update_last_update_time () RETURNS trigger
	LANGUAGE plpgsql
AS $$


BEGIN
  NEW.last_update_time = now(); -- table column last_update_time
  RETURN NEW;
END;

$$
