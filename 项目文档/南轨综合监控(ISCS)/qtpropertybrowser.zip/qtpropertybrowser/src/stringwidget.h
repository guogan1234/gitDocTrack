#ifndef STRINGWIDGET
#define STRINGWIDGET
#include <QDialog>
#include <QString>
#include <QLabel>
#include <QToolButton>
#include <QLineEdit>
#include <QHBoxLayout>
#include <QPushButton>
class StringDialog : public QDialog
{
    Q_OBJECT
public:
    explicit StringDialog(QWidget *parent = 0):QDialog(parent),top_edit(new QLineEdit(this)),botton_edit(new QLineEdit(this)),
     enter_button(new QPushButton("Enter",this)),dialog_layout(new QVBoxLayout(this))
    {
        dialog_layout->addWidget(top_edit);
        dialog_layout->addWidget(botton_edit);
        dialog_layout->addWidget(enter_button);
        dialog_layout->setMargin(0);
        dialog_layout->setSpacing(0);
        connect(enter_button,SIGNAL(clicked(bool)),this,SLOT(on_enter_button()));
        connect(enter_button,SIGNAL(clicked(bool)),this,SIGNAL(click_enter_button()));
    }
    ~StringDialog(){};
    QString getString()
    {
        QString once_string = temp_string;
        temp_string.clear();
        return once_string;
    };
    void clear()
    {
        top_edit->clear();
        botton_edit->clear();
        temp_string.clear();
    }
signals:
    void click_enter_button();
private slots:
    void on_enter_button()
    {
        temp_string.clear();
        temp_string = top_edit->text();
        temp_string.append(botton_edit->text());
        this->hide();
    }

private:
    QLineEdit *top_edit;
    QLineEdit *botton_edit;
    QVBoxLayout *dialog_layout;
    QString temp_string;
    QPushButton *enter_button;
};

class StringWidget : public QWidget
{
    Q_OBJECT
public:
    explicit StringWidget(QWidget *parent = 0):QWidget(parent),tag_label(new QLabel("字符串：",this)),
        string_edit(new QLineEdit(this)),open_dialog_button(new QToolButton(this)),widget_layout(new QHBoxLayout(this)),
        string_dialog(new StringDialog(this))
    {
        string_edit->setReadOnly(true);
        open_dialog_button->setText("Open");
        widget_layout->addWidget(tag_label);
        widget_layout->addWidget(string_edit);
        widget_layout->addWidget(open_dialog_button);
        widget_layout->setSpacing(0);
        widget_layout->setMargin(0);
        connect(open_dialog_button,SIGNAL(clicked(bool)),this,SLOT(click_tool_button()));
        connect(string_edit,SIGNAL(textChanged(QString)),this,SIGNAL(textChanged(QString)));
        connect(string_dialog,SIGNAL(click_enter_button()),this,SLOT(get_string()));
        string_dialog->hide();
    }
    ~StringWidget(){};

    bool setReadOnly(bool ok)
    {
        tag_label->setEnabled(!ok);
        string_edit->setReadOnly(ok);
        open_dialog_button->setEnabled(!ok);
        return true;
    }
    QString text()
    {
        return string_edit->text();
    }

    int setText(const QString text)
    {
        string_edit->setText(text);
        return 0;
    }
    const QValidator *validator()
    {
        return string_edit->validator();
    }
    void setValidator(const QValidator * val)
    {
        string_edit->setValidator(val);
    }
signals:
    void textChanged(QString);
private slots:
    int click_tool_button()
    {
        string_dialog->clear();
        string_dialog->show();
    }
    int get_string()
    {
        QString temp = string_dialog->getString();
        if(temp.isEmpty())
            return -1;
        string_edit->setText(temp);
    }
private:
    QLabel *tag_label;
    QLineEdit *string_edit;
    QToolButton *open_dialog_button;
    QHBoxLayout *widget_layout;
    StringDialog *string_dialog;
};
#endif // STRINGWIDGET

