#ifndef FILEOPEN
#define FILEOPEN
#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QToolButton>
#include <QHBoxLayout>
#include <QString>
#include <QFileDialog>

class FileOpen : public QWidget
{
    Q_OBJECT
public:
    explicit FileOpen (QWidget *parent = 0):QWidget(parent),tag_label(new QLabel("路径：",this)),path_edit(new QLineEdit(this)),
        open_dialog_button(new QToolButton(this)),widget_layout(new QHBoxLayout(this))
    {
        open_dialog_button->setText("...");
        widget_layout->addWidget(tag_label,0);
        widget_layout->addWidget(path_edit,1);
        widget_layout->addWidget(open_dialog_button,0);
        this->setLayout(widget_layout);
        widget_layout->setSpacing(0);
        widget_layout->setMargin(0);
        connect(open_dialog_button,SIGNAL(clicked(bool)),this,SLOT(click_tool_button()));
        connect(path_edit,SIGNAL(textChanged(QString)),this,SIGNAL(textChanged(QString)));
    }
    ~FileOpen ()
    {

    }
    bool setReadOnly(bool ok)
    {
        tag_label->setEnabled(!ok);
        path_edit->setReadOnly(ok);
        open_dialog_button->setEnabled(!ok);
        return true;
    }
    QString text()
    {
        return path_edit->text();
    }

    int setText(const QString text)
    {
        path_edit->setText(text);
        return 0;
    }
    const QValidator *validator()
    {
        return path_edit->validator();
    }
    void setValidator(const QValidator * val)
    {
        path_edit->setValidator(val);
    }
signals:
    void textChanged(const QString &);
private slots:
    void click_tool_button()
    {
        path_edit->setText(QFileDialog::getOpenFileName());
    }
private:
    QLabel *tag_label;
    QLineEdit *path_edit;
    QToolButton *open_dialog_button;
    QHBoxLayout *widget_layout;
};
#endif // FILEOPEN

