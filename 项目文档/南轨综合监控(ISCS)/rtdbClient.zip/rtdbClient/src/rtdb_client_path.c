/*
 @Copyright Reserved by XXXX.
 Path definition and operations. Path is a string with colons and dots as delimiters.
 Colons are nodes separators, and dots are separators of node and attribute, and separator
 of attribute and attribute. Examples:
    "tableName"
    "tableName.fieldName"
    "domain_label"
    "domain_label.field"
    "domain_label.tableName.field"
    ...
    "domain_label:station_label:pro_system_label:device_label:ai_label"
    "domain_label:station_label:pro_system_label:device_label:ai_label.field"
    "domain_label:station_label:pro_system_label:device_label:ai_label.tableName.field"

 Create by KanWenDi, 2018.04.02.
 Histories:

 */
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "rtdb_client_path.h"

struct rtdb_client_path
{
    int8_t nodeNum;
    char **nodes;
    int8_t fieldNum;
    char **fields;
};

rtdb_client_path* rtdb_client_path_create()
{
    rtdb_client_path *path = malloc(sizeof(*path));
    if (path)
    {
        memset(path, 0, sizeof(*path));
    }
    return path;
}

static void rtdb_client_path_release_strings(char **strings, int8_t size)
{
    if (strings)
    {
        for(int8_t i = 0; i < size; i++)
        {
            if (strings[i])
            {
                free(strings[i]);
            }
        }
        free(strings);
    }
}

void rtdb_client_path_release(rtdb_client_path *path)
{
    if (path)
    {
        rtdb_client_path_release_strings(path->nodes, path->nodeNum);
        rtdb_client_path_release_strings(path->fields, path->fieldNum);
        free(path);
    }
}

int8_t rtdb_client_path_get_nodesize(const rtdb_client_path *path)
{
    return (path ? path->nodeNum : 0);
}

int8_t rtdb_client_path_get_fieldsize(const rtdb_client_path *path)
{
    return (path ? path->fieldNum : 0);
}

static const char* crtdb_client_path_get_key(char **keys, int8_t keyNum, int8_t index)
{
    if (!keys || keyNum == 0 || index < 0 || index >= keyNum)
    {
        return NULL;
    }
    return keys[index];
}

const char* crtdb_client_path_get_node(const rtdb_client_path *path, int8_t index)
{
    return crtdb_client_path_get_key(path ? path->nodes : NULL, path->nodeNum, index);
}

const char* rtdb_client_path_get_field(const rtdb_client_path *path, int8_t index)
{
    return crtdb_client_path_get_key(path ? path->fields : NULL, path->fieldNum, index);
}

static rtdb_client_code rtdb_client_path_add_key(char ***keys, int8_t *keyNum, char *key)
{
    char **tmp = realloc(*keys, sizeof(char*)*(*keyNum+1));
    if (!tmp)
    {
        return RTDB_CLIENT_OOM;
    }

    tmp[*keyNum] = key;
    *keys = tmp;
    *keyNum += 1;

    return RTDB_CLIENT_OK;
}

rtdb_client_code rtdb_client_path_add_node(rtdb_client_path *path, char *node)
{
    if (path && node)
    {
        return rtdb_client_path_add_key(&path->nodes, &path->nodeNum, node);
    }
    return RTDB_CLIENT_NIL;
}

rtdb_client_code rtdb_client_path_add_field(rtdb_client_path *path, char *field)
{
    if (path && field)
    {
        return rtdb_client_path_add_key(&path->fields, &path->fieldNum, field);
    }
    return RTDB_CLIENT_NIL;
}

rtdb_client_path* rtdb_client_path_parse(const char *spath)
{
    char *key;
    int i, start, end, flag, keyLen, psLen;
    rtdb_client_path *path;
    rtdb_client_code ec;

    psLen = spath ? strlen(spath) : 0;
    if (!psLen)
    {
        return NULL;
    }

    path = rtdb_client_path_create();
    if (!path)
    {
        return NULL;
    }

    flag = 0;
    i = start = end = 0;
    while (spath[i])
    {
        switch (spath[i])
        {
        case ':':
            end = i - 1;
            i++;
            if (end < start)
            {
                if (path)
                {
                    rtdb_client_path_release(path);
                }
                return NULL;
            }
            else
            {
                keyLen = end - start + 1;
                key = malloc(keyLen+1);
                if (!key)
                {
                    if (path)
                    {
                        rtdb_client_path_release(path);
                    }
                    return NULL;
                }

                memcpy(key, spath+start, keyLen);
                key[keyLen] = '\0';
                start = i;
                ec = rtdb_client_path_add_node(path, key);
                if (ec != RTDB_CLIENT_OK)
                {
                    free(key);
                    rtdb_client_path_release(path);
                    return NULL;
                }
            }

            break;
        case '.':
            end = i -1;
            i++;

            if (end < start)
            {
                if (path)
                {
                    rtdb_client_path_release(path);
                }
                return NULL;
            }
            else
            {
                keyLen = end - start + 1;
                key = malloc(keyLen+1);
                if (!key)
                {
                    if (path)
                    {
                        rtdb_client_path_release(path);
                    }
                    return NULL;
                }

                memcpy(key, spath+start, keyLen);
                key[keyLen] = '\0';
                start = i;
                if (flag)
                {
                    ec = rtdb_client_path_add_field(path, key);
                }
                else
                {
                    ec = rtdb_client_path_add_node(path, key);
                }
                if (ec != RTDB_CLIENT_OK)
                {
                    free(key);
                    rtdb_client_path_release(path);
                    return NULL;
                }
            }

            flag = 1;
            break;
        default:
            i++;
        }
    }

    if (end < start)
    {
        if (path)
        {
            rtdb_client_path_release(path);
        }
        return NULL;
    }
    else
    {
        keyLen = end - start + 1;
        key = malloc(keyLen+1);
        if (!key)
        {
            if (path)
            {
                rtdb_client_path_release(path);
            }
            return NULL;
        }

        memcpy(key, spath+start, keyLen);
        key[keyLen] = '\0';
        start = i;
        if (flag)
        {
            ec = rtdb_client_path_add_field(path, key);
        }
        else
        {
            ec = rtdb_client_path_add_node(path, key);
        }
        if (ec != RTDB_CLIENT_OK)
        {
            free(key);
            rtdb_client_path_release(path);
            return NULL;
        }
    }

    return path;
}
