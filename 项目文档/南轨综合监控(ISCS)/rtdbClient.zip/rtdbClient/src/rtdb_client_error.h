/*
 @Copyright Reserved by XXXX.
 RTDB client error definition.
 Create by KanWenDi, 2018.04.03.
 Histories:

 */
#ifndef RTDB_CLIENT_ERROR_H
#define RTDB_CLIENT_ERROR_H
#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    RTDB_CLIENT_ERR = -1,
    RTDB_CLIENT_OK = 0,
    RTDB_CLIENT_NIL = 1,
    RTDB_CLIENT_OOM = 2
} rtdb_client_code;

#ifdef __cplusplus
}
#endif
#endif
