/*
 @Copyright Reserved by XXXX.
 RTDB client.
 Create by KanWenDi, 2018.04.03.
 Histories:

 */
#ifndef RTDB_CLIENT_H
#define RTDB_CLIENT_H
#ifdef __cplusplus
extern "C" {
#endif

#include "rtdb_client_error.h"
#include "rtdb_client_variant.h"
#include "cmn_list.h"

typedef struct rtdb_client rtdb_client;

rtdb_client* rtdb_client_create();
void rtdb_client_release(rtdb_client *cli);

rtdb_client_code rtdb_client_add_server(const char *ip, int port, const char *user, const char *pswd);

void rtdb_client_remove_server(const char *ip);
void rtdb_client_remove_subpubserver(const char *ip);
rtdb_client_variant* rtdb_client_query_field(const char *path);
cmn_list* rtdb_client_query_node_fields(const char *path, const cmn_list *fields);
cmn_list* rtdb_client_query_node(const char *path);
cmn_list* rtdb_client_query_nodes(const cmn_list *paths);
int rtdb_client_set_field(const char *path, rtdb_client_variant *v);
//int rtdb_client_command();

cmn_list* rtdb_client_query_table_field(const char *tableName, const char *fieldName);
cmn_list* rtdb_client_query_table_fields(const char *tableName, const cmn_list *fields);
cmn_list* rtdb_client_query_table(const char *tableName, const char *queryString);
cmn_list* rtdb_client_filter_query_table(const char *tableName,const cmn_list *filters, const char *queryString);

#ifdef __cplusplus
}
#endif
#endif
