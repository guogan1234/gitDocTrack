/*
 @Copyright Reserved by XXXX.
 RTDB client network operations(TCP socket).
 Create by KanWenDi, 2018.04.03.
 Histories:

 */
#include "rtdb_client_net.h"

struct rtdb_client_net
{
    int fd;
};
