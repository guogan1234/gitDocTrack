/*
 @Copyright Reserved by XXXX.
 RTDB client network operations(TCP socket).
 Create by KanWenDi, 2018.04.03.
 Histories:

 */
#ifndef RTDB_CLIENT_NET_H
#define RTDB_CLIENT_NET_H
#ifdef __cplusplus
extern "C" {
#endif

typedef struct rtdb_client_net rtdb_client_net;


#ifdef __cplusplus
}
#endif
#endif
