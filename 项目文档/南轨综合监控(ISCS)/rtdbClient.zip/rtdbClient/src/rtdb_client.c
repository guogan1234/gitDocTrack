/*
 @Copyright Reserved by XXXX.
 RTDB client.
 Create by KanWenDi, 2018.04.03.
 Histories:

 */
#include <stdlib.h>
#include "rtdb_client.h"
#include "rtdb_client_net.h"

/**
 * type -- 0 port is available, 1 spport is available, 2 port and spport are available.
 * port -- RTDB service query port.
 * spport -- RTDB service subscribe-publish port.
 * ip -- RTDB service host address.
 * user -- RTDB user name.
 * pswd -- RTDB user password.
 */
struct rtdb_server
{
    int8_t type;
    int port;
    int spport;
    char *ip;
    char *user;
    char *pswd;
    rtdb_client_net *network;
};

struct rtdb_client
{
    // list *servers;
};

rtdb_client* rtdb_client_create()
{
    return NULL;
}

void rtdb_client_release(rtdb_client *cli)
{

}

rtdb_client_code rtdb_client_add_server(const char *ip, int port, const char *user, const char *pswd)
{
    return RTDB_CLIENT_OK;
}

void rtdb_client_remove_server(const char *ip)
{

}

void rtdb_client_remove_subpubserver(const char *ip)
{

}

rtdb_client_variant* rtdb_client_query_field(const char *path)
{
    return NULL;
}

cmn_list* rtdb_client_query_node_fields(const char *path, const cmn_list *fields)
{
    return NULL;
}

cmn_list* rtdb_client_query_node(const char *path)
{
    return NULL;
}

cmn_list* rtdb_client_query_nodes(const cmn_list *paths)
{
    return NULL;
}

int rtdb_client_set_field(const char *path, rtdb_client_variant *v)
{
    return 0;
}

cmn_list* rtdb_client_query_table_field(const char *tableName, const char *fieldName)
{
    return NULL;
}

cmn_list* rtdb_client_query_table_fields(const char *tableName, const cmn_list *fields)
{
    return NULL;
}

cmn_list* rtdb_client_query_table(const char *tableName, const char *queryString)
{
    return NULL;
}

cmn_list* rtdb_client_filter_query_table(const char *tableName,const cmn_list *filters, const char *queryString)
{
    return NULL;
}
