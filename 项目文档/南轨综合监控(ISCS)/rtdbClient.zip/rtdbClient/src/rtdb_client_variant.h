/*
 @Copyright Reserved by XXXX.
 variant definition and operations.
 Create by KanWenDi, 2018.04.02.
 Histories:

 */
#ifndef RTDB_CLIENT_VARIANT_H
#define RTDB_CLIENT_VARIANT_H
#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#define RTDB_CLIENT_VARIANT_UNDEF    0
#define RTDB_CLIENT_VARIANT_BOOL     1
#define RTDB_CLIENT_VARIANT_INT8     2
#define RTDB_CLIENT_VARIANT_INT16    3
#define RTDB_CLIENT_VARIANT_INT32    4
#define RTDB_CLIENT_VARIANT_INT64    5
#define RTDB_CLIENT_VARIANT_FLOAT    6
#define RTDB_CLIENT_VARIANT_DOUBLE   7
#define RTDB_CLIENT_VARIANT_STRING   8

typedef struct rtdb_client_variant rtdb_client_variant;

rtdb_client_variant* rtdb_client_variant_create();
rtdb_client_variant* rtdb_client_variant_create_bool(int8_t val);
rtdb_client_variant* rtdb_client_variant_int8(int8_t val);
rtdb_client_variant* rtdb_client_variant_int16(int16_t val);
rtdb_client_variant* rtdb_client_variant_int32(int32_t val);
rtdb_client_variant* rtdb_client_variant_int64(int64_t val);
rtdb_client_variant* rtdb_client_variant_float(float val);
rtdb_client_variant* rtdb_client_variant_double(double val);
rtdb_client_variant* rtdb_client_variant_string(const char *val);
void rtdb_client_variant_release(rtdb_client_variant *vt);

int8_t rtdb_client_variant_get_type(const rtdb_client_variant *vt);
int8_t rtdb_client_variant_get_bool(const rtdb_client_variant *vt);
int8_t rtdb_client_variant_get_int8(const rtdb_client_variant *vt);
int16_t rtdb_client_variant_get_int16(const rtdb_client_variant *vt);
int32_t rtdb_client_variant_get_int32(const rtdb_client_variant *vt);
int64_t rtdb_client_variant_get_int64(const rtdb_client_variant *vt);
float rtdb_client_variant_get_float(const rtdb_client_variant *vt);
double rtdb_client_variant_get_double(const rtdb_client_variant *vt);
const char* rtdb_client_variant_get_string(const rtdb_client_variant *vt);
void rtdb_client_variant_set_type(rtdb_client_variant *vt, int8_t type);
void rtdb_client_variant_set_bool(rtdb_client_variant *vt, int8_t val);
void rtdb_client_variant_set_int8(rtdb_client_variant *vt, int8_t val);
void rtdb_client_variant_set_int16(rtdb_client_variant *vt, int16_t val);
void rtdb_client_variant_set_int32(rtdb_client_variant *vt, int32_t val);
void rtdb_client_variant_set_int64(rtdb_client_variant *vt, int64_t val);
void rtdb_client_variant_set_float(rtdb_client_variant *vt, float val);
void rtdb_client_variant_set_double(rtdb_client_variant *vt, double val);
void rtdb_client_variant_set_string(rtdb_client_variant *vt, const char *val);

#ifdef __cplusplus
}
#endif
#endif
