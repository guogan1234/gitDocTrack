/*
 @Copyright Reserved by XXXX.
 variant definition and operations.
 Create by KanWenDi, 2018.03.20.
 Histories:

 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "rtdb_client_variant.h"

struct rtdb_client_variant
{
    int8_t type;
    union
    {
        int8_t i8;
        int16_t i16;
        int32_t i32;
        int64_t i64;
        float flt;
        double dbl;
        char *str;
    } v;
};

rtdb_client_variant* rtdb_client_variant_create()
{
    rtdb_client_variant *vt = malloc(sizeof(*vt));
    if (vt)
    {
        memset(vt, 0, sizeof(*vt));
    }

    return vt;
}

rtdb_client_variant* rtdb_client_variant_create_bool(int8_t val)
{
    rtdb_client_variant *vt = rtdb_client_variant_create();
    if (vt)
    {
        vt->type =RTDB_CLIENT_VARIANT_BOOL;
        vt->v.i8 = 0x01 & val;
    }

    return vt;
}

rtdb_client_variant* rtdb_client_variant_int8(int8_t val)
{
    rtdb_client_variant *vt = rtdb_client_variant_create();
    if (vt)
    {
        vt->type =RTDB_CLIENT_VARIANT_INT8;
        vt->v.i8 = val;
    }

    return vt;
}

rtdb_client_variant* rtdb_client_variant_int16(int16_t val)
{
    rtdb_client_variant *vt = rtdb_client_variant_create();
    if (vt)
    {
        vt->type =RTDB_CLIENT_VARIANT_INT16;
        vt->v.i16 = val;
    }

    return vt;
}

rtdb_client_variant* rtdb_client_variant_int32(int32_t val)
{
    rtdb_client_variant *vt = rtdb_client_variant_create();
    if (vt)
    {
        vt->type =RTDB_CLIENT_VARIANT_INT32;
        vt->v.i32 = val;
    }

    return vt;
}

rtdb_client_variant* rtdb_client_variant_int64(int64_t val)
{
    rtdb_client_variant *vt = rtdb_client_variant_create();
    if (vt)
    {
        vt->type =RTDB_CLIENT_VARIANT_INT64;
        vt->v.i64 = val;
    }

    return vt;
}

rtdb_client_variant* rtdb_client_variant_float(float val)
{
    rtdb_client_variant *vt = rtdb_client_variant_create();
    if (vt)
    {
        vt->type =RTDB_CLIENT_VARIANT_FLOAT;
        vt->v.flt = val;
    }

    return vt;
}

rtdb_client_variant* rtdb_client_variant_double(double val)
{
    rtdb_client_variant *vt = rtdb_client_variant_create();
    if (vt)
    {
        vt->type =RTDB_CLIENT_VARIANT_DOUBLE;
        vt->v.dbl = val;
    }

    return vt;
}

rtdb_client_variant* rtdb_client_variant_string(const char *val)
{
    rtdb_client_variant *vt = rtdb_client_variant_create();
    if (vt)
    {
        vt->type =RTDB_CLIENT_VARIANT_STRING;
        vt->v.str = val ? strdup(val) : NULL;
    }

    return vt;
}

void rtdb_client_variant_release(rtdb_client_variant *vt)
{
    if (vt)
    {
        if (vt->type == RTDB_CLIENT_VARIANT_STRING && vt->v.str)
        {
            free(vt->v.str);
        }
        free(vt);
    }
}

int8_t rtdb_client_variant_get_type(const rtdb_client_variant *vt)
{
    return (vt ? vt->type : RTDB_CLIENT_VARIANT_UNDEF);
}

int8_t rtdb_client_variant_get_bool(const rtdb_client_variant *vt)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_BOOL)
    {
        return vt->v.i8;
    }
    else
    {
        return 0;
    }
}

int8_t rtdb_client_variant_get_int8(const rtdb_client_variant *vt)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_INT8)
    {
        return vt->v.i8;
    }
    else
    {
        return 0;
    }
}

int16_t rtdb_client_variant_get_int16(const rtdb_client_variant *vt)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_INT16)
    {
        return vt->v.i16;
    }
    else
    {
        return 0;
    }
}

int32_t rtdb_client_variant_get_int32(const rtdb_client_variant *vt)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_INT32)
    {
        return vt->v.i32;
    }
    else
    {
        return 0;
    }
}

int64_t rtdb_client_variant_get_int64(const rtdb_client_variant *vt)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_INT64)
    {
        return vt->v.i64;
    }
    else
    {
        return 0;
    }
}

float rtdb_client_variant_get_float(const rtdb_client_variant *vt)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_FLOAT)
    {
        return vt->v.flt;
    }
    else
    {
        return 0.0;
    }
}

double rtdb_client_variant_get_double(const rtdb_client_variant *vt)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_DOUBLE)
    {
        return vt->v.flt;
    }
    else
    {
        return 0.0;
    }
}

const char* rtdb_client_variant_get_string(const rtdb_client_variant *vt)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_STRING)
    {
        return vt->v.str;
    }
    else
    {
        return NULL;
    }
}

void rtdb_client_variant_set_type(rtdb_client_variant *vt, int8_t type)
{
    if (vt)
    {
        vt->type = type;
    }
}

void rtdb_client_variant_set_bool(rtdb_client_variant *vt, int8_t val)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_BOOL)
    {
        vt->v.i8 = val;
    }
}

void rtdb_client_variant_set_int8(rtdb_client_variant *vt, int8_t val)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_INT8)
    {
        vt->v.i8 = val;
    }
}

void rtdb_client_variant_set_int16(rtdb_client_variant *vt, int16_t val)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_INT16)
    {
        vt->v.i16 = val;
    }
}

void rtdb_client_variant_set_int32(rtdb_client_variant *vt, int32_t val)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_INT32)
    {
        vt->v.i32 = val;
    }
}

void rtdb_client_variant_set_int64(rtdb_client_variant *vt, int64_t val)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_INT64)
    {
        vt->v.i64 = val;
    }
}

void rtdb_client_variant_set_float(rtdb_client_variant *vt, float val)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_FLOAT)
    {
        vt->v.flt = val;
    }
}

void rtdb_client_variant_set_double(rtdb_client_variant *vt, double val)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_DOUBLE)
    {
        vt->v.dbl = val;
    }
}

void rtdb_client_variant_set_string(rtdb_client_variant *vt, const char *val)
{
    if (vt && vt->type == RTDB_CLIENT_VARIANT_STRING)
    {
        if (vt->v.str)
        {
            free(vt->v.str);
        }
        vt->v.str = val ? strdup(val) : NULL;
    }
}
