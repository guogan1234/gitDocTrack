/*
 @Copyright Reserved by XXXX.
 Double link list.
 Create by KanWenDi, 2018.04.03.
 Histories:

 */
#include <stdlib.h>
#include <string.h>
#include "cmn_list.h"

struct cmn_list_node
{
    struct cmn_list_node *prev;
    struct cmn_list_node *next;
    void *value;
};

struct cmn_list_iterator
{
    struct cmn_list_node *next;
    int direction;
};

struct cmn_list_type
{
    void*(*dup)(void *val);
    void(*free)(void *val);
    int(*match)(void *val, void *key);
};

struct cmn_list
{
    struct cmn_list_node *head;
    struct cmn_list_node *tail;
    struct cmn_list_type *type;
    long length;
};

cmn_list* cmn_list_create(cmn_list_type *type)
{
    return NULL;
}

void cmn_list_release(cmn_list *l)
{

}

cmn_list* cmn_list_add_head(cmn_list *l, void *value)
{
    return NULL;
}

cmn_list* cmn_list_add_tail(cmn_list *l, void *value)
{
    return NULL;
}

cmn_list* cmn_list_add(cmn_list *l, cmn_list_node *ln, void *value, int after)
{
    return NULL;
}

void cmn_list_remove(cmn_list *l, cmn_list_node *ln)
{

}

cmn_list_iterator* cmn_list_get_iterator(cmn_list *l, int direction)
{
    return NULL;
}

void cmn_list_release_iterator(cmn_list_iterator *iter)
{

}

cmn_list_node* cmn_list_next(cmn_list_iterator *iter)
{
    return NULL;
}

cmn_list_node* cmn_list_find(cmn_list *l, void *key)
{
    return NULL;
}

cmn_list_node* cmn_list_get_at(cmn_list *l, long index)
{
    return NULL;
}

long cmn_list_get_size(cmn_list *l)
{
    return l->length;
}

cmn_list_node* cmn_list_get_frist(cmn_list *l)
{
    return l->head;
}

cmn_list_node* cmn_list_get_last(cmn_list *l)
{
    return l->tail;
}

void* cmn_list_node_get_previous(cmn_list_node *ln)
{
    return ln->prev;
}

void* cmn_list_node_get_next(cmn_list_node *ln)
{
    return ln->next;
}

void* cmn_list_node_get_value(cmn_list_node *ln)
{
    return ln->value;
}

cmn_list* cmn_list_dup(cmn_list *l)
{
    return NULL;
}

