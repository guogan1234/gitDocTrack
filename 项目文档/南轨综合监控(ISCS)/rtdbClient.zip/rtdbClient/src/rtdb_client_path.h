/*
 @Copyright Reserved by XXXX.
 Path definition and operations. Path is a string with colons and dots as delimiters.
 Colons are nodes separators, and dots are separators of node and attribute, and separator
 of attribute and attribute. Examples:
    "tableName"
    "tableName.fieldName"
    "domain_label"
    "domain_label.field"
    "domain_label.tableName.field"
    ...
    "domain_label:station_label:pro_system_label:device_label:ai_label"
    "domain_label:station_label:pro_system_label:device_label:ai_label.field"
    "domain_label:station_label:pro_system_label:device_label:ai_label.tableName.field"

 Create by KanWenDi, 2018.04.02.
 Histories:

 */
#ifndef RTDB_CLIENT_PATH_H
#define RTDB_CLIENT_PATH_H
#ifdef __cplusplus
extern "C" {
#endif

#include "rtdb_client_error.h"

typedef struct rtdb_client_path rtdb_client_path;

rtdb_client_path* rtdb_client_path_create();
void rtdb_client_path_release(rtdb_client_path *path);
int8_t rtdb_client_path_get_nodesize(const rtdb_client_path *path);
int8_t rtdb_client_path_get_fieldsize(const rtdb_client_path *path);
const char* crtdb_client_path_get_node(const rtdb_client_path *path, int8_t index);
const char* rtdb_client_path_get_field(const rtdb_client_path *path, int8_t index);
rtdb_client_code rtdb_client_path_add_node(rtdb_client_path *path, char *node);
rtdb_client_code rtdb_client_path_add_field(rtdb_client_path *path, char *field);
rtdb_client_path* rtdb_client_path_parse(const char *spath);

#ifdef __cplusplus
}
#endif
#endif
