/*
 @Copyright Reserved by XXXX.
 Plugin Interface. plugins must implement all those methods defined here.
 Create by KanWenDi, 2018.04.10.
 Histories:

 */
#ifndef CORE_PLUGIN_H
#define CORE_PLUGIN_H
#ifdef __cplusplus
extern "C" {
#endif

/**
 * define methods export and import control symbol.
 * RTDB must defined the macro CORE_PLUGIN_IMPORT to import the plugin methods.
 */
#ifdef _WIN32
    #ifdef CORE_PLUGIN_IMPORT
        #define CORE_PLUGIN_API __declspec(dllimport)
	#else
	    #define CORE_PLUGIN_API __declspec(dllexport)
	#endif
#else
	#define CORE_PLUGIN_API
#endif

#include "core_plugin_cb.h"

/**
 * core_plugin_initialize.
 * "cbs" is an input parameter, it is created an release by RTDB.
 * this method is used to initialize resources and context environment plugins need.
 * RTDB will firstly call this method, when RTDB try to use plugins.
 * the "cbs" just supplies lower level methods that used by plugins, 
 * return 0 on success, and !0 on error.
 */
CORE_PLUGIN_API int core_plugin_initialize(const core_plugin_cbs *cbs);

/**
 * core_plugin_uninitialize.
 * this method is used to release resources and context environment plugins owned.
 * the core_plugin_shutdown must be called, before call this method to release resources and context environment.
 * return 0 on success, and !0 on error.
 */
CORE_PLUGIN_API int core_plugin_uninitialize();

/**
 * core_plugin_startup.
 * this method is used to start the plugin service.
 * the core_plugin_initialize must be called, before call this method.
 * return 0 on success, and !0 on error.
 */
CORE_PLUGIN_API int core_plugin_startup();

/**
 * core_plugin_shutdown.
 * this method is used to stop the plugin service.
 * return 0 on success, and !0 on error.
 */
CORE_PLUGIN_API int core_plugin_shutdown();

/**
 * core_plugin_command.
 * "cmd" is an input parameter, it is created and released by RTDB.
 * "result" is an output parameter, it is created and released by RTDB.
 * this is a synchronized method.
 * this method is used to send command from RTDB to plugins, and plugins should set the command executing status to "result".
 * if a command is a special or compex command that RTDB cann't process, then the command will be delivered to plugin by RTDB.
 * return 0 on success, and !0 on error.
 */
CORE_PLUGIN_API int core_plugin_command(const core_plugin_command *cmd, core_plugin_command_result *result);

/**
 * core_plugin_message.
 * "msg" is an input parameter, it is created and released by RTDB.
 * this method is used to send message from RTDB to plugins.
 * return 0 on success, and !0 on error.
 */
CORE_PLUGIN_API int core_plugin_message(const core_plugin_message *msg);

#ifdef __cplusplus
}
#endif
#endif
