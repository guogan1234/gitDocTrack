/*
 @Copyright Reserved by XXXX.
 Plugins. define message from RTDB core to plugin.
 Create by KanWenDi, 2018.04.10.
 Histories:

 */
#ifndef CORE_PLUGIN_CB_H
#define CORE_PLUGIN_CB_H
#ifdef __cplusplus
extern "C" {
#endif

/**
 * core_plugin_message is used to pass message between RTDB and plug-ins.
 */
typedef struct
{
	int type;
	char *message;
} core_plugin_message;


#ifdef __cplusplus
}
#endif
#endif
