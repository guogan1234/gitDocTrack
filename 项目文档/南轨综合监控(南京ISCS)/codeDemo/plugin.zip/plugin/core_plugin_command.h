/*
 @Copyright Reserved by XXXX.
 Plugins. define command from RTDB core to plugin.
 Create by KanWenDi, 2018.04.10.
 Histories:

 */
#ifndef CORE_PLUGIN_COMMAND_H
#define CORE_PLUGIN_COMMAND_H
#ifdef __cplusplus
extern "C" {
#endif

/**
 * core_plugin_command is used to pass command from RTDB to plugins. 
 */
typedef struct
{
	
} core_plugin_command;

/**
 * core_plugin_direct_command is used to pass command from plugins to RTDB,
 * and RTDB will do nothing, but send command to FES directly. 
 */
typedef struct
{
	
} core_plugin_direct_command;

/**
 * core_plugin_command_result is used to pass command from RTDB to plugins. 
 */
typedef struct
{
	int code;
	char *message;
} core_plugin_command_result;

#ifdef __cplusplus
}
#endif
#endif
