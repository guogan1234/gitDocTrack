/*
 @Copyright Reserved by XXXX.
 Plugins. define callback methods used by app-system plugins.
 All the callback methods are implemented by RTDB Core, and set to plugin by plugin api.
 Create by KanWenDi, 2018.04.10.
 Histories:

 */
#ifndef CORE_PLUGIN_CB_H
#define CORE_PLUGIN_CB_H
#ifdef __cplusplus
extern "C" {
#endif

#include "core_plugin_command.h"
#include "core_plugin_message.h"

//
// prototype callback methods.
//

/**
 * core_plugin_cb_message.
 * "msg" is an input parameter, and it is created and release by plugin.
 * this method is implemented by RTDB, and is used by plugins.
 * when there is any message needs to be processed by RTDB in plugins, then plugins call this method to send message to RTDB.
 * this method return 0 on success, and !0 on error.
 */
typedef int(core_plugin_cb_message*)(const core_plugin_message *msg);

/**
 * core_plugin_cb_direct_command.
 * "cmd" is an input parameter, and it is created and release by plugin.
 * "result" is an output parameter, and it is created and relase by plugin, this method just set value to it.
 * htis method is implemented by RTDB, and is used by plugins.
 * when there is any command that just send to FES directly in plugins, then plugins call this method to send command to RTDB,
 * and RTDB will send this command directly to FES.
 */
typedef int(core_plugin_cb_direct_command*)(const core_plugin_direct_command *cmd, core_plugin_command_result *result);

/**
 * core_plugin_cbs is used to pass RTDB methods to plugins.
 * those callback methods are implemented by RTDB and used by plugins.
 */
typedef struct
{
	core_plugin_cb_message messageHandler;
	core_plugin_cb_direct_command directCommandHandler;
} core_plugin_cbs;


#ifdef __cplusplus
}
#endif
#endif
