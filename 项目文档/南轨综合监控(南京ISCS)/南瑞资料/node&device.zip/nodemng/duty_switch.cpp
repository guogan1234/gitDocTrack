/**************************************
* @file duty_switch.cpp
* @brief duty_switch app
* @author lib
* @version 1.0
* @date 19-Apr-2013
* @log:43500 -- 43549
***************************************/
#include "hb_struct.h"
#include "nodemng_def.h"
#include "libpub.h"
#include "shmkey_define.h"
#include "libpara.h"
#include "liblogger.h"

#ifndef WIN32
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#if !defined ( _LINUX ) && !defined( _IBM )
#include <inet/ip.h>
#endif
#endif
#include <string>


void usage(void)
{
    printf("duty_switch -d domain_id app_name  [duty|back] hostname\n");
    printf("duty_switch  public  [duty|back] hostname\n");
    return;
}

void on_sig(int nouse)
{
    return;
}


int main(int argc, char **argv)
{
    rt21_context_init(argc, argv);
    if (rt21_context_sim())//��ѵ̬
    {
        argc = argc - 1; //��������֮��ԭ�����еĶ�������Ҫ�䶯
    }

    bool need_alarm = true;
    if (argc < 2)
    {
        usage();
        return -1;
    }
    if (strcmp(argv[1], "-help") == 0)
    {
        usage();
        return -1;
    }
    log_init("duty_switch", "duty_switch");
#ifndef WIN32
    signal(SIGINT, on_sig);
    signal(SIGTERM, on_sig);
    signal(SIGALRM, on_sig);
    signal(SIGPIPE, on_sig);
    signal(SIGUSR1, on_sig);
    signal(SIGHUP, on_sig);
#else
    WORD wVersionRequested;
    WSADATA wsaData;

    wVersionRequested = MAKEWORD(1, 1);
    WSAStartup(wVersionRequested, &wsaData);
#endif
    struct NM_SWITCH_PACKET nsp;

    CShm pcshm;
    NODEMNG_SHM *pshm = (NODEMNG_SHM *)pcshm.AttachShm("nodemng", sizeof(struct NODEMNG_SHM));
    if (pshm == NULL)
    {
        log_printf(LOG_ERROR, 43500, "Attach share memory error");
        _exit(-1);
    }
    CNodeInfo ni;
    if (!ni.init())
    {
        log_printf(LOG_ERROR, 43501, "CNodeInfo init error, check nodes.sys");
        _exit(-1);
    }
    int local_sergrp_id;
    int i;
    if (ni.getLocalServerGroupId(local_sergrp_id) < 0)
    {
        log_printf(LOG_ERROR, 43502, "duty_switch--Can not Get Active domain, abort.");
        usage();
        _exit(-1);
    }

    CSysInfo si;
    if (si.Init() < 0)
    {
        printf("CSysinfo::Init() error\n");
        return -1;
    }
    std::vector<string> node_list;
    if (si.GetAppServerNodeBySgId(node_list) < 0)
    {
        log_printf(LOG_ERROR, 43503, "duty_switch--CSysInfo can not GetAppServerNodeBySgId, abort.");
        usage();
        _exit(-1);
    }
    if (strcmp(argv[1], "-d") == 0) //��ʾ����Ӧ��
    {
        if (argc < 6)
        {
            usage();
            _exit(-1);
        }
        if ((argc == 7) && (strcmp(argv[6], "-stop") == 0))
        {
            need_alarm = false;
        }
        char temp[64];
        if (CPubCommon::str_low(temp, argv[3]) < 0)
        {
            printf("CPubCommon::str_low error:app_name =%s\n", argv[3]);
            usage();
            _exit(-1);
        }
        std::string app_name(temp);

        std::vector<int> activeDomainList;
        std::vector<int> appno_list;
        map<int, string> appMap;
        if (!ni.getDomainID(activeDomainList))
        {
            log_printf(LOG_ERROR, 43504, "duty_switch--Can not Get Active domain, abort.");
            usage();
            _exit(-1);
        }
        int domain_id = atoi(argv[2]);;
        for (i = 0; i < activeDomainList.size(); i++)
        {
            if (domain_id == activeDomainList[i])
            {
                break;
            }
        }
        if (i == activeDomainList.size())
        {
            log_printf(LOG_ERROR, 43505, "Can not find this domain in this node ,domain_id =%d.", domain_id);
            usage();
            _exit(-1);
        }

        if (si.GetAppInfoByDomainId(appno_list, domain_id) < 0) //��ȡ���ڵ��������Ӧ����Ϣ
        {
            log_printf(LOG_ERROR, 43506,
                       "duty_switch--CSysInfo can not GetAppInfoByDomainId--domain_id =%d, abort.", domain_id);
            usage();
            _exit(-1);
        }
        if (si.GetAllAppInfo(appMap) < 0) //��ȡ����Ӧ����Ϣmap<app_id,app_name>
        {
            log_printf(LOG_ERROR, 43507, "duty_switch--CSysInfo can not GetAllAppInfo, abort.");
            usage();
            _exit(-1);
        }
        for (i = 0; i < node_list.size(); i++)
        {
            if (strcmp(argv[5], node_list[i].c_str()) == 0)
            {
                break;
            }
        }
        if (i == node_list.size()) //��ʾû���ҵ�
        {
            printf("can not find this node(%s) in this sgid(%d)\n", argv[5], local_sergrp_id);
            usage();
            _exit(-1);
        }
        std::map<int, string> ::iterator iter_appMap;
        bool jump_flag = false;
        for (i = 0; i < appno_list.size(); i++)
        {
            for (iter_appMap = appMap.begin(); iter_appMap != appMap.end(); ++iter_appMap)
            {
                if (iter_appMap->first == appno_list[i])
                {
                    char temp1[64];
                    if (CPubCommon::str_low(temp1, iter_appMap->second.c_str()) < 0)
                    {
                        printf("CPubCommon::str_low error:app_name =%s\n", iter_appMap->second.c_str());
                        usage();
                        _exit(-1);
                    }
                    std::string temp_appname(temp1);
                    if (strcmp(app_name.c_str(), temp_appname.c_str()) == 0)
                    {
                        nsp.app_num = htonl(iter_appMap->first);
                        jump_flag = true;
                        break;
                    }
                }
            }
            if (jump_flag)
            {
                break;
            }
        }
        if (i == appno_list.size())
        {
            printf("can not find this app(%s) in this domain(%d)\n", argv[3], domain_id);
            usage();
            _exit(-1);
        }

        memcpy(nsp.head.magic, PACKET_LEAD, 6);
        strcpy(nsp.head.hostname, ni.getHostname());

        nsp.head.packet_type = htonl(APP_SWITCH);
        nsp.domain_id = htonl(domain_id);
        if (strcmp(argv[4], "duty") ==
                0) //command ==0 ǿ����������command ==1 ǿ����������command ==2 ǿ����������
        {
            nsp.command = htonl(0);
        }
        else if (strcmp(argv[4], "back") == 0)
        {
            if (need_alarm)//��Ҫ����
            {
                nsp.command = htonl(1);
            }
            else//����Ҫ������ֻ��ͣϵͳʱ��
            {
                nsp.command = htonl(2);
            }
        }
        else
        {
            usage();
            _exit(-1);
        }

        strcpy(nsp.hostname, argv[5]);

        log_printf(LOG_NORMAL, 43508, "force %s to switch %s to %s in domain(%d)", argv[5], argv[3],
                   argv[4], atoi(argv[2]));


    }
    else if ((strcmp(argv[1], "public") == 0) || (strcmp(argv[1], "PUBLIC") == 0))
    {
        if (argc < 4)
        {
            usage();
            _exit(-1);
        }
        if ((argc == 5) && (strcmp(argv[4], "-stop") == 0))
        {
            need_alarm = false;
        }
        for (i = 0; i < node_list.size(); i++)
        {
            if (strcmp(argv[3], node_list[i].c_str()) == 0)
            {
                break;
            }
        }
        if (i == node_list.size()) //��ʾû���ҵ�
        {
            printf("can not find this node(%s) in this sgid(%d)\n", argv[3], local_sergrp_id);
            usage();
            _exit(-1);
        }

        nsp.app_num = htonl(PUBLIC);
        memcpy(nsp.head.magic, PACKET_LEAD, 6);
        strcpy(nsp.head.hostname, ni.getHostname());

        nsp.head.packet_type = htonl(APP_SWITCH);
        nsp.domain_id = htonl(-1);
        if (strcmp(argv[2], "duty") ==
                0) //command ==0 ǿ����������command ==1 ǿ����������command ==2 ǿ����������
        {
            nsp.command = htonl(0);
        }
        else if (strcmp(argv[2], "back") == 0)
        {
            if (need_alarm)
            {
                nsp.command = htonl(1);
            }
            else
            {
                nsp.command = htonl(2);
            }
        }
        else
        {
            usage();
            _exit(-1);
        }

        strcpy(nsp.hostname, argv[3]);

        log_printf(LOG_NORMAL, 43509, "force %s to switch %s to %s", argv[3], argv[1], argv[2]);
    }
    else
    {
        usage();
        _exit(-1);
    }
    //����
    //if(!ni.init(nsp.hostname))
    //{
    //  log_printf(LOG_ERROR, 43510, "CNodeInfo init error, check nodes.sys.hostname %s",nsp.hostname);
    //  _exit(-1);
    //}
    //DatagramSocket  duty_switchSock;    //ע��socket
    //try
    //{
    //  duty_switchSock.sendTo((const char*)(&nsp), sizeof(struct NM_SWITCH_PACKET), SocketAddress(string(ni.getNIC1Addr()), HEARTBEAT_PORT));
    //}
    //catch(Exception& ex)
    //{
    //  log_printf(LOG_ERROR, 43511,"Duty_switch::send,net A send failed, errno = %d, description: %s",ex.code(),ex.displayText().c_str());
    //}
    //if ( ni.getNICNum()== 2)
    //{
    //  try
    //  {
    //      duty_switchSock.sendTo((const char*)(&nsp), sizeof(struct NM_SWITCH_PACKET), SocketAddress(string(ni.getNIC2Addr()), HEARTBEAT_PORT));
    //  }
    //  catch(Exception& ex)
    //  {
    //      log_printf(LOG_ERROR, 43512,"Duty_switch::send,net B send failed, errno = %d, description: %s",ex.code(),ex.displayText().c_str());
    //  }
    //}














    /* ���÷���SOCKET(�鲥) */
    unsigned char ttl = 3;
    if (!ni.init())
    {
        log_printf(LOG_ERROR, 43513, "CNodeInfo init error, check nodes.sys.local_host");
        _exit(-1);
    }

    MulticastSocket multi_sendsock1(IPAddress::IPv4);
    MulticastSocket multi_sendsock2(IPAddress::IPv4);
    try
    {
        NetworkInterface ifc1 = NetworkInterface::forAddress(IPAddress(string(ni.getNIC1Addr())));
        multi_sendsock1.setInterface(ifc1);
        multi_sendsock1.setOption(IPPROTO_IP, IP_MULTICAST_TTL, ttl);
        log_printf(LOG_SENSOR, 43514, "duty_switch multi_sendsock1 setInterface netA success");
    }
    catch (Exception &)
    {
        log_printf(LOG_WARN, 43515, "duty_switch set A net NetworkInterface error, A net may be bad");
    }
    if (ni.getNICNum() == 2)
    {
        try
        {
            NetworkInterface ifc2 = NetworkInterface::forAddress(IPAddress(string(ni.getNIC2Addr())));
            multi_sendsock2.setInterface(ifc2);
            multi_sendsock2.setOption(IPPROTO_IP, IP_MULTICAST_TTL, ttl);
            log_printf(LOG_SENSOR, 43516, "duty_switch multi_sendsock2 setInterface netB success");
        }
        catch (Exception &)
        {
            log_printf(LOG_WARN, 43517, "duty_switch set B net NetworkInterface error, B net may be bad");
        }
    }



    //���鲥
    try
    {
        multi_sendsock1.sendTo((const char *)(&nsp), sizeof(struct NM_SWITCH_PACKET),
                               SocketAddress(string(ni.getNIC1MulticastAddr()), CPubCommon::getPort(HEARTBEAT_PORT)));
    }
    catch (Exception &ex)
    {
        log_printf(LOG_WARN, 43518,
                   "duty_switch multi_sendsock1 send remote_heartbeat packet error, errno = %d,description: %s",
                   ex.code(), ex.displayText().c_str());
    }
    if (ni.getNICNum() == 2)
    {
        try
        {
            multi_sendsock2.sendTo((const char *)(&nsp), sizeof(struct NM_SWITCH_PACKET),
                                   SocketAddress(string(ni.getNIC2MulticastAddr()), CPubCommon::getPort(HEARTBEAT_PORT)));
        }
        catch (Exception &ex)
        {
            log_printf(LOG_WARN, 43519,
                       "duty_switch multi_sendsock2 send remote_heartbeat packet error, errno = %d,description: %s",
                       ex.code(), ex.displayText().c_str());
        }
    }

    return 0;
}
