
#include "hb_struct.h"
#include "nodemng_def.h"
#include "libpub.h"
#include "shmkey_define.h"
#include "libpara.h"
#include "liblogger.h"
#include "libtableout.h"
#include <string>
#include <vector>
using namespace std;

CSysInfo g_si;
CPublicTime g_pt;
std::vector<string> g_node_list;
std::vector<int> g_domain_list;
std::vector<int> g_appno_list;
int g_local_sergrp_id;
int g_show_domain_id;
CShm *pcshm;
//struct NODE_INFO
//{
//  int system_id;  /* ϵͳ�� */
//  int context;    /* ����context */
//  int app_id; /* Ӧ�ú� */
//  char app_name[40];  /* Ӧ���� */
//  int node_number;    /* ���нڵ���� */
//  int nodes[16];
//};
//
//struct HOST_INFO
//{
//  int node_id;
//  char node_name[40];
//};
//
//static inline int GetAppPosById(int nAppId)
//{
//  int i;
//  for(i=0; i<MAX_APP_NUM;i++)
//  {
//      if(1<<i == nAppId)
//          return i;
//  }
//  return -1;
//}
//
//int getNode(int node_id, struct HOST_INFO* phost_info, int num)
//{
//  int i;
//  for(i=0; i<num; i++)
//  {
//      if(phost_info[i].node_id == node_id)
//          return i;
//  }
//  return -1;
//}
//
//
//
//void showLocalDomainTmp(NODEMNG_SHM* pshm, CTableOut &to)
//{
//  cout << "����[" << pshm->local_domain_id << "]Ӧ����Ϣ��" << endl;
//
//  to.clear();
//
//  vector<CTableOut::TABLE_INFO> tis;
//  CTableOut::TABLE_INFO ti;
//  string appname;
//
//  ti.head_name = "Ӧ����";
//  ti.data_type = CTableOut::D_TEXT;
//  tis.push_back(ti);
//
//  ti.head_name = "����";
//  ti.data_type = CTableOut::D_TEXT;
//  tis.push_back(ti);
//
//  ti.head_name = "����1";
//  ti.data_type = CTableOut::D_TEXT;
//  tis.push_back(ti);
//
//  ti.head_name = "����2";
//  ti.data_type = CTableOut::D_TEXT;
//  tis.push_back(ti);
//
//  ti.head_name = "����3";
//  ti.data_type = CTableOut::D_TEXT;
//  tis.push_back(ti);
//
//  ti.head_name = "����4";
//  ti.data_type = CTableOut::D_TEXT;
//  tis.push_back(ti);
//
//  to.setTable(tis);
//
//  string app_name;
//  for(int i=0; i<MAX_APP_NUM; i++)
//  {
//      //if(GetAppNameByNo(1<<i, app_name) == -1)
//      //  continue;
//      //to.setItem(i, 0, app_name.c_str());
//      /**
//      * ʱ�䣺2011��3��25��
//      * ���ߣ�hzxt
//      * �޸ģ������˻�����Ӧ���滻ʵ��Ӧ������ʵ��ϵͳ��Ӧ�ú�ʵ��ʹ��Ӧ��������
//      */
//      if(g_si.GetAppNameByNo(1<<i, app_name) < 0)
//          continue;
//      string hmiapp = app_name;
//
//
//      to.setItem(i, 0, hmiapp.c_str());
//      if(pshm->local_domain_apps[i].usage)
//      {
//          if(pshm->local_domain_apps[i].duty_host == -1)
//          {
//              to.setItem(i, 1, pshm->localhost.hostname);
//          }
//          if(pshm->local_domain_apps[i].duty_host >= 0)
//          {
//              to.setItem(i, 1, pshm->neighbors[pshm->local_domain_apps[i].duty_host].hostname);
//          }
//
//          for(int j=0; j<MAX_NODE_NUM; j++)
//          {
//              if(pshm->local_domain_apps[i].standby_host[j] == -2)
//                  break;
//              if(pshm->local_domain_apps[i].standby_host[j] == -1)
//              {
//                  to.setItem(i, j+2, pshm->localhost.hostname);
//              }
//              if(pshm->local_domain_apps[i].standby_host[j] >= 0)
//              {
//                  to.setItem(i, j+2, pshm->neighbors[pshm->local_domain_apps[i].standby_host[j]].hostname);
//              }
//          }
//      }
//  }
//
//  to.print();
//  return;
//
//}

void destroyShm()
{
    if (pcshm != NULL)
    {
        delete pcshm;
        pcshm = NULL;
    }
    return ;
}


void showOtherSerGroup(NODEMNG_SHM *pshm, CTableOut &to, int segrp_id)
{

    int m, i, j;
    int app_pos;
    char hostname_info[512];


    //for public
    to.clear();
    vector<CTableOut::TABLE_INFO> tis;
    CTableOut::TABLE_INFO ti;
    char file_name[256];
    ti.head_name = "Ӧ����";
    ti.data_type = CTableOut::D_TEXT;
    tis.push_back(ti);

    sprintf(file_name, "�ڵ�1");
    ti.head_name = string(file_name);
    ti.data_type = CTableOut::D_TEXT;
    tis.push_back(ti);

    to.setTable(tis);
    cout << endl;
    cout << "PUBLICӦ�ã�" << endl;
    string hmiapp = "PUBLIC";
    to.setItem(0, 0, hmiapp.c_str());
    int index_sergrp;
    //for public
    for (i = 0; i < MAX_SERGRP_NUM; i++)
    {
        if (pshm->remote_sergrp[i].sergrp_id != segrp_id)
        {
            continue;
        }
        if (pshm->remote_sergrp[i].usage == 0)
        {
            printf("��Ϣ����.......\n");
            return ;
        }

        sprintf(hostname_info, "%s(��)", pshm->remote_sergrp[i].remote_public.duty_hostname);
        index_sergrp = i;
        to.setItem(0, 1, hostname_info);
        to.print();
        break;
    }

    if (i == MAX_SERGRP_NUM)
    {
        printf("�Ҳ����˷�������,��ȷ��sam_tunnel������ת��\n");
        //cout <<"�Ҳ����˷�������,��ȷ��sam_tunnel������ת��"<<endl;
        return;
    }
    printf("\n");
    //cout <<endl;
    //for ����Ӧ��
    for (i = 0; i < MAX_DM_IN_SG; i++)
    {
        if (pshm->remote_sergrp[index_sergrp].remote_domains[i].usage != 1)
        {
            continue;
        }
        to.clear();
        printf("\n");
        //cout << endl;
        vector<CTableOut::TABLE_INFO> tis;
        CTableOut::TABLE_INFO ti;
        char file_name[256];
        ti.head_name = "Ӧ����";
        ti.data_type = CTableOut::D_TEXT;
        tis.push_back(ti);

        sprintf(file_name, "�ڵ�1");
        ti.head_name = string(file_name);
        ti.data_type = CTableOut::D_TEXT;
        tis.push_back(ti);
        to.setTable(tis);
        //cout << "��[" << pshm->remote_sergrp[index_sergrp].remote_domains[i].domain_id<< "]Ӧ����Ϣ��" << endl;
        printf("��[%d]Ӧ����Ϣ��\n", pshm->remote_sergrp[index_sergrp].remote_domains[i].domain_id);
        int nret = g_si.GetAppInfoByDomainId(g_appno_list,
                                             pshm->remote_sergrp[index_sergrp].remote_domains[i].domain_id);
        if (nret < 0)
        {
            printf("g_si.GetAppInfoByDomainId() domain_id=%d error",
                   pshm->remote_sergrp[index_sergrp].remote_domains[i].domain_id);
            _exit(-1);
        }
        for (j = 0; j < g_appno_list.size(); j++) //�����������Ӧ�ã�������
        {
            app_pos = g_appno_list[j];
            if (app_pos == PUBLIC)
            {
                continue;
            }
            string hmiapp;
            if (g_si.GetAppNameByNo(g_appno_list[j], hmiapp) < 0)
            {
                continue;
            }
            to.setItem(j, 0, hmiapp.c_str());
            for (m = 0; m < MAX_APP_NUM; m++)
            {
                if (m != app_pos)
                {
                    continue;
                }
                if (pshm->remote_sergrp[index_sergrp].remote_domains[i].duty_host[m].usage == 0)
                {
                    sprintf(hostname_info, "(������)");
                    break;
                }
                sprintf(hostname_info, "%s(��)",
                        pshm->remote_sergrp[index_sergrp].remote_domains[i].duty_host[m].hostname);
                break;
            }
            to.setItem(j, 1, hostname_info);
        }
        to.print();
    }
    return ;
}


void showLocalDomain(NODEMNG_SHM *pshm, CTableOut &to)
{
    //printf("local_server=%d\n",sizeof(NM_LOCAL_PACKET_SERVER));
    //printf("local_client=%d\n",sizeof(NM_LOCAL_PACKET_CLIENT));
    //printf("remote=%d\n",sizeof(NM_REMOTE_PACKET));


    int m, i, j, k, n, l;
    // int cur_domain_index;
    int app_pos;
    char hostname_info[512];

    //for public
    to.clear();
    vector<CTableOut::TABLE_INFO> tis;
    CTableOut::TABLE_INFO ti;
    char file_name[256];
    ti.head_name = "Ӧ����";
    ti.data_type = CTableOut::D_TEXT;
    tis.push_back(ti);

    for (i = 0; i < g_node_list.size(); i++)
    {
        sprintf(file_name, "�ڵ�%d", i + 1);
        ti.head_name = string(file_name);
        ti.data_type = CTableOut::D_TEXT;
        tis.push_back(ti);
    }
    to.setTable(tis);
    printf("\n");
    printf("PUBLICӦ�ã�\n");
    //cout << endl;
    //cout << "PUBLICӦ�ã�" << endl;
    string hmiapp = "PUBLIC";
    to.setItem(0, 0, hmiapp.c_str());
    for (j = 0, k = 1; j < g_node_list.size(); j++)
    {
        if (strcmp(pshm->nodemng_public.localhost.hostname, g_node_list[j].c_str()) == 0) // ����Ǳ���
        {
            if (pshm->nodemng_public.local_domain_apps.duty_host == -1)
            {
                sprintf(hostname_info, "%s(��)", pshm->nodemng_public.localhost.hostname);
            }
            else
            {
                for (l = 0; l < MAX_NODE_NUM; l++)
                {
                    if (pshm->nodemng_public.local_domain_apps.standby_host[l] == -1)
                    {
                        sprintf(hostname_info, "%s(��)", pshm->nodemng_public.localhost.hostname);
                        break;
                    }
                    if (pshm->nodemng_public.local_domain_apps.standby_host[l] == -2)
                    {
                        l = MAX_NODE_NUM;
                        break;
                    }
                }
                if (l == MAX_NODE_NUM)
                {
                    if (pshm->nodemng_public.localhost.app_order == -1)
                    {
                        sprintf(hostname_info, "%s(ͣ)", pshm->nodemng_public.localhost.hostname);
                    }
                    else
                    {
                        switch (pshm->nodemng_public.localhost.app_info & RUN_MASK)
                        {
                        case RUN_START:
                            sprintf(hostname_info, "%s(��)", pshm->nodemng_public.localhost.hostname);
                            break;
                        case RUN_STOP:
                            sprintf(hostname_info, "%s(ͣ)", pshm->nodemng_public.localhost.hostname);
                            break;
                        case RUN_FAIL:
                            sprintf(hostname_info, "%s(��)", pshm->nodemng_public.localhost.hostname);
                            break;
                        default:
                            if (((pshm->nodemng_public.localhost.app_info & RUN_MASK) == RUN_BACK)||((pshm->nodemng_public.localhost.app_info & RUN_MASK) == RUN_FORCE_BACK))
                            {
                                if ((pshm->nodemng_public.localhost.app_info & PROCESS_MASK) == PROCESS_OK)
                                {
                                    sprintf(hostname_info, "%s(��)", pshm->nodemng_public.localhost.hostname);
                                }
                                else
                                {
                                    sprintf(hostname_info, "%s(��)", pshm->nodemng_public.localhost.hostname);
                                }
                                break;
                            }
                            else if ((pshm->nodemng_public.localhost.app_info & RUN_MASK) == RUN_DUTY)
                            {
                                if ((pshm->nodemng_public.localhost.app_info & PROCESS_MASK) == PROCESS_OK)
                                {
                                    sprintf(hostname_info, "%s(��)", pshm->nodemng_public.localhost.hostname);
                                }
                                else
                                {
                                    sprintf(hostname_info, "%s(��)", pshm->nodemng_public.localhost.hostname);
                                }
                                break;
                            }
                        }
                    }
                }
            }
            to.setItem(0, k++, hostname_info);
        }
        else
        {
            int node_pos = -1;
            for (l = 0; l < MAX_NODE_NUM; l++)
            {
                if ((pshm->nodemng_public.neighbors[l].usage)
                        && (strcmp(pshm->nodemng_public.neighbors[l].hostname, g_node_list[j].c_str()) == 0))
                {
                    node_pos = l;
                    break;
                }
            }
            if (l == MAX_NODE_NUM) // �˻����Ѿ�ֹͣ�����
            {
                sprintf(hostname_info, "%s(��)", g_node_list[j].c_str());
            }
            else
            {
                if (pshm->nodemng_public.local_domain_apps.duty_host == node_pos)
                {
                    sprintf(hostname_info, "%s(��)", pshm->nodemng_public.neighbors[node_pos].hostname);
                }
                else
                {
                    for (l = 0; l < MAX_NODE_NUM; l++)
                    {
                        if (pshm->nodemng_public.local_domain_apps.standby_host[l] == node_pos)
                        {
                            sprintf(hostname_info, "%s(��)", pshm->nodemng_public.neighbors[node_pos].hostname);
                            break;
                        }
                        if (pshm->nodemng_public.local_domain_apps.standby_host[l] == -2)
                        {
                            l = MAX_NODE_NUM;
                            break;
                        }
                    }
                    if (l == MAX_NODE_NUM)
                    {
                        if (pshm->nodemng_public.neighbors[node_pos].app_order == -1)
                        {
                            sprintf(hostname_info, "%s(ͣ)", pshm->nodemng_public.neighbors[node_pos].hostname);
                        }
                        else
                        {
                            switch (pshm->nodemng_public.neighbors[node_pos].app_info & RUN_MASK)
                            {
                            case RUN_START:
                                sprintf(hostname_info, "%s(��)", pshm->nodemng_public.neighbors[node_pos].hostname);
                                break;
                            case RUN_STOP:
                                sprintf(hostname_info, "%s(ͣ)", pshm->nodemng_public.neighbors[node_pos].hostname);
                                break;
                            case RUN_FAIL:
                                sprintf(hostname_info, "%s(��)", pshm->nodemng_public.neighbors[node_pos].hostname);
                                break;
                            default:
                                sprintf(hostname_info, "%s(��)", pshm->nodemng_public.neighbors[node_pos].hostname);
                                break;
                            }

                        }
                    }
                }
            }
            to.setItem(0, k++, hostname_info);
        }
    }
    to.print();

    printf("\n");
    //cout <<endl;


    for (m = 0; m < g_domain_list.size(); m++)
    {
        if ((g_show_domain_id != g_domain_list[m]) && (g_show_domain_id > 0))
        {
            continue;
        }
        int domain_not_used_flag = 0;
        to.clear();


        vector<CTableOut::TABLE_INFO> tis;
        CTableOut::TABLE_INFO ti;
        char file_name[256];
        ti.head_name = "Ӧ����";
        ti.data_type = CTableOut::D_TEXT;
        tis.push_back(ti);

        for (i = 0; i < g_node_list.size(); i++)
        {
            sprintf(file_name, "�ڵ�%d", i + 1);
            ti.head_name = string(file_name);
            ti.data_type = CTableOut::D_TEXT;
            tis.push_back(ti);
        }
        to.setTable(tis);
        if (m != 0)
        {
            printf("\n");
            //cout <<endl;
        }
        printf("��[%d]Ӧ����Ϣ��\n", g_domain_list[m]);
        //cout << "��[" << g_domain_list[m]<< "]Ӧ����Ϣ��" << endl;
        int nret = g_si.GetAppInfoByDomainId(g_appno_list, g_domain_list[m]);
        if (nret < 0)
        {
            printf("g_si.GetAppInfoByDomainId() domain_id=%d error", g_domain_list[m]);
            _exit(-1);
        }
        //for (int i=0;i<g_appno_list.size();i++)
        //{
        //  printf("app_id =%d\n",g_appno_list[i]);
        //}
        for (i = 0; i < g_appno_list.size(); i++) //�����������Ӧ�ã�������
        {
            app_pos = g_appno_list[i];
            if (app_pos == PUBLIC)
            {
                continue;
            }
            string hmiapp;
            if (g_si.GetAppNameByNo(g_appno_list[i], hmiapp) < 0)
            {
                continue;
            }
            to.setItem(i, 0, hmiapp.c_str());
            for (j = 0, k = 1; j < g_node_list.size(); j++)
            {
                for (n = 0; n < pshm->domain_count; n++)
                {
                    if (pshm->nodemng_domain[n].local_domain_id ==
                            g_domain_list[m]) //��ʾ�ҵ������ڴ��е����뵱ǰҪ��ӡ����һһ��
                    {
                        //cur_domain_index = n;
                        break;
                    }
                }
                if (n == pshm->domain_count)//��ʾû���ҵ�
                {
                    printf("domain(%d) not be used \n", g_domain_list[m]);
                    domain_not_used_flag = 1;
                    break;
                }
                if (strcmp(pshm->nodemng_domain[n].localhost.hostname, g_node_list[j].c_str()) == 0) // ����Ǳ���
                {
                    if (pshm->nodemng_domain[n].local_domain_apps[app_pos].duty_host == -1)
                    {
                        sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].localhost.hostname);
                    }
                    else
                    {
                        for (l = 0; l < MAX_NODE_NUM; l++)
                        {
                            if (pshm->nodemng_domain[n].local_domain_apps[app_pos].standby_host[l] == -1)
                            {
                                sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].localhost.hostname);
                                break;
                            }
                            if (pshm->nodemng_domain[n].local_domain_apps[app_pos].standby_host[l] == -2)
                            {
                                l = MAX_NODE_NUM;
                                break;
                            }
                        }
                        if (l == MAX_NODE_NUM)
                        {
                            if (pshm->nodemng_domain[n].localhost.app_order[app_pos] == -1)
                            {
                                sprintf(hostname_info, "%s(ͣ)", pshm->nodemng_domain[n].localhost.hostname);
                            }
                            else
                            {
                                switch (pshm->nodemng_domain[n].localhost.app_info[app_pos]&RUN_MASK)
                                {
                                case RUN_START:
                                    sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].localhost.hostname);
                                    break;
                                case RUN_STOP:
                                    sprintf(hostname_info, "%s(ͣ)", pshm->nodemng_domain[n].localhost.hostname);
                                    break;
                                case RUN_FAIL:
                                    sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].localhost.hostname);
                                    break;
                                default:
                                    if (((pshm->nodemng_domain[n].localhost.app_info[app_pos]&RUN_MASK) == RUN_BACK)||((pshm->nodemng_domain[n].localhost.app_info[app_pos]&RUN_MASK) == RUN_FORCE_BACK))
                                    {
                                        if ((pshm->nodemng_domain[n].localhost.app_info[app_pos]&PROCESS_MASK) == PROCESS_OK)
                                        {
                                            sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].localhost.hostname);
                                        }
                                        else
                                        {
                                            sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].localhost.hostname);
                                        }
                                        break;
                                    }
                                    if ((pshm->nodemng_domain[n].localhost.app_info[app_pos]&RUN_MASK) == RUN_DUTY)
                                    {
                                        if ((pshm->nodemng_domain[n].localhost.app_info[app_pos]&PROCESS_MASK) == PROCESS_OK)
                                        {
                                            sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].localhost.hostname);
                                        }
                                        else
                                        {
                                            sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].localhost.hostname);
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    to.setItem(i, k++, hostname_info);
                }
                else
                {
                    int node_pos = -1;
                    for (l = 0; l < MAX_NODE_NUM; l++)
                    {
                        if ((pshm->nodemng_domain[n].neighbors[l].usage)
                                && (strcmp(pshm->nodemng_domain[n].neighbors[l].hostname, g_node_list[j].c_str()) == 0))
                        {
                            node_pos = l;
                            break;
                        }
                    }
                    if (l == MAX_NODE_NUM) // �˻����Ѿ�ֹͣ�����
                    {

                        sprintf(hostname_info, "%s(��)", g_node_list[j].c_str());
                        //printf("?????????????????\n");
                        //int inode = getNode(pnode_info[i].nodes[j], phost_info, num);
                        //if(inode != -1)
                        //  sprintf(hostname_info, "%s(��)", phost_info[inode].node_name);
                        //else
                        //  sprintf(hostname_info, "�޷�ʶ��");
                    }
                    else
                    {
                        if (pshm->nodemng_domain[n].local_domain_apps[app_pos].duty_host == node_pos)
                        {
                            sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].neighbors[node_pos].hostname);
                        }
                        else
                        {
                            for (l = 0; l < MAX_NODE_NUM; l++)
                            {
                                if (pshm->nodemng_domain[n].local_domain_apps[app_pos].standby_host[l] == node_pos)
                                {
                                    sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].neighbors[node_pos].hostname);
                                    break;
                                }
                                if (pshm->nodemng_domain[n].local_domain_apps[app_pos].standby_host[l] == -2)
                                {
                                    l = MAX_NODE_NUM;
                                    break;
                                }
                            }
                            if (l == MAX_NODE_NUM)
                            {
                                if (pshm->nodemng_domain[n].neighbors[node_pos].app_order[app_pos] == -1)
                                {
                                    sprintf(hostname_info, "%s(ͣ)", pshm->nodemng_domain[n].neighbors[node_pos].hostname);
                                }
                                else
                                {
                                    switch (pshm->nodemng_domain[n].neighbors[node_pos].app_info[app_pos]&RUN_MASK)
                                    {
                                    case RUN_START:
                                        sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].neighbors[node_pos].hostname);
                                        break;
                                    case RUN_STOP:
                                        sprintf(hostname_info, "%s(ͣ)", pshm->nodemng_domain[n].neighbors[node_pos].hostname);
                                        break;
                                    case RUN_FAIL:
                                        sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].neighbors[node_pos].hostname);
                                        break;
                                    default:
                                        sprintf(hostname_info, "%s(��)", pshm->nodemng_domain[n].neighbors[node_pos].hostname);
                                        break;
                                    }

                                }
                            }
                        }
                    }
                    to.setItem(i, k++, hostname_info);
                }
            }
            if (domain_not_used_flag == 1)
            {
                to.clear();
                break;
            }
        }
        if (domain_not_used_flag == 0)
        {
            to.print();
        }
    }
    //to.print();
    return;
}

void showHostDebug(NODEMNG_SHM *pshm, CTableOut &to, char *hostname)
{
    int i;
    HOST_ENTRY_PUBLIC *pentry_public = NULL;
    bool islocalhost = false;
    if (strcmp(hostname, pshm->hostname) == 0) //��ʾ�Ǳ���
    {
        pentry_public = &pshm->nodemng_public.localhost;
        islocalhost = true;
    }
    else
    {
        for (i = 0; i < g_node_list.size(); i++)
        {
            if (pshm->nodemng_public.neighbors[i].usage != 1)
            {
                continue;
            }
            if (strcmp(hostname, pshm->nodemng_public.neighbors[i].hostname) == 0)
            {
                pentry_public = &pshm->nodemng_public.neighbors[i];
                break;
            }
        }
    }
    if (pentry_public == NULL)
    {
        return;
    }
    printf("\n");
    printf("����[%s]Ӧ����Ϣ:\n", hostname);
    if ((pentry_public->host_info & NETSTATUS_MASK) == NETSTATUS_BAD)
    {
        printf("�������\n");
    }
    else
    {
        printf("��������\n");
    }
    printf("Note��\n");
    printf("����ͨ��״̬�� 0������1����\n");
    printf("\n");
    printf("�����ӳ�״̬�� 2�����ӳ�������0����ӳ�\n");
    printf("\n");
    printf("Ӧ��״̬��1������2������3������4ǿ����5ǿ����6ֹͣ��15���ϣ�>16���̹���\n");
    printf("\n");

    to.clear();

    vector<CTableOut::TABLE_INFO> tis;
    CTableOut::TABLE_INFO ti;
    ti.head_name = "Ӧ����";
    ti.data_type = CTableOut::D_TEXT;
    tis.push_back(ti);

    ti.head_name = "���ȼ�";
    ti.data_type = CTableOut::D_INT;
    tis.push_back(ti);

    ti.head_name = "Ӧ��״̬";
    ti.data_type = CTableOut::D_TEXT;
    tis.push_back(ti);

    ti.head_name = "����ͨ��״̬";
    ti.data_type = CTableOut::D_TEXT;
    tis.push_back(ti);

    ti.head_name = "�����ӳ�״̬";
    ti.data_type = CTableOut::D_TEXT;
    tis.push_back(ti);

    to.setTable(tis);
    printf("\n");
    printf("PUBLICӦ�ã�\n");

    string hmiapp = "PUBLIC";
    to.setItem(0, 0, hmiapp.c_str());
    to.setItem(0, 1,  pentry_public->app_order);
    to.setItem(0, 2,  pentry_public->app_info);
    to.setItem(0, 3,  pentry_public->host_info);
    to.setItem(0, 4,  pentry_public->extra_info);

    //if((pentry_public->app_info&PROCESS_MASK) == PROCESS_OK)
    //{
    //  switch(pentry_public->app_info&RUN_MASK)
    //  {
    //  case RUN_START:
    //      to.setItem(0, 2, "����");
    //      break;
    //  case RUN_BACK:
    //      to.setItem(0, 2, "����");
    //      break;
    //  case RUN_DUTY:
    //      to.setItem(0, 2, "����");
    //      break;
    //  case RUN_FORCE_DUTY:
    //      to.setItem(0, 2, "ǿ������");
    //      break;
    //  case RUN_FORCE_BACK:
    //      to.setItem(0, 2, "ǿ�Ʊ���");
    //      break;
    //  case RUN_STOP:
    //      to.setItem(0, 2, "ֹͣ");
    //      break;
    //  case RUN_FAIL:
    //      to.setItem(0, 2, "����");
    //      break;
    //  default:
    //      to.setItem(0, 2, "����");
    //      break;
    //  }
    //}
    //else
    //  to.setItem(0, 2, "���̹���");
    to.print();

    printf("\n");

    int m;
    int app_pos;
    for (m = 0; m < g_domain_list.size(); m++)
    {
        //        int domain_not_used_flag = 0;
        to.clear();

        HOST_ENTRY *pentry = NULL;
        for (i = 0; i < MAX_NODE_NUM; i++)
        {
            if (pshm->nodemng_domain[m].usage != 1)
            {
                continue;
            }
            if (islocalhost)
            {
                if (strcmp(hostname, pshm->nodemng_domain[m].localhost.hostname) == 0)
                {
                    pentry = &pshm->nodemng_domain[m].localhost;
                    break;
                }
            }
            else
            {
                if (strcmp(hostname, pshm->nodemng_domain[m].neighbors[i].hostname) == 0)
                {
                    pentry = &pshm->nodemng_domain[m].neighbors[i];
                    break;
                }
            }
        }
        if (i == MAX_NODE_NUM)
        {
            continue;
        }

        vector<CTableOut::TABLE_INFO> tis;
        CTableOut::TABLE_INFO ti;
        ti.head_name = "Ӧ����";
        ti.data_type = CTableOut::D_TEXT;
        tis.push_back(ti);

        ti.head_name = "���ȼ�";
        ti.data_type = CTableOut::D_INT;
        tis.push_back(ti);

        ti.head_name = "Ӧ��״̬";
        ti.data_type = CTableOut::D_TEXT;
        tis.push_back(ti);

        ti.head_name = "����ͨ��״̬";
        ti.data_type = CTableOut::D_TEXT;
        tis.push_back(ti);

        ti.head_name = "�����ӳ�״̬";
        ti.data_type = CTableOut::D_TEXT;
        tis.push_back(ti);

        to.setTable(tis);
        if (m != 0)
        {
            printf("\n");
        }
        printf("��[%d]Ӧ����Ϣ��\n", g_domain_list[m]);
        int nret = g_si.GetAppInfoByDomainId(g_appno_list, g_domain_list[m]);
        if (nret < 0)
        {
            printf("g_si.GetAppInfoByDomainId() domain_id=%d error", g_domain_list[m]);
            _exit(-1);
        }
        for (i = 0; i < g_appno_list.size(); i++) //�����������Ӧ�ã�������
        {
            app_pos = g_appno_list[i];
            if (app_pos == PUBLIC)
            {
                continue;
            }
            string hmiapp;
            if (g_si.GetAppNameByNo(app_pos, hmiapp) < 0)
            {
                continue;
            }
            to.setItem(i, 0, hmiapp.c_str());
            to.setItem(i, 1,  pentry->app_order[app_pos]);
            to.setItem(i, 2,  pentry->app_info[app_pos]);
            to.setItem(i, 3,  pentry->host_info);
            to.setItem(i, 4,  pentry->extra_info);

            //if((pentry->app_info[app_pos]&PROCESS_MASK) == PROCESS_OK)
            //{
            //  switch(pentry->app_info[app_pos]&RUN_MASK)
            //  {
            //  case RUN_START:
            //      to.setItem(i, 2, "����");
            //      break;
            //  case RUN_BACK:
            //      to.setItem(i, 2, "����");
            //      break;
            //  case RUN_DUTY:
            //      to.setItem(i, 2, "����");
            //      break;
            //  case RUN_FORCE_DUTY:
            //      to.setItem(i, 2, "ǿ������");
            //      break;
            //  case RUN_FORCE_BACK:
            //      to.setItem(i, 2, "ǿ�Ʊ���");
            //      break;
            //  case RUN_STOP:
            //      to.setItem(i, 2, "ֹͣ");
            //      break;
            //  case RUN_FAIL:
            //      to.setItem(i, 2, "����");
            //      break;
            //  default:
            //      to.setItem(i, 2, "����");
            //      break;
            //  }
            //}
            //else
            //  to.setItem(i, 2, "���̹���");
        }
        to.print();
    }
    return;
}



void showHost(NODEMNG_SHM *pshm, CTableOut &to, char *hostname)
{
    int i;
    HOST_ENTRY_PUBLIC *pentry_public = NULL;
    bool islocalhost = false;
    if (strcmp(hostname, pshm->hostname) == 0) //��ʾ�Ǳ���
    {
        pentry_public = &pshm->nodemng_public.localhost;
        islocalhost = true;
    }
    else
    {
        for (i = 0; i < g_node_list.size(); i++)
        {
            if (pshm->nodemng_public.neighbors[i].usage != 1)
            {
                continue;
            }
            if (strcmp(hostname, pshm->nodemng_public.neighbors[i].hostname) == 0)
            {
                pentry_public = &pshm->nodemng_public.neighbors[i];
                break;
            }
        }
    }
    if (pentry_public == NULL)
    {
        return;
    }
    printf("\n");
    printf("����[%s]Ӧ����Ϣ:\n", hostname);
    if ((pentry_public->host_info & NETSTATUS_MASK) == NETSTATUS_BAD)
    {
        cout << "�������" << endl;
    }
    else
    {
        cout << "��������" << endl;
    }

    to.clear();

    vector<CTableOut::TABLE_INFO> tis;
    CTableOut::TABLE_INFO ti;
    ti.head_name = "Ӧ����";
    ti.data_type = CTableOut::D_TEXT;
    tis.push_back(ti);

    ti.head_name = "���ȼ�";
    ti.data_type = CTableOut::D_INT;
    tis.push_back(ti);

    ti.head_name = "״̬";
    ti.data_type = CTableOut::D_TEXT;
    tis.push_back(ti);

    to.setTable(tis);
    printf("\n");
    printf("PUBLICӦ�ã�\n");

    string hmiapp = "PUBLIC";
    to.setItem(0, 0, hmiapp.c_str());
    to.setItem(0, 1,  pentry_public->app_order);
    if ((pentry_public->app_info & PROCESS_MASK) == PROCESS_OK)
    {
        switch (pentry_public->app_info & RUN_MASK)
        {
        case RUN_START:
            to.setItem(0, 2, "����");
            break;
        case RUN_BACK:
            to.setItem(0, 2, "����");
            break;
        case RUN_DUTY:
            to.setItem(0, 2, "����");
            break;
        case RUN_FORCE_DUTY:
            to.setItem(0, 2, "ǿ������");
            break;
        case RUN_FORCE_BACK:
            to.setItem(0, 2, "ǿ�Ʊ���");
            break;
        case RUN_STOP:
            to.setItem(0, 2, "ֹͣ");
            break;
        case RUN_FAIL:
            to.setItem(0, 2, "����");
            break;
        default:
            to.setItem(0, 2, "����");
            break;
        }
    }
    else
    {
        to.setItem(0, 2, "���̹���");
    }
    to.print();

    printf("\n");

    int m;
    int app_pos;
    for (m = 0; m < g_domain_list.size(); m++)
    {
        //        int domain_not_used_flag = 0;
        to.clear();

        HOST_ENTRY *pentry = NULL;
        for (i = 0; i < MAX_NODE_NUM; i++)
        {
            if (pshm->nodemng_domain[m].usage != 1)
            {
                continue;
            }
            if (islocalhost)
            {
                if (strcmp(hostname, pshm->nodemng_domain[m].localhost.hostname) == 0)
                {
                    pentry = &pshm->nodemng_domain[m].localhost;
                    break;
                }
            }
            else
            {
                if (strcmp(hostname, pshm->nodemng_domain[m].neighbors[i].hostname) == 0)
                {
                    pentry = &pshm->nodemng_domain[m].neighbors[i];
                    break;
                }
            }
        }
        if (i == MAX_NODE_NUM)
        {
            continue;
        }

        vector<CTableOut::TABLE_INFO> tis;
        CTableOut::TABLE_INFO ti;
        ti.head_name = "Ӧ����";
        ti.data_type = CTableOut::D_TEXT;
        tis.push_back(ti);

        ti.head_name = "���ȼ�";
        ti.data_type = CTableOut::D_INT;
        tis.push_back(ti);

        ti.head_name = "״̬";
        ti.data_type = CTableOut::D_TEXT;
        tis.push_back(ti);

        to.setTable(tis);
        if (m != 0)
        {
            printf("\n");
        }
        printf("��[%d]Ӧ����Ϣ��\n", g_domain_list[m]);
        int nret = g_si.GetAppInfoByDomainId(g_appno_list, g_domain_list[m]);
        if (nret < 0)
        {
            printf("g_si.GetAppInfoByDomainId() domain_id=%d error", g_domain_list[m]);
            _exit(-1);
        }
        for (i = 0; i < g_appno_list.size(); i++) //�����������Ӧ�ã�������
        {
            app_pos = g_appno_list[i];
            if (app_pos == PUBLIC)
            {
                continue;
            }
            string hmiapp;
            if (g_si.GetAppNameByNo(app_pos, hmiapp) < 0)
            {
                continue;
            }
            to.setItem(i, 0, hmiapp.c_str());
            to.setItem(i, 1,  pentry->app_order[app_pos]);
            if ((pentry->app_info[app_pos]&PROCESS_MASK) == PROCESS_OK)
            {
                switch (pentry->app_info[app_pos]&RUN_MASK)
                {
                case RUN_START:
                    to.setItem(i, 2, "����");
                    break;
                case RUN_BACK:
                    to.setItem(i, 2, "����");
                    break;
                case RUN_DUTY:
                    to.setItem(i, 2, "����");
                    break;
                case RUN_FORCE_DUTY:
                    to.setItem(i, 2, "ǿ������");
                    break;
                case RUN_FORCE_BACK:
                    to.setItem(i, 2, "ǿ�Ʊ���");
                    break;
                case RUN_STOP:
                    to.setItem(i, 2, "ֹͣ");
                    break;
                case RUN_FAIL:
                    to.setItem(i, 2, "����");
                    break;
                default:
                    to.setItem(i, 2, "����");
                    break;
                }
            }
            else
            {
                to.setItem(i, 2, "���̹���");
            }
        }
        to.print();
    }
    return;
}
//
//void showDomain(NODEMNG_SHM* pshm, CTableOut &to, int domain_id)
//{
//  cout << "��[" << domain_id << "]Ӧ����Ϣ��" << endl;
//  to.clear();
//
//  vector<CTableOut::TABLE_INFO> tis;
//  CTableOut::TABLE_INFO ti;
//
//  ti.head_name = "Ӧ����";
//  ti.data_type = CTableOut::D_TEXT;
//  tis.push_back(ti);
//
//  ti.head_name = "����";
//  ti.data_type = CTableOut::D_TEXT;
//  tis.push_back(ti);
//
//  to.setTable(tis);
//
//  int i, j, line;
//  string app_name;
//  for(i=0, line=0; i<MAX_DOMAIN_NUM; i++)
//  {
//      if(pshm->remote_domains[i].usage == 0)
//          continue;
//      if(pshm->remote_domains[i].domain_id != domain_id)
//          continue;
//      for(j=0; j<MAX_APP_NUM; j++)
//      {
//          if(pshm->remote_domains[i].duty_host[j].usage == 0)
//              continue;
//          if(1<<j == AP_BASE_SERVICE)
//              continue;
//          //if(GetAppNameByNo(1<<j, appname) == -1)
//          //  continue;
//          //to.setItem(line, 0, appname.c_str());
//          if(g_si.GetAppNameByNo(1<<j, app_name) < 0)
//              continue;
//          string hmiapp =app_name;
//          //if (g_si.GetAppHmiENByName(app_name, hmiapp) < 0)
//          //  continue;
//          to.setItem(line, 0, hmiapp.c_str());
//          to.setItem(line, 1, pshm->remote_domains[i].duty_host[j].hostname);
//          line++;
//      }
//      break;
//  }
//  to.print();
//  return;
//}
//
//
//
//void showDomainAll(NODEMNG_SHM* pshm, CTableOut &to, int domain_id)
//{
//  //cout << "��[" << domain_id << "]Ӧ����Ϣ��" << endl;
//  to.clear();
//
//  vector<CTableOut::TABLE_INFO> tis;
//  CTableOut::TABLE_INFO ti;
//
//  ti.head_name = "Ӧ����";
//  ti.data_type = CTableOut::D_TEXT;
//  tis.push_back(ti);
//
//  ti.head_name = "����";
//  ti.data_type = CTableOut::D_TEXT;
//  tis.push_back(ti);
//
//  to.setTable(tis);
//
//  int i, j, line;
//  string app_name;
//  for(i=0, line=0; i<MAX_DOMAIN_NUM; i++)
//  {
//      if(pshm->remote_domains[i].usage == 0)
//          continue;
//      if(pshm->remote_domains[i].domain_id != domain_id)
//          continue;
//      cout << "��[" << domain_id << "]Ӧ����Ϣ��" << endl;
//      for(j=0; j<MAX_APP_NUM; j++)
//      {
//          if(pshm->remote_domains[i].duty_host[j].usage == 0)
//              continue;
//          if(1<<j == AP_BASE_SERVICE)
//              continue;
//          //if(GetAppNameByNo(1<<j, appname) == -1)
//          //  continue;
//          //to.setItem(line, 0, appname.c_str());
//          if(g_si.GetAppNameByNo(1<<j, app_name) < 0)
//              continue;
//          string hmiapp =app_name;
//          //if (g_si.GetAppHmiENByName(app_name, hmiapp) < 0)
//          //  continue;
//          to.setItem(line, 0, hmiapp.c_str());
//          to.setItem(line, 1, pshm->remote_domains[i].duty_host[j].hostname);
//          line++;
//      }
//      break;
//  }
//  if (i!=MAX_DOMAIN_NUM)
//      to.print();
//  return;
//}

void usage()
{
    //cout << "Usage:" << endl;
    //cout << "  nodemng_show " << endl;
    //cout << "  nodemng_show sgid sergrp_id " << endl;
    printf("Usage:\n");
    printf("  nodemng_show \n");
    printf("  nodemng_show sgid sergrp_id \n");
    printf("  nodemng_show -d domain_id \n");
    //printf("  nodemng_show -n hostname \n");


    //cout << "Usage:" << endl;
    //cout << "  nodemng_show -d [DOMAIN_ID]" << endl;
    //cout << "  nodemng_show -all " << endl;
    //cout << "    If DOMAIN_ID is ignored, local domain information will be shown." << endl;
    //cout << "  nodemng_show -n [NODE_NAME]" << endl;
    //cout << "    If NODE_NAME is ignored, local host information will be shown." << endl;
    //cout << "  nodemng_show" << endl;
    //cout << "    This command is same as nodemng_show -d" << endl;
    return;
}
void print_debug()
{
    CNodeInfo ni;
    if (!ni.init())
    {
        printf("CNodeInfo init error\n");
    }
    printf("*******************************************\n");
    printf("net_num :%d\n", ni.getNICNum());
    printf("---m_nic1_addr:%s---m_nic1_name: %s-----\n", ni.getNIC1Addr(), ni.getNIC1Name());
    printf("---m_nic2_addr:%s---m_nic2_name: %s-----\n", ni.getNIC2Addr(), ni.getNIC2Name());
    printf("*******************************************\n");
}


int main(int argc, char **argv)
{
    rt21_context_init(argc, argv);
    if (rt21_context_sim())//��ѵ̬
    {
        argc = argc - 1; //��������֮��ԭ�����еĶ�������Ҫ�䶯
    }

    //printf("local_packe_size=%d\n",sizeof(NM_LOCAL_PACKET));
    //printf("remote_packe_size=%d\n",sizeof(NM_REMOTE_PACKET));
    //printf("total_packe_size=%d\n",sizeof(HB_LOCAL_TO_SERVER_PACKET));
    g_show_domain_id = -1;
    int isDebug = false;
    int nret;
    if (argc > 4)
    {
        usage();
        return 0;
    }
    if (argc == 4)
    {
        if (strcmp(argv[3], "-v") == 0)
        {
            isDebug = true;
            print_debug();
        }
        else
        {
            usage();
            return 0;
        }
    }
    if (argc == 3)
    {
        if ((strcmp(argv[1], "-n") == 0) || (strcmp(argv[1], "-d") == 0) || (strcmp(argv[1], "sgid") == 0));
        else
        {
            usage();
            return 0;
        }
    }
    if (argc == 2)
    {
        if (strcmp(argv[1], "-help") == 0)
        {
            usage();
            return 0;
        }
        if (strcmp(argv[1], "-v") == 0)
        {
            isDebug = true;
            print_debug();
        }
        else
        {
            usage();
            return 0;
        }
    }

    //if((argc == 2)&&(strcmp(argv[1],"-help")==0))
    //{
    //  usage();
    //  return 0;
    //}

    //if((argc == 2)&&(strcmp(argv[1],"-v")==0))
    //{
    //  isDebug = true;
    //}
    //if((argc == 4)&&(strcmp(argv[3],"-v")==0))
    //{
    //  isDebug = true;
    //}
    pcshm  = new CShm();
    NODEMNG_SHM *pshm = (NODEMNG_SHM *)pcshm->AttachShm("nodemng", sizeof(struct NODEMNG_SHM));
    if (pshm == NULL)
    {
        printf("Attach share memory error\n");
        destroyShm();
        _exit(-1);
    }
	else
	{
		if (pshm->shm_error_flag)
		{
			printf("nodemng share memory is error,suggest to restart system\n");
			destroyShm();
			_exit(-1);
		}
	}
    struct timeb nowb;
    ftime(&nowb);
    if (!isDebug)
    {
        if (g_pt.TimebCheck(&nowb, &pshm->refresh_time,
                            ACTIVE_TIME) >= 0) //��ʾ����3sû��ˢ�£���Ϊ���ݲ��ɿ�
        {
            printf("��Ϣ���ڣ�ϵͳ�����Ѿ�ֹͣ\n");
            destroyShm();
            return 0;
        }
    }
    int sergrp_id = -1;
    if ((argc > 2) && (strcmp(argv[1], "sgid") == 0 ))
    {
        sergrp_id = atoi(argv[2]);
    }
    if ((argc > 2) && (strcmp(argv[1], "-d") == 0 )) //nodemng_show -d domain_id
    {
        g_show_domain_id = atoi(argv[2]);
    }

    if (g_si.Init() < 0)
    {
        printf("g_si.Init() error");
        destroyShm();
        _exit(-1);
    }
    nret = g_si.GetDeployDomainBySgId(g_domain_list, sergrp_id);
    if (nret < 0)
    {
        printf("g_si.GetDeployDomainBySgId() error");
        destroyShm();
        _exit(-1);
    }
    int bb;
    for (bb = 0; bb < g_domain_list.size(); bb++)
    {
        if (g_show_domain_id == g_domain_list[bb])
        {
            break;
        }
    }
    if ((bb == g_domain_list.size()) && (g_show_domain_id != -1))
    {
        printf("�ڱ������������Ҳ�����domain_id(%d)\n", g_show_domain_id);
        destroyShm();
        _exit(-1);
    }
    nret = g_si.GetAppServerNodeBySgId(g_node_list, sergrp_id);
    if (nret < 0)
    {
        printf("g_si.GetAppServerNodeBySgId() error");
        destroyShm();
        _exit(-1);
    }
    //printf("-------------sergrp_id=%d\n",sergrp_id);
    //for (int a=0;a<g_node_list.size();a++)
    //{
    //  printf("++++++++++node_name=%s++++++++++++\n",(g_node_list[a]).c_str());
    //}

    nret = g_si.GetLocalSgId(g_local_sergrp_id);
    if (nret < 0)
    {
        printf("g_si.GetLocalSgId() error");
        destroyShm();
        exit(-1);
    }

    //nret = g_si.GetAppInfoBySgId(g_appno_list,sergrp_id);
    //if (nret <0)
    //{
    //  printf("g_si.GetAppInfoBySgId() error");
    //  exit(-1);
    //}
    //printf("segrp_id=%d\n",sergrp_id);
    //for (int i=0;i<g_appno_list.size();i++)
    //{
    //  printf("app_id =%d\n",g_appno_list[i]);
    //}

    CTableOut to;
    int i;
    for (i = 0; i < pshm->domain_count; i++)
    {
        if (pshm->nodemng_domain[i].usage == 0)
        {
            continue;
        }
        if ((pshm->nodemng_domain[i].localhost.host_info & NETSTATUS_MASK) == NETSTATUS_OK) //ûһ����
        {
            printf("��ǰ����״̬������\n");
            //cout << "��ǰ����״̬������" << endl;
            break;
        }
    }
    if (i == pshm->domain_count)
    {
        printf("��ǰ����״̬������\n");
        //cout << "��ǰ����״̬������" << endl;
    }
    if (sergrp_id == -1)
    {
        printf("��ǰ������id:[%d]\n", g_local_sergrp_id);
    }
    //cout << "��ǰ������id:[" << g_local_sergrp_id << "]" << endl;
    else
    {
        printf("������id:[%d]\n", sergrp_id);
    }
    //cout << "������id:[" << sergrp_id << "]" << endl;
    if (g_node_list.size() > MAX_NODE_NUM)
    {
        printf("��ǰ��������ڵ�������������(8)\n");
        //cout << "��ǰ��������ڵ�������������(8)" << endl;
        return 0;
    }
    if (argc == 1) // nodemng_show
    {
        showLocalDomain(pshm, to);
    }
    if ((isDebug) && (argc == 2)) // nodemng_show -v
    {
        showLocalDomain(pshm, to);
    }
    else if ((argc > 2) && (strcmp(argv[1], "sgid") == 0 )) //nodemng_show sgid 1 [-v]
    {
        if (g_local_sergrp_id == sergrp_id)
        {
            showLocalDomain(pshm, to);
        }
        else
        {
            showOtherSerGroup(pshm, to, sergrp_id);
        }
    }
    else if ((argc > 2) && (strcmp(argv[1], "-d") == 0 )) //nodemng_show -d 1 [-v]
    {
        showLocalDomain(pshm, to);
    }
    else if ((argc > 2) && (strcmp(argv[1], "-n") == 0 )) //nodemng_show -n lib/localhost [-v]
    {
        char host_name[64];
        strcpy(host_name, argv[2]);
        if ((strcmp(host_name, "localhost") == 0 ))
        {
            CNodeInfo ni;
            if (!ni.init())
            {
                printf("CNodeInfo init error\n");
            }
            strcpy(host_name, ni.getHostname());
        }
        int nn;
        for (nn = 0; nn < g_node_list.size(); nn++)
        {
            if (strcmp(host_name, g_node_list[nn].c_str()) == 0)
            {
                if (!isDebug)//nodemng_show -n lib
                {
                    showHost(pshm, to, host_name);
                }
                else
                {
                    showHostDebug(pshm, to, host_name);    //nodemng_show -n lib -v
                }
                break;
            }
        }
        if (nn == g_node_list.size())// ��ʾ����������û�ҵ��˽ڵ�
        {
            printf("�Ҳ����˽ڵ�(%s)�ڵ�ǰ��������(%d)\n", argv[2], g_local_sergrp_id);
            destroyShm();
            return 0;
        }
    }

    //else
    //{
    //  if(strcmp(argv[1], "-d") == 0)  // nodemng_show -d [DOMAIN_ID]
    //  {
    //      if((argc == 2) || (atoi(argv[2]) == pshm->local_domain_id))
    //          showLocalDomain(pshm, to);
    //      else
    //          showDomain(pshm, to, atoi(argv[2]));
    //  }
    //  else if(strcmp(argv[1], "-n") == 0)  // nodemng_show -n [NODE_NAME]
    //  {
    //      if(argc == 2)
    //          showHost(pshm, to, pshm->localhost.hostname);
    //      else
    //          showHost(pshm, to, argv[2]);
    //  }
    //  else if(strcmp(argv[1], "-all") == 0)  // nodemng_show -all
    //  {
    //      showLocalDomain(pshm, to);
    //      for(int i=0; i<MAX_DOMAIN_NUM; i++)
    //      {
    //          if(pshm->remote_domains[i].domain_id == pshm->local_domain_id)
    //              continue;
    //          /*if(pshm->remote_domains[i].usage == 0)
    //              continue;*/
    //               showDomainAll(pshm, to, i);
    //      }
    //  }
    //  else
    //      usage();
    //}

    destroyShm();
    return 0;
}
