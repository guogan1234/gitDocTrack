/**************************************
* @file libnodemng.cpp
* @brief CServicesManage interface
* @author lib
* @version 1.0
* @date 19-Mar-2013
* @log:42000~~~42500
***************************************/
#include "nodemng_def.h"
#include "libnodemng.h"
#include "liblogger.h"
#include <list>
using namespace std;
#define MAX_NODE_ORDER 100

#define OVER_TIME 4000
/***************************
      log:42000~~~42009
***************************/
void CServicesManage::init()
{
    if (!m_init)
    {
        rt21_context_sim();
        m_pshm = NULL;
        m_pcshm = new CShm();
        if (m_pcshm == NULL)
        {
            if (!log_printf(LOG_ERROR, 42000, "Create CShm error"))
            {
                printf("Create CShm error\n");
            }
            _exit(-1);
        }
        m_pshm = m_pcshm->AttachShm("nodemng", sizeof(struct NODEMNG_SHM), rt21::SHM_READONLY);
        if (m_pshm == NULL)
        {
            if (!log_printf(LOG_ERROR, 42001, "Attach ShareMemory nodemng error"))
            {
                printf("Attach ShareMemory nodemng error.\n");
            }
            _exit(-1);
        }

        if (!m_ni.init())
        {
            if (!log_printf(LOG_ERROR, 42002, "CServicesManage Cnode init error"))
            {
                printf("CServicesManage Cnode init error.\n");
            }
            _exit(-1);
        }
        if (m_si.Init() < 0)
        {
            if (!log_printf(LOG_ERROR, 42003, "CServicesManage CSysInfo Init error"))
            {
                printf("CServicesManage CSysInfo Init error.\n");
            }
            _exit(-1);
        }
        m_init = true;
    }
}

CServicesManage::CServicesManage()
{
    m_init = false;
    m_pshm = NULL;
    m_pcshm = NULL;
}
/***************************
      log:42010~~~42019
***************************/
CServicesManage::~CServicesManage()
{
    if (NULL != m_pcshm)
    {
        delete m_pcshm;
        m_pcshm = NULL;
    }
    log_printf(LOG_SENSOR, 42004, "CServiceManage destruction success");
}

/***************************
      log:42020~~~42039
***************************/
int CServicesManage::IsOnDuty( int app_id , int domain_id)
{
    init();
    if (app_id < 0)
    {
        log_printf(LOG_WARN, 42005, "app_id is wrong app_id =%d", app_id);
        return -1;
    }
    if (m_pshm == NULL)
    {
        log_printf(LOG_WARN, 42006, "CServicesManage::IsOnDuty: share memory  'nodemng' is NULL");
        return -1;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);
    // NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    struct timeb nowb;
    ftime(&nowb);
    if (m_pt.TimebCheck(&nowb, &pshm->refresh_time,
                        OVER_TIME) >= 0) //��ʾ����3sû��ˢ�£���Ϊ���ݲ��ɿ�
    {
        log_printf(LOG_WARN, 42007,
                   "CServicesManage::IsOnDuty: Share memory has not been refreshed for long");
        return -1;
    }
    if (pshm->shm_error_flag)
    {
        log_printf(LOG_WARN, 42008, "CServicesManage::IsOnDuty: Share memory in nodemng is error");
        return -1;
    }
    for (int i = 0; i < pshm->domain_count; i++)
    {
        if (pshm->nodemng_domain[i].usage == 0) //��ǰ�򲻿���continue��
        {
            continue;
        }
        if (pshm->nodemng_domain[i].local_domain_id != domain_id) //��ǰ�����������Ӧ��
        {
            continue;
        }
        if (pshm->nodemng_domain[i].local_domain_apps[app_id].usage == 0) //��ǰӦ�ò�����
        {
            log_printf(LOG_SENSOR, 42009,
                       "CServicesManage::IsOnDuty:  the app %d in this domain %d is not be used", app_id, domain_id);
            return 0;   //�ҵ������ĳ�򣬵�����Ӧ�ò�����
        }
        if ((pshm->nodemng_domain[i].localhost.app_info[app_id]&RUN_MASK) == RUN_STOP) //��ʾ��ͣ��״̬
        {
            log_printf(LOG_SENSOR, 42010,
                       "CServicesManage::IsOnDuty:  current domain(%d) and app_id(%d) is Run.....  return Stop!",
                       domain_id, app_id);
            return 3;
        }
        if (pshm->nodemng_domain[i].local_domain_apps[app_id].duty_host == -1)//�ǵ�ǰӦ������
        {
            log_printf(LOG_SENSOR, 42011,
                       "CServicesManage::IsOnDuty:  current domain(%d) and app_id(%d) on this node is On duty!", domain_id,
                       app_id);
            return 1;
        }
        if (pshm->nodemng_domain[i].local_domain_apps[app_id].duty_host != -2)//��ʾ�Ǳ���
        {
            log_printf(LOG_SENSOR, 42012,
                       "CServicesManage::IsOnDuty:  current domain(%d) and app_id(%d) on this node is On back!", domain_id,
                       app_id);
            return 2;
        }
        else
        {
            log_printf(LOG_DEBUG, 42013,
                       "CServicesManage::IsOnDuty:  current domain(%d) and app_id(%d) on this node can not get its status.....return 0",
                       domain_id, app_id);
            return 0;
        }
    }
    return 0;
}

/***************************
      log:42040~~~42059
***************************/
int CServicesManage::IsPublicOnDuty(int SerGrp_id)
{
    init();
    if (SerGrp_id != -1)
    {
        int ret;
        int local_sergrp_id ;
        ret = m_ni.getLocalServerGroupId(local_sergrp_id);
        if (ret < 0)
        {
            log_printf(LOG_WARN, 42014,
                       "CServicesManage::IsPublicOnDuty:  CNodeInfo getLocalServerGroupId error");
            return -1;
        }
        if (SerGrp_id != local_sergrp_id) //��ȡ��������id���ǵ�ǰ�������飬return 0
        {
            log_printf(LOG_WARN, 42015,
                       "CServicesManage::IsPublicOnDuty:  this SerGrp_id(%d) is not local_sergrp_id(%d)", SerGrp_id,
                       local_sergrp_id);
            return 0;
        }
    }
    if (m_pshm == NULL)
    {
        log_printf(LOG_WARN, 42016, "CServicesManage::IsPublicOnDuty:  Share memory  'nodemng' is NULL");
        return -1;
    }
    struct timeb nowb;
    ftime(&nowb);
    if (m_pt.TimebCheck(&nowb, &(reinterpret_cast<NODEMNG_SHM *>(m_pshm))->refresh_time,
                        OVER_TIME) >= 0) //��ʾ����3sû��ˢ�£���Ϊ���ݲ��ɿ�
    {
        log_printf(LOG_WARN, 42017,
                   "CServicesManage::IsPublicOnDuty:  Share memory has not been refreshed for long");
        return -1;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    // NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;

    if (pshm->shm_error_flag)
    {
        log_printf(LOG_WARN, 42018, "CServicesManage::IsPublicOnDuty :  Share memory in nodemng is error");
        return -1;
    }
    //if (pshm->nodemng_public.usage ==0)
    //  return 0;
    //if (pshm->nodemng_public.localhost.usage ==0)
    //  return 0;
    if (pshm->nodemng_public.local_domain_apps.duty_host == -1)
    {
        return 1;
    }
    //else if (pshm->nodemng_public.local_domain_apps.duty_host != -2)//��ʾ�Ǳ���
    //{
    //    return 0;
    //}
    else
    {
        return 0;
    }
}

/***************************
      log:42060~~~42079
***************************/
int CServicesManage::RequestPublicService(int policy, char *host_name, int SerGrp_id)
{
    init();
    int local_sergrp_id ;
    int ret;
    ret = m_ni.getLocalServerGroupId(local_sergrp_id);
    if (ret < 0)
    {
        log_printf(LOG_WARN, 42019, "CNodeInfo getLocalServerGroupId error");
        return -1;
    }
    if (m_pshm == NULL)
    {
        log_printf(LOG_WARN, 42020, "m_pshm is NULL");
        return -1;
    }
    struct timeb nowb;
    ftime(&nowb);
    if (m_pt.TimebCheck(&nowb, &(reinterpret_cast<NODEMNG_SHM *>(m_pshm))->refresh_time,
                        OVER_TIME) >= 0) //��ʾ����3sû��ˢ�£���Ϊ���ݲ��ɿ�
    {
        log_printf(LOG_DEBUG, 42021, "Share memory has not been refreshed for long");
        return -1;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    // NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    if (pshm->shm_error_flag)
    {
        log_printf(LOG_WARN, 42022, "Share memory in nodemng is error");
        return -1;
    }
    if ((SerGrp_id == -1) || (SerGrp_id == local_sergrp_id)) //��ʾ��ȡ�����������public����
    {
        //if (pshm->nodemng_public.usage==0)
        //  return -1;
        //if (pshm->nodemng_public.localhost.usage==0)
        //  return -1;
        //if((pshm->nodemng_public.localhost.host_info&NETSTATUS_MASK) != NETSTATUS_OK)
        //  return -1;
        if (policy == REQUEST_DUTY)
        {
            if (pshm->nodemng_public.local_domain_apps.usage != 1)
            {
                return 0;
            }
            if (pshm->nodemng_public.local_domain_apps.duty_host == -1)
            {
                strcpy(host_name, pshm->nodemng_public.localhost.hostname);
                return 1;
            }
            else if (pshm->nodemng_public.local_domain_apps.duty_host != -2)
            {
                strcpy(host_name,
                       pshm->nodemng_public.neighbors[pshm->nodemng_public.local_domain_apps.duty_host].hostname);
                return 1;
            }
            else
            {
                return -1;
            }
        }
        else if (policy == REQUEST_BACK)
        {
            if (pshm->nodemng_public.local_domain_apps.usage)
            {
                if (pshm->nodemng_public.local_domain_apps.standby_host[0] != -2)
                {
                    if (pshm->nodemng_public.local_domain_apps.standby_host[0] == -1)
                    {
                        strcpy(host_name, pshm->nodemng_public.localhost.hostname);
                        return 1;
                    }
                    else
                    {
                        strcpy(host_name,
                               pshm->nodemng_public.neighbors[pshm->nodemng_public.local_domain_apps.standby_host[0]].hostname);
                        return 1;
                    }
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                return -1;
            }
        }
    }
    else//��ȡ�������������public������Ϣ
    {
        if (policy != REQUEST_DUTY)//��������ȡ������Ϣ
        {
            log_printf(LOG_WARN, 42023, "Need to require REQUEST_BACK not from local ,but from sergrp (%d)",
                       SerGrp_id);
            return -1;
        }
        else
        {
            for (int i = 0; i < MAX_SERGRP_NUM; i++)
            {
                if (pshm->remote_sergrp[i].usage == 0) //��ǰ�������鲻����continue��
                {
                    continue;
                }
                if (pshm->remote_sergrp[i].sergrp_id != SerGrp_id) //��ǰ�������鲻���������Ӧ�����
                {
                    continue;
                }
                if (pshm->remote_sergrp[i].remote_public.usage == 0)
                {
                    return -1;
                }
                else
                {
                    strcpy(host_name, pshm->remote_sergrp[i].remote_public.duty_hostname);
                    return 1;
                }
            }
            log_printf(LOG_WARN, 42024, "Can not find duty_host,maybe from serGrp(%d) do not have public host",
                       SerGrp_id);
            return 0;
        }
    }
    return 1;
}
/***************************
      log:42080~~~42099
***************************/
int CServicesManage::GetAppActiveNodes( int app_id, int domain_id, vector<string> &node_name)
{
    init();
    if (app_id < 0)
    {
        log_printf(LOG_WARN, 42025, "app_id is wrong app_id =%d", app_id);
        return -1;
    }
    if (m_pshm == NULL)
    {
        log_printf(LOG_WARN, 42026, "m_pshm is NULL");
        return -1;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;

    struct timeb nowb;
    ftime(&nowb);
    if (m_pt.TimebCheck(&nowb, &(reinterpret_cast<NODEMNG_SHM *>(m_pshm))->refresh_time, OVER_TIME) >= 0)
    {
        log_printf(LOG_WARN, 42027, "Share memory has not been refreshed for long");
        return -1;
    }
    node_name.clear();
    if (pshm->shm_error_flag)
    {
        log_printf(LOG_WARN, 42028, "Share memory in nodemng is error");
        return -1;
    }

    for (int i = 0; i < pshm->domain_count; i++)
    {
        if (pshm->nodemng_domain[i].usage == 0) //��ǰ�򲻿���continue��
        {
            continue;
        }
        if (pshm->nodemng_domain[i].local_domain_id != domain_id) //��ǰ�����������Ӧ��
        {
            continue;
        }
        if (pshm->nodemng_domain[i].local_domain_apps[app_id].usage == 0) //��ǰӦ�ò�����
        {
            log_printf(LOG_WARN, 42029, "Current domain(%d) and app_id(%d) is not run!", domain_id, app_id);
            return 0;   //�ҵ�ĳ����ĳӦ�ò�����
        }
        if (pshm->nodemng_domain[i].local_domain_apps[app_id].duty_host ==
                -1)//��ǰ������������ĳ��ĳӦ������
        {
            node_name.push_back(pshm->nodemng_domain[i].localhost.hostname);
        }
        else if (pshm->nodemng_domain[i].local_domain_apps[app_id].duty_host !=
                 -2) //��ǰ����������ĳ��ĳӦ������, �����Ǳ���
        {
            node_name.push_back(
                pshm->nodemng_domain[i].neighbors[pshm->nodemng_domain[i].local_domain_apps[app_id].duty_host].hostname);
        }
        for (int j = 0; j < MAX_NODE_NUM; j++)
        {
            if (pshm->nodemng_domain[i].local_domain_apps[app_id].standby_host[j] == -2) //��ʾ��λ�ýڵ���Ч
            {
                break;
            }
            if (pshm->nodemng_domain[i].local_domain_apps[app_id].standby_host[j] == -1) //������Ϣ���빲���ڴ�
            {
                node_name.push_back(pshm->nodemng_domain[i].localhost.hostname);
            }
            else//����λ�õĽڵ���빲���ڴ�
            {
                node_name.push_back(
                    pshm->nodemng_domain[i].neighbors[pshm->nodemng_domain[i].local_domain_apps[app_id].standby_host[j]].hostname);
            }
        }
    }
    return (node_name.size());
}
/***************************
      log:42100~~~42119
***************************/
int CServicesManage::GetActiveAppsInDomain( vector<int> &app_id , int domain_id)
{
    init();
    if (m_pshm == NULL)
    {
        log_printf(LOG_WARN, 42030, "m_pshm is NULL");
        return -1;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;

    struct timeb nowb;
    ftime(&nowb);
    if (m_pt.TimebCheck(&nowb, &pshm->refresh_time, OVER_TIME) >= 0)
    {
        log_printf(LOG_WARN, 42031, "Share memory has not been refreshed for long");
        return -1;
    }
    if (pshm->shm_error_flag)
    {
        log_printf(LOG_WARN, 42032, "Share memory in nodemng is error");
        return -1;
    }

    app_id.clear();
    for (int i = 0; i < pshm->domain_count; i++)
    {
        if (pshm->nodemng_domain[i].usage == 0) //��ǰ�򲻿���continue��
        {
            continue;
        }
        if (pshm->nodemng_domain[i].local_domain_id != domain_id) //��ǰ�����������Ӧ��
        {
            continue;
        }
        for (int j = 0; j < MAX_APP_NUM; j++)
        {
            if ((pshm->nodemng_domain[i].localhost.app_order[j] != APP_NOT_RUN)
                    && ((pshm->nodemng_domain[i].localhost.app_info[j]&PROCESS_MASK) == PROCESS_OK)
                    && ((pshm->nodemng_domain[i].localhost.host_info & NETSTATUS_MASK) == NETSTATUS_OK)
                    && ((pshm->nodemng_domain[i].localhost.extra_info & NET_OK_DELAY_MASK) == NET_OK_DELAY_CLEAR)
                    && ((pshm->nodemng_domain[i].localhost.app_info[j]&RUN_MASK) != RUN_START)
                    && ((pshm->nodemng_domain[i].localhost.app_info[j]&RUN_MASK) != RUN_STOP)
                    && ((pshm->nodemng_domain[i].localhost.app_info[j]&RUN_MASK) != RUN_FAIL))
            {
                app_id.push_back(j);
            }
        }
    }
    return (app_id.size());
}


/***************************
      log:42120~~~42139
***************************/
int CServicesManage::GetActiveDomainsInApp( vector<int> &domain_id , int app_id)
{
    init();
    if (m_pshm == NULL)
    {
        log_printf(LOG_WARN, 42033, "m_pshm is NULL");
        return -1;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;

    struct timeb nowb;
    ftime(&nowb);
    if (m_pt.TimebCheck(&nowb, &pshm->refresh_time, OVER_TIME) >= 0)
    {
        log_printf(LOG_WARN, 42034, "Share memory has not been refreshed for long");
        return -1;
    }
    int pos = app_id;
    domain_id.clear();
    if (pshm->shm_error_flag)
    {
        log_printf(LOG_WARN, 42035, "Share memory in nodemng is error");
        return -1;
    }

    for (int i = 0; i < pshm->domain_count; i++)
    {
        if (pshm->nodemng_domain[i].usage == 0) //��ǰ�򲻿���continue��
        {
            continue;
        }
        if ((pshm->nodemng_domain[i].localhost.app_order[pos] != APP_NOT_RUN)
                && ((pshm->nodemng_domain[i].localhost.app_info[pos]&PROCESS_MASK) == PROCESS_OK)
                && ((pshm->nodemng_domain[i].localhost.host_info & NETSTATUS_MASK) == NETSTATUS_OK)
                && ((pshm->nodemng_domain[i].localhost.extra_info & NET_OK_DELAY_MASK) == NET_OK_DELAY_CLEAR)
                && ((pshm->nodemng_domain[i].localhost.app_info[pos]&RUN_MASK) != RUN_START)
                && ((pshm->nodemng_domain[i].localhost.app_info[pos]&RUN_MASK) != RUN_STOP)
                && ((pshm->nodemng_domain[i].localhost.app_info[pos]&RUN_MASK) != RUN_FAIL))
        {
            domain_id.push_back(pshm->nodemng_domain[i].local_domain_id);
        }
        //if (pshm->nodemng_domain[i].local_domain_apps[app_id].usage==0)//��ǰӦ�ò�����
        //  continue;
        //if (pshm->nodemng_domain[i].local_domain_apps[app_id].duty_host == -1)//��ǰ�ڵ���ĳ��ĳӦ������
        //{
        //  domain_id.push_back(pshm->nodemng_domain[i].local_domain_id);
        //}
        //else if(pshm->nodemng_domain[i].local_domain_apps[app_id].duty_host != -2)//��ǰ�ڵ㲻��ĳ��ĳӦ������, �����Ǳ���
        //{
        //  domain_id.push_back(pshm->nodemng_domain[i].local_domain_id);
        //}
    }
    return (domain_id.size());
}
/***************************
      log:42140~~~42159
***************************/
int CServicesManage::CheckDomainIsBelongLocalSergrp( int app_id, int domain_id, bool &isbelongflag)
{
    init();
    int ret;
    if (app_id < 0)
    {
        log_printf(LOG_WARN, 42036, "app_id is wrong app_id =%d", app_id);
        return -1;
    }
    if (m_pshm == NULL)
    {
        log_printf(LOG_WARN, 42037, "m_pshm is NULL");
        return -1;
    }

    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    struct timeb nowb;
    ftime(&nowb);
    if (m_pt.TimebCheck(&nowb, &(reinterpret_cast<NODEMNG_SHM *>(m_pshm))->refresh_time, OVER_TIME) >= 0)
    {
        log_printf(LOG_WARN, 42038, "Share memory has not been refreshed for long");
        return -1;
    }
    if (pshm->shm_error_flag)
    {
        log_printf(LOG_WARN, 42039, "Share memory in nodemng is error");
        return -1;
    }
    std::vector<int> domain_ids;
    ret = m_ni.getDomainID(domain_ids);
    if (ret < 0)
    {
        log_printf(LOG_WARN, 42040, "CNodeInfo getDomainID error");
        return -1;
    }

    //�ж�domain�Ƿ�ǰ��������
    int i = 0;
	bool isClientAllDomain=true;
    for (i = 0; i < domain_ids.size(); i++)
    {
        if (domain_ids[i] == domain_id)
        {
            isbelongflag = true;
            break;
        }
		else if (domain_ids[i] !=-1)//
		{
			isClientAllDomain=false;
		}
    }
    if (i == domain_ids.size())
    {
		if (isClientAllDomain)
		{
			isbelongflag = true;
		}
		else
		{
            isbelongflag = false;
		}
    }
    return 1;

}
/***************************
      log:42160~~~42179
***************************/
int CServicesManage::RequestService( int app_id, int policy, char *host_name, int domain_id)
{
    init();
    if (app_id == PUBLIC) //publicӦ��
    {
        int ret;
        int public_sergrp_id;
        ret = m_si.GetSgIdByDomainId(public_sergrp_id, domain_id);
        if (ret < 0)
        {
            log_printf(LOG_WARN, 42041, "RequestService fail....CSysInfo GetSgIdByDomainId error,domain_id=%d",
                       domain_id);
            return -1;
        }
        return (RequestPublicService(policy, host_name, public_sergrp_id));
    }
    int pos = app_id;
    bool BelongLocalSergrp = false;
    int ret;
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);
    ret = CheckDomainIsBelongLocalSergrp(app_id, domain_id, BelongLocalSergrp);
    if (ret < 0)
    {
        return -1;
    }
    //��domain_id�����ڵ�ǰ���������
    int i;
    if (BelongLocalSergrp)
    {
        for (i = 0; i < pshm->domain_count; i++)
        {
            if (pshm->nodemng_domain[i].usage == 0) //��ǰ�򲻿���continue��
            {
                continue;
            }
			if (pshm->nodemng_domain[i].local_domain_id !=domain_id)
			{
				continue;
			}
            //if((pshm->nodemng_domain[i].localhost.host_info&NETSTATUS_MASK) != NETSTATUS_OK)
            //  return -1;
            if (policy == REQUEST_DUTY)
            {
                if (pshm->nodemng_domain[i].local_domain_apps[pos].usage != 1)
                {
                    return 0;
                }
                if (pshm->nodemng_domain[i].local_domain_apps[pos].duty_host == -1)
                {
                    strcpy(host_name, pshm->nodemng_domain[i].localhost.hostname);
                    return 1;
                }
                else if (pshm->nodemng_domain[i].local_domain_apps[pos].duty_host != -2)
                {
                    strcpy(host_name,
                           pshm->nodemng_domain[i].neighbors[pshm->nodemng_domain[i].local_domain_apps[pos].duty_host].hostname);
                    return 1;
                }
                else
                {
                    return -1;
                }
            }
            else if (policy == REQUEST_BACK)
            {
                if (pshm->nodemng_domain[i].local_domain_apps[pos].usage)
                {
                    if (pshm->nodemng_domain[i].local_domain_apps[pos].standby_host[0] != -2)
                    {
                        if (pshm->nodemng_domain[i].local_domain_apps[pos].standby_host[0] == -1)
                        {
                            strcpy(host_name, pshm->nodemng_domain[i].localhost.hostname);
                            return 1;
                        }
                        else
                        {
                            strcpy(host_name,
                                   pshm->nodemng_domain[i].neighbors[pshm->nodemng_domain[i].local_domain_apps[pos].standby_host[0]].hostname);
                            return 1;
                        }
                    }
                    else
                    {
                        return -1;
                    }
                }
                else
                {
                    return -1;
                }
            }
        }
    }
    else//��ȡ�������������Ӧ��������Ϣ
    {
        if (policy != REQUEST_DUTY)//��������ȡ������Ϣ
        {
            log_printf(LOG_WARN, 42042, "Need to require REQUEST_BACK not from local ,but from domain_id (%d)",
                       domain_id);
        }
        else
        {
            for (i = 0; i < MAX_SERGRP_NUM; i++)
            {
                if (pshm->remote_sergrp[i].usage == 0) //��ǰ�������鲻����continue��
                {
                    continue;
                }
                for (int j = 0; j < MAX_DM_IN_SG; j++)
                {
                    if (pshm->remote_sergrp[i].remote_domains[j].usage == 0) //��ʾ�˷�������Ĵ��򲻿���
                    {
                        continue;
                    }
                    if (pshm->remote_sergrp[i].remote_domains[j].domain_id != domain_id) //��ǰ������Ҫȡ��������
                    {
                        continue;
                    }
                    if (pshm->remote_sergrp[i].remote_domains[j].duty_host[pos].usage ==
                            0) //��ʾ�˷�������Ĵ���Ĵ�Ӧ�ò�����
                    {
                        return -1;
                    }
                    else
                    {
                        strcpy(host_name, pshm->remote_sergrp[i].remote_domains[j].duty_host[pos].hostname);
                        return 1;
                    }
                }
            }
            if (i == MAX_SERGRP_NUM)
            {
                log_printf(LOG_WARN, 42043, "domain_id(%d) you need can not get in app_id(%d)for request",
                           domain_id, app_id);
                return -1;
            }
        }
    }
    log_printf(LOG_WARN, 42044, "Current domain(%d) have not run in app(%d)", domain_id, app_id);
    return -1;//��ǰ�����û������
}

/***************************
      log:42180~~~42199
***************************/
int CServicesManage::RequestService( int app_id, int policy, vector<string> &hosts_name,
                                     int domain_id /*= -1*/ )
{
    init();
    int ret;
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);
    int pos = app_id;
    bool BelongLocalSergrp = false;

    if (policy == REQUEST_DUTY)//����ʱhosts_nameֻ��һ��
    {
        char hostname[64];
        ret = RequestService(app_id, policy, hostname, domain_id);
        if (ret > 0)
        {
            string m_host_name(hostname);
            hosts_name.push_back(m_host_name);
            return 1;
        }
        return ret;
    }
    else//�����������domainԶ�˵Ļ�������
    {
        ret = CheckDomainIsBelongLocalSergrp(app_id, domain_id, BelongLocalSergrp);
        if (ret < 0)
        {
            return -1;
        }
        else if (BelongLocalSergrp) //���صı���ȫ������hosts_name
        {
            for (int i = 0; i < pshm->domain_count; i++)
            {
                if (pshm->nodemng_domain[i].usage == 0) //��ǰ�򲻿���continue��
                {
                    continue;
                }
                if (pshm->nodemng_domain[i].local_domain_id != domain_id) //����ͬcontinue
                {
                    continue;
                }
                if ((pshm->nodemng_domain[i].localhost.host_info & NETSTATUS_MASK) != NETSTATUS_OK)
                {
                    return -1;
                }
                int num = 0;
                if (pshm->nodemng_domain[i].local_domain_apps[pos].usage)
                {
                    for (int j = 0; j < MAX_NODE_NUM; j++)
                    {
                        if (pshm->nodemng_domain[i].local_domain_apps[pos].standby_host[j] != -2)
                        {
                            if (pshm->nodemng_domain[i].local_domain_apps[pos].standby_host[j] == -1)
                            {
                                hosts_name.push_back(pshm->nodemng_domain[i].localhost.hostname);
                            }
                            else
                            {
                                hosts_name.push_back(
                                    pshm->nodemng_domain[i].neighbors[pshm->nodemng_domain[i].local_domain_apps[pos].standby_host[j]].hostname);
                            }
                            num++;
                        }
                        else
                        {
                            break;
                        }
                    }
                    return num;
                }
                else
                {
                    return -1;
                }
            }
        }
        else//������������ı���ֱ�ӷ���-1
        {
            log_printf(LOG_WARN, 42045, "domain_id(%d) you need request not on this sergrp", domain_id);
            return -1;
        }

    }
    //string host_name(m_ni.getHostname());
    //hosts_name.push_back(host_name);
    return 1;
}

/***************************
      log:42200~~~42209
***************************/
int CServicesManage::GetDefaultSerGrpID( int &SerGrp_id )
{
    init();
    if (m_pshm == NULL)
    {
        log_printf(LOG_WARN, 42046, "m_pshm is NULL");
        return -1;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    struct timeb nowb;
    ftime(&nowb);
    if (m_pt.TimebCheck(&nowb, &pshm->refresh_time, OVER_TIME) >= 0)
    {
        log_printf(LOG_WARN, 42047, "Share memory has not been refreshed for long");
        return -1;
    }
    if (pshm->shm_error_flag)
    {
        log_printf(LOG_WARN, 42048, "Share memory in nodemng is error");
        return -1;
    }
    SerGrp_id = pshm->local_sergrp_id;
    return 1;
}

//int CServicesManage::reportNetworkInfo( int net_info )
//{
//����������Ҫ�Ժ��ٸ�
//if(m_pshm == NULL)
//{
//  log_printf(LOG_DEBUG, 42049, "m_pshm is NULL");
//  return -1;
//}
//struct timeb nowb;
//ftime(&nowb);
//if(timeb_check(&nowb, &((NODEMNG_SHM*)m_pshm)->refresh_time) >= 0)
//{
//  log_printf(LOG_DEBUG, 42050, "Share memory has not been refreshed for long");
//  return -1;
//}
//NODEMNG_SHM *pshm = (NODEMNG_SHM*)m_pshm;
//if(net_info == 0)
//{
//  log_printf(LOG_NORMAL, 42051, "Network status change to OK");
//  pshm->localhost.host_info = (pshm->localhost.host_info&(~NETSTATUS_MASK)) + NETSTATUS_OK;
//  pshm->localhost.extra_info = (pshm->localhost.host_info&(~NET_OK_DELAY_MASK)) + NET_OK_DELAY_SET;  // Delay some seconds for receive other nodes' information
//}
//else
//{
//  log_printf(LOG_NORMAL, 42052, "Network status change to BAD");
//  pshm->localhost.host_info = (pshm->localhost.host_info&(~NETSTATUS_MASK)) + NETSTATUS_BAD;
//  pshm->localhost.extra_info = (pshm->localhost.host_info&(~NET_OK_DELAY_MASK)) + NET_OK_DELAY_CLEAR;
//}
//return 1;

//}

//int CServicesManage::reportPorcessInfo(int app_id,int domain_id,int process_info)
//{
//  int pos =app_id;
//  if(m_pshm == NULL)
//  {
//      log_printf(LOG_DEBUG, 42053, "m_pshm is NULL");
//      return -1;
//  }
//  struct timeb nowb;
//  ftime(&nowb);
//  if(m_pt.TimebCheck(&nowb, &((NODEMNG_SHM*)m_pshm)->refresh_time,ACTIVE_TIME) >= 0)
//  {
//      log_printf(LOG_WARN, 42054, "Share memory has not been refreshed for long");
//      return -1;
//  }
//  NODEMNG_SHM *pshm = (NODEMNG_SHM*)m_pshm;
//
//  for(int i=0;i<pshm->domain_count;i++)
//  {
//      //�����Ǹ�procmng�ж�isAppRun�õģ��������pshm->process[i].domain_id=NOT_WITH_ANY_DOMAIN
//      if (domain_id ==NOT_WITH_ANY_DOMAIN)
//      {
//          if (pshm->nodemng_domain[i].usage==0)//��ǰ�򲻿���continue��
//              continue;
//          if(pshm->nodemng_domain[i].localhost.app_order[pos] == APP_NOT_RUN)
//              continue;
//          if(((pshm->nodemng_domain[i].localhost.app_info[pos]&RUN_MASK) == RUN_STOP) || ((pshm->nodemng_domain[i].localhost.app_info[pos]&RUN_MASK) == RUN_START)
//              || ((pshm->nodemng_domain[i].localhost.app_info[pos]&RUN_MASK) == RUN_FAIL))  // �޷��ָ���״̬
//              continue;
//          if((process_info == PROC_NORMAL) && ((pshm->nodemng_domain[i].localhost.app_info[pos]&PROCESS_MASK) != PROCESS_OK))
//          {
//              // ������ָ̻��������л�������
//              log_printf(LOG_NORMAL, 42055, "APP %d is changed to BACK dure to process ok", app_id);
//              pshm->nodemng_domain[i].localhost.app_info[pos] = (pshm->nodemng_domain[i].localhost.app_info[pos]&(~RUN_MASK)) + RUN_BACK;
//              pshm->nodemng_domain[i].localhost.app_info[pos] = (pshm->nodemng_domain[i].localhost.app_info[pos]&(~PROCESS_MASK)) + PROCESS_OK;
//              continue;
//          }
//          if((process_info == PROC_ERROR) && ((pshm->nodemng_domain[i].localhost.app_info[pos]&PROCESS_MASK) != PROCESS_BAD))
//          {
//              log_printf(LOG_NORMAL, 42056, "APP %d process BAD", app_id);
//              pshm->nodemng_domain[i].localhost.app_info[pos] = (pshm->nodemng_domain[i].localhost.app_info[pos]&(~PROCESS_MASK)) + PROCESS_BAD;
//              continue;
//          }
//      }
//      else
//      {
//          if (pshm->nodemng_domain[i].usage==0)//��ǰ�򲻿���continue��
//              continue;
//          if (pshm->nodemng_domain[i].local_domain_id!=domain_id)//��ǰ����������
//              continue;
//          if(pshm->nodemng_domain[i].localhost.app_order[pos] == APP_NOT_RUN)
//              return -1;
//          if(((pshm->nodemng_domain[i].localhost.app_info[pos]&RUN_MASK) == RUN_STOP) || ((pshm->nodemng_domain[i].localhost.app_info[pos]&RUN_MASK) == RUN_START)
//              || ((pshm->nodemng_domain[i].localhost.app_info[pos]&RUN_MASK) == RUN_FAIL))  // �޷��ָ���״̬
//              return -1;
//          if((process_info == PROC_NORMAL) && ((pshm->nodemng_domain[i].localhost.app_info[pos]&PROCESS_MASK) != PROCESS_OK))
//          {
//              // ������ָ̻��������л�������
//              log_printf(LOG_NORMAL, 42057, "APP %d is changed to BACK dure to process ok", app_id);
//              pshm->nodemng_domain[i].localhost.app_info[pos] = (pshm->nodemng_domain[i].localhost.app_info[pos]&(~RUN_MASK)) + RUN_BACK;
//              pshm->nodemng_domain[i].localhost.app_info[pos] = (pshm->nodemng_domain[i].localhost.app_info[pos]&(~PROCESS_MASK)) + PROCESS_OK;
//              return 1;
//          }
//          if((process_info == PROC_ERROR) && ((pshm->nodemng_domain[i].localhost.app_info[pos]&PROCESS_MASK) != PROCESS_BAD))
//          {
//              log_printf(LOG_NORMAL, 42058, "APP %d process BAD", app_id);
//              pshm->nodemng_domain[i].localhost.app_info[pos] = (pshm->nodemng_domain[i].localhost.app_info[pos]&(~PROCESS_MASK)) + PROCESS_BAD;
//              return 1;
//          }
//      }
//  }
//  return 1;
//}

/***************************
      log:42210~~~42229
***************************/
bool CServicesManage::isAppRun(int app_id , int domain_id)
{
    init();
    int app_pos = app_id;
    if (app_id < 0)
    {
        log_printf(LOG_WARN, 42059, "app_id is wrong app_id =%d", app_id);
        return false;
    }
    if (m_pshm == NULL)
    {
        log_printf(LOG_WARN, 42060, "m_pshm is NULL");
        return false;
    }
    struct timeb nowb;
    ftime(&nowb);
    if (m_pt.TimebCheck(&nowb, &(reinterpret_cast<NODEMNG_SHM *>(m_pshm))->refresh_time,
                        OVER_TIME) >= 0) //��ʾ����3sû��ˢ�£���Ϊ���ݲ��ɿ�
    {
        log_printf(LOG_ERROR, 42061, "Share memory has not been refreshed for long----");
        return false;
    }
    if ((reinterpret_cast<NODEMNG_SHM *>(m_pshm))->shm_error_flag)
    {
        log_printf(LOG_WARN, 42062, "Share memory in nodemng is error");
        return false;
    }
    if (m_ni.getNodeType() == CNodeInfo::CLIENT) //�ͻ���
    {
        if (app_id == BASE_SERVICE)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    if (app_id == BASE_SERVICE)
    {
        return true;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);
    //if((pshm->nodemng_public.usage==1)&&(app_id ==PUBLIC))
    //  return true;
    if (app_id == PUBLIC)
    {
        if (pshm->nodemng_public.usage == 1)
        {
            return true;
        }
        if ((pshm->nodemng_public.localhost.app_info & RUN_MASK) != RUN_STOP)
        {
            return true;
        }
    }
    int i;
    for (i = 0; i < pshm->domain_count; i++)
    {
        //�����Ǹ�procmng�ж�isAppRun�õģ��������pshm->process[i].domain_id=NOT_WITH_ANY_DOMAIN
        if (domain_id == NOT_WITH_ANY_DOMAIN)
        {
            if (pshm->nodemng_domain[i].usage == 0) //��ǰ�򲻿���continue��
            {
                continue;
            }
            if (pshm->nodemng_domain[i].localhost.app_order[app_pos] == APP_NOT_RUN)
            {
                continue;
            }
            else if ((pshm->nodemng_domain[i].localhost.app_info[app_pos]&RUN_MASK) == RUN_STOP)
            {
                continue;
            }
            else
            {
                return true;
            }
        }
        else
        {
            if (pshm->nodemng_domain[i].usage == 0) //��ǰ�򲻿���continue��
            {
                continue;
            }
            if (pshm->nodemng_domain[i].local_domain_id != domain_id)
            {
                continue;
            }
            if (pshm->nodemng_domain[i].localhost.app_order[app_pos] == APP_NOT_RUN)
            {
                return false;
            }
            else if ((pshm->nodemng_domain[i].localhost.app_info[app_pos]&RUN_MASK) == RUN_STOP)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
    if (domain_id != NOT_WITH_ANY_DOMAIN)
    {
        log_printf(LOG_WARN, 42063, "Current domain(%d) have not run in app(%d)", domain_id, app_id);
    }
    else
    {
        log_printf(LOG_WARN, 42064, "The app(%d) on this node,maybe stop or error ", app_id);
    }
    return false;//��ǰ�����û������
}

struct HOST_SORT_INFO
{
    string host_name;
    int order;
};
static bool host_compare(const struct HOST_SORT_INFO &first, const struct HOST_SORT_INFO &second)
{
    if ((first.order == MAX_NODE_ORDER) && (second.order != MAX_NODE_ORDER))
    {
        return true;
    }
    if ((second.order == MAX_NODE_ORDER) && (first.order != MAX_NODE_ORDER))
    {
        return false;
    }
    if (first.order == second.order)
    {
        return false;
    }
    return (first.order < second.order);
}

/***************************
      log:42230~~~42249
***************************/
int CServicesManage::GetSorttedNodes( int app_id, int domain_id, vector<string> &hosts )
{
    init();
	bool BelongLocalSergrp;
	int ret = CheckDomainIsBelongLocalSergrp(app_id, domain_id, BelongLocalSergrp);
    if (ret < 0)
    {
		log_printf(LOG_DEBUG, 42065, "GetSorttedNodes::CheckDomainIsBelongLocalSergrp error return....");
        return -1;
    }
	if(!BelongLocalSergrp)// ��domain���Ǳ��ط��������
	{
		log_printf(LOG_DEBUG, 42066, "GetSorttedNodes::this domain(%d) you put is not belong to this node,please check carefully!!!",domain_id);
		return -1;
	}
    struct HOST_SORT_INFO hsi;
    list<struct HOST_SORT_INFO> host_info;
	NODEMNG_SHM *pshm = (NODEMNG_SHM*)m_pshm;
    if(m_pshm == NULL)
      return -1;
    struct timeb nowb;
    ftime(&nowb);
    if(m_pt.TimebCheck(&nowb, &pshm->refresh_time,OVER_TIME) >= 0)
    {
		log_printf(LOG_DEBUG, 42067, "GetSorttedNodes::Share memory has not been refreshed for long");
        return -1;
    }
	int pos=app_id;
	//����public�ͷ�public
	 if (app_id == PUBLIC) 
	 {
		if(pshm->nodemng_public.local_domain_apps.usage == 0)
		  return 0;
		if(pshm->nodemng_public.local_domain_apps.duty_host == -1)
		{
		  hsi.host_name = pshm->hostname;
		  hsi.order = MAX_NODE_ORDER;
		  host_info.push_back(hsi);
		}
		else if(pshm->nodemng_public.local_domain_apps.duty_host != -2)
		{
		  hsi.host_name = pshm->nodemng_public.neighbors[pshm->nodemng_public.local_domain_apps.duty_host].hostname;
		  hsi.order = MAX_NODE_ORDER;
		  host_info.push_back(hsi);
		}
		for(int i=0; i<MAX_NODE_NUM; i++)
		{
		  if(pshm->nodemng_public.local_domain_apps.standby_host[i] == -2)
			  break;
		  if(pshm->nodemng_public.local_domain_apps.standby_host[i] == -1)
		  {
			  hsi.host_name = pshm->hostname;
			  hsi.order = pshm->nodemng_public.localhost.app_order;
			  host_info.push_back(hsi);
		  }
		  else
		  {
			  hsi.host_name = pshm->nodemng_public.neighbors[pshm->nodemng_public.local_domain_apps.standby_host[i]].hostname;
			  hsi.order = pshm->nodemng_public.neighbors[pshm->nodemng_public.local_domain_apps.standby_host[i]].app_order;
			  host_info.push_back(hsi);
		  }
		}
		host_info.sort(host_compare);
		list<struct HOST_SORT_INFO>::iterator it;
		hosts.clear();
		for(it=host_info.begin(); it!=host_info.end(); it++)
		  hosts.push_back(it->host_name);
	 }
	 else
	 {
		int k;
		for (k = 0; k < MAX_DM_IN_SG; k++)
		{
			if (pshm->nodemng_domain[k].local_domain_id == domain_id)//��ʾ�ҵ�
				break;
		}
		if(k==MAX_DM_IN_SG)
		{
			log_printf(LOG_DEBUG, 42068, "GetSorttedNodes::this domain(%d) not found in this node!!!",domain_id);
			return -1;
		}
		if(pshm->nodemng_domain[k].local_domain_apps[pos].usage == 0)
		  return 0;
		if(pshm->nodemng_domain[k].local_domain_apps[pos].duty_host == -1)
		{
		  hsi.host_name = pshm->hostname;
		  hsi.order = MAX_NODE_ORDER;
		  host_info.push_back(hsi);
		}
		else if(pshm->nodemng_domain[k].local_domain_apps[pos].duty_host != -2)
		{
		  hsi.host_name = pshm->nodemng_domain[k].neighbors[pshm->nodemng_domain[k].local_domain_apps[pos].duty_host].hostname;
		  hsi.order = MAX_NODE_ORDER;
		  host_info.push_back(hsi);
		}
		for(int i=0; i<MAX_NODE_NUM; i++)
		{
		  if(pshm->nodemng_domain[k].local_domain_apps[pos].standby_host[i] == -2)
			  break;
		  if(pshm->nodemng_domain[k].local_domain_apps[pos].standby_host[i] == -1)
		  {
			  hsi.host_name = pshm->hostname;
			  hsi.order = pshm->nodemng_domain[k].localhost.app_order[pos];
			  host_info.push_back(hsi);
		  }
		  else
		  {
			  hsi.host_name = pshm->nodemng_domain[k].neighbors[pshm->nodemng_domain[k].local_domain_apps[pos].standby_host[i]].hostname;
			  hsi.order = pshm->nodemng_domain[k].neighbors[pshm->nodemng_domain[k].local_domain_apps[pos].standby_host[i]].app_order[pos];
			  host_info.push_back(hsi);
		  }
		}
		host_info.sort(host_compare);
		list<struct HOST_SORT_INFO>::iterator it;
		hosts.clear();
		for(it=host_info.begin(); it!=host_info.end(); it++)
		  hosts.push_back(it->host_name);
	 }
	 int ii;
	 std::vector<string>::iterator it1;
	 for(ii=0;ii<hosts.size();ii++)
	 {
		 log_printf(LOG_DEBUG, 42065, "GetSorttedNodes::print this host order(%d)...host_name(%s)",ii,hosts[ii].c_str());
	 }
    return 1;
}
/***************************
      log:42250~~~42269
***************************/
int CServicesManage::isAppOK(int app_id, int domain_id)
{
    init();
    if (app_id < 0)
    {
        log_printf(LOG_WARN, 42069, "app_id is wrong app_id =%d", app_id);
        return -1;
    }
    if (domain_id < 0)
    {
        log_printf(LOG_WARN, 42070, "domain_id is wrong app_id =%d", domain_id);
        return -1;
    }
    if (m_pshm == NULL)
    {
        log_printf(LOG_WARN, 42071, "m_pshm is NULL");
        return -1;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    struct timeb nowb;
    ftime(&nowb);
    if (m_pt.TimebCheck(&nowb, &(reinterpret_cast<NODEMNG_SHM *>(m_pshm))->refresh_time, OVER_TIME) >= 0)
    {
        log_printf(LOG_WARN, 42072, "Share memory has not been refreshed for long");
        return -1;
    }
    if ((reinterpret_cast<NODEMNG_SHM *>(m_pshm))->shm_error_flag)
    {
        log_printf(LOG_WARN, 42073, "Share memory in nodemng is error");
        return false;
    }

    for (int i = 0; i < pshm->domain_count; i++)
    {
        if (pshm->nodemng_domain[i].usage == 0) //��ǰ�򲻿���continue��
        {
            continue;
        }
        if (pshm->nodemng_domain[i].local_domain_id != domain_id) //��ǰ�����������Ӧ��
        {
            continue;
        }
        if (pshm->nodemng_domain[i].local_domain_apps[app_id].usage == 0) //��ǰӦ�ò�����
        {
            log_printf(LOG_WARN, 42074, "Current domain(%d) and app_id(%d) is not run!", domain_id, app_id);
            return -1;  //�ҵ�ĳ����ĳӦ�ò�����
        }
        if ((pshm->nodemng_domain[i].localhost.app_order[app_id] != APP_NOT_RUN)
                && ((pshm->nodemng_domain[i].localhost.app_info[app_id]&PROCESS_MASK) == PROCESS_OK)
                && ((pshm->nodemng_domain[i].localhost.host_info & NETSTATUS_MASK) == NETSTATUS_OK)
                && ((pshm->nodemng_domain[i].localhost.extra_info & NET_OK_DELAY_MASK) == NET_OK_DELAY_CLEAR)
                && ((pshm->nodemng_domain[i].localhost.app_info[app_id]&RUN_MASK) != RUN_START)
                && ((pshm->nodemng_domain[i].localhost.app_info[app_id]&RUN_MASK) != RUN_STOP)
                && ((pshm->nodemng_domain[i].localhost.app_info[app_id]&RUN_MASK) != RUN_FAIL))
        {
            log_printf(LOG_NORMAL, 42075, "Current domain(%d) and app_id(%d) is run!", domain_id, app_id);
            return 1;
        }
        else
        {
            log_printf(LOG_WARN, 42076, "Current domain(%d) and app_id(%d) is not run!", domain_id, app_id);
            return -1;
        }
    }
    return -1;


}

//int CServicesManage::GetSerGrpIDbyDomain(int &SerGrp_id)
//{
//
//  SerGrp_id =1;
//  return 1;
//  //����������Զ�˵��й�ϵ�����ڴ�
//  //if(m_pshm == NULL)
//  //{
//  //  log_printf(LOG_WARN, 42077, "m_pshm is NULL");
//  //  return -1;
//  //}
//  //NODEMNG_SHM *pshm = (NODEMNG_SHM*)m_pshm;
//
//  //struct timeb nowb;
//  //ftime(&nowb);
//  //if(m_pt.TimebCheck(&nowb, &pshm->refresh_time,ACTIVE_TIME) >= 0)
//  //{
//  //  log_printf(LOG_WARN, 42078, "Share memory has not been refreshed for long");
//  //  return -1;
//  //}
//  //NODEMNG_SHM *pshm = (NODEMNG_SHM*)m_pshm;
//  //SerGrp_id = pshm->local_sergrp_id;
//  //return 1;
//
//}
