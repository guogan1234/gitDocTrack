#include "nodemng_def.h"
#include "libpub.h"
#include "shmkey_define.h"

void usage(void)
{
    //printf("nodemng_set -app app_name -order order|-1\n");
    printf("usage :nodemng_set -app app_name -status start|stop|back|duty [-d domain ] \n");//7������
    //printf("nodemng_set -app app_name -proc ok|bad\n");
    //printf("nodemng_set -app app_name -net ok|bad\n");
    return;
}

int main(int argc, char **argv)
{
    rt21_context_init(argc, argv);
    if (rt21_context_sim())//��ѵ̬
    {
        argc = argc - 1; //��������֮��ԭ�����еĶ�������Ҫ�䶯
    }

    if ((argc < 5) || (strcmp(argv[1], "-app") != 0))
    {
        usage();
        exit(-1);
    }
    CShm *pcshm = new CShm();
    if (pcshm == NULL)
    {
        printf("Create CShm error");
        exit(-1);
    }
    NODEMNG_SHM *pshm = (NODEMNG_SHM *)pcshm->AttachShm("nodemng", sizeof(struct NODEMNG_SHM));
    if (pshm == NULL)
    {
        printf("Attach share memory error");
        exit(-1);
    }

    CSem *m_psem = new CSem();
    if (m_psem == NULL)
    {
        printf("CNodemngCal can not create semaphore");
        exit(-1);
    }
    if (!m_psem->init(NODEMNG_KEY))
    {
        printf("CNodemngCal can not init semaphore");
        exit(-1);
    }
    int app_pos;

    map<int, string> appMap;
    std::map<int, string>::iterator iter_app_map;
    CSysInfo m_si;
    int nret = m_si.Init();
    if (nret < 0)
    {
        printf("nodemng_set--CSysInfo can not Init, abort.\n");
        return -1;
    }
    nret = m_si.GetAllAppInfo(appMap);//��ȡӦ��id��Ӧ�����Ķ�Ӧ��ϵmap
    if (nret < 0)
    {
        printf("nodemng_set--CSysInfo can not GetAllAppInfo, abort.\n");
        return -1;
    }
    for (iter_app_map = appMap.begin(); iter_app_map != appMap.end(); ++iter_app_map)
    {
        if (strcmp(argv[2], iter_app_map->second.c_str()) == 0)
        {
            app_pos = iter_app_map->first;
            break;
        }
    }
    if (iter_app_map == appMap.end())
    {
        printf("can not find this app_name(%s) in system\n", argv[2]);
        exit(-1);
    }

    //if(strcmp(argv[3], "-order") == 0)
    //{
    //  int order = atoi(argv[4]);
    //  if(order == -1)
    //      pshm->localhost.app_order[app_pos] = APP_NOT_RUN;
    //  else
    //      pshm->localhost.app_order[app_pos] = order;
    //}
    if (strcmp(argv[3], "-status") == 0)
    {
        int i;
        if (pshm->shm_error_flag)//��ʾ���������ڴ棬return
        {
            printf("nodemng shm is error .abort\n");
            exit(-1);
        }
        if (argc == 5)
        {
            if (!m_psem->p(1000))
            {
                printf("duty_cal operate p overtime error\n");
                return -1;
            }
            if (app_pos == PUBLIC)
            {
                if (pshm->nodemng_public.usage == 0)
                    ;
                else
                {
                    if (strcmp(argv[4], "start") == 0)
                    {
                        pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
                                (~RUN_MASK)) + RUN_START;
                        printf("���óɹ�,shm=%x", pshm->nodemng_public.localhost.app_info);
                    }
                    else if (strcmp(argv[4], "back") == 0)
                    {
                        pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
                                (~RUN_MASK)) + RUN_BACK;
                        printf("���óɹ�,shm=%x", pshm->nodemng_public.localhost.app_info);
                    }
                    else if (strcmp(argv[4], "duty") == 0)
                    {
                        pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
                                (~RUN_MASK)) + RUN_DUTY;
                        printf("���óɹ�,shm=%x", pshm->nodemng_public.localhost.app_info);
                    }
                    else if (strcmp(argv[4], "stop") == 0)
                    {
                        pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
                                (~RUN_MASK)) + RUN_STOP;
                        printf("���óɹ�,shm=%x", pshm->nodemng_public.localhost.app_info);
                    }
                    else
                    {
                        usage();
                        m_psem->v();
                        exit(-1);
                    }
                    m_psem->v();
                }
            }
            else
            {
                for (i = 0; i < pshm->domain_count; i++)
                {
                    if (pshm->nodemng_domain[i].usage == 0)
                    {
                        continue;
                    }
                    else
                    {
                        if (strcmp(argv[4], "start") == 0)
                        {
                            pshm->nodemng_domain[i].localhost.app_info[app_pos] =
                                (pshm->nodemng_domain[i].localhost.app_info[app_pos] & (~RUN_MASK)) + RUN_START;
                            printf("���óɹ�,shm=%x", pshm->nodemng_domain[i].localhost.app_info[app_pos]);
                        }
                        else if (strcmp(argv[4], "back") == 0)
                        {
                            pshm->nodemng_domain[i].localhost.app_info[app_pos] =
                                (pshm->nodemng_domain[i].localhost.app_info[app_pos] & (~RUN_MASK)) + RUN_BACK;
                            printf("���óɹ�,shm=%x", pshm->nodemng_domain[i].localhost.app_info[app_pos]);
                        }
                        else if (strcmp(argv[4], "duty") == 0)
                        {
                            pshm->nodemng_domain[i].localhost.app_info[app_pos] =
                                (pshm->nodemng_domain[i].localhost.app_info[app_pos] & (~RUN_MASK)) + RUN_DUTY;
                            printf("���óɹ�,shm=%x", pshm->nodemng_domain[i].localhost.app_info[app_pos]);
                        }
                        else if (strcmp(argv[4], "stop") == 0)
                        {
                            pshm->nodemng_domain[i].localhost.app_info[app_pos] =
                                (pshm->nodemng_domain[i].localhost.app_info[app_pos] & (~RUN_MASK)) + RUN_STOP;
                            printf("���óɹ�,shm=%x", pshm->nodemng_domain[i].localhost.app_info[app_pos]);
                        }
                        else
                        {
                            usage();
                            m_psem->v();
                            exit(-1);
                        }
                        m_psem->v();
                        break;
                    }
                }
                if (i == pshm->domain_count)
                {
                    printf("there is no domain be used\n");
                }
            }
        }
        else if ((argc == 7) && (strcmp(argv[5], "-d") == 0))
        {
            for (i = 0; i < pshm->domain_count; i++)
            {
                if (pshm->nodemng_domain[i].usage == 0)
                {
                    continue;
                }
                if (pshm->nodemng_domain[i].local_domain_id != atoi(argv[6]))
                {
                    continue;
                }
                else
                {
                    if (!m_psem->p(1000))
                    {
                        printf("duty_cal operate p overtime error\n");
                        return -1;
                    }
                    if (strcmp(argv[4], "start") == 0)
                    {
                        pshm->nodemng_domain[i].localhost.app_info[app_pos] =
                            pshm->nodemng_domain[i].localhost.app_info[app_pos] & (~RUN_MASK) + RUN_START;
                    }
                    else if (strcmp(argv[4], "back") == 0)
                    {
                        pshm->nodemng_domain[i].localhost.app_info[app_pos] =
                            pshm->nodemng_domain[i].localhost.app_info[app_pos] & (~RUN_MASK) + RUN_BACK;
                    }
                    else if (strcmp(argv[4], "duty") == 0)
                    {
                        pshm->nodemng_domain[i].localhost.app_info[app_pos] =
                            pshm->nodemng_domain[i].localhost.app_info[app_pos] & (~RUN_MASK) + RUN_DUTY;
                    }
                    else if (strcmp(argv[4], "stop") == 0)
                    {
                        pshm->nodemng_domain[i].localhost.app_info[app_pos] =
                            pshm->nodemng_domain[i].localhost.app_info[app_pos] & (~RUN_MASK) + RUN_STOP;
                    }
                    else
                    {
                        usage();
                        m_psem->v();
                        exit(-1);
                    }
                    m_psem->v();
                    break;
                }
            }
        }
        else
        {
            usage();
            exit(-1);
        }
    }
    //else if(strcmp(argv[3], "-proc") == 0)
    //{
    //  if(strcmp(argv[4], "ok") == 0)
    //      pshm->localhost.app_info[app_pos] = (pshm->localhost.app_info[app_pos]&(~PROCESS_MASK)) + PROCESS_OK;
    //  else if(strcmp(argv[4], "bad") == 0)
    //      pshm->localhost.app_info[app_pos] = (pshm->localhost.app_info[app_pos]&(~PROCESS_MASK)) + PROCESS_BAD;
    //  else
    //  {
    //      usage();
    //      exit(-1);
    //  }
    //}
    //else if(strcmp(argv[3], "-net") == 0)
    //{
    //  if(strcmp(argv[4], "ok") == 0)
    //      pshm->localhost.host_info = NETSTATUS_OK;
    //  else if(strcmp(argv[4], "bad") == 0)
    //      pshm->localhost.host_info = NETSTATUS_BAD;
    //  else
    //  {
    //      usage();
    //      exit(-1);
    //  }
    //}
    else
    {
        usage();
        exit(-1);
    }
    if (pcshm != NULL)
    {
        delete pcshm;
        pcshm = NULL;
    }
    return 0;
}