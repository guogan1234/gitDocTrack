/****************************************
*  log:41000~~~41299
* @file nodemng_cal.cpp
* @brief duty_cal
* @author lib
* @version 1.0
* @date 13-Apr-2013
* @log:41000~~~41299
*****************************************/
#include "OB/CORBA.h"
#include "libmsg.h"
#include "alarm_message.h"
#include "corba_wrap_common.h"
#include "message_type.h"
#include "libnodemng.h"
#include "nodemng_cal.h"
#include <list>

static CMsg g_msg;
static CServicesManage g_sm;
char g_allTag[200] = "";
int g_send_alarm_domain;
char g_hostname[64] = "";
int  g_location_id;
bool g_bMsgInit = false;

//duty_switch_count
int g_count_force_duty = 0;
int g_count_force_back = 0;
int g_count_force_duty_public = 0;
int g_count_force_back_public = 0;

/*�������ı�������ʽ*/
#define MENU_RTNALARM_AND_EVENT 1   /* ���ظ澯+�¼� */
#define MENU_ALARM_AND_EVENT    0   /* �澯+�¼� */
/*����������*/
#define REGION_SYSTEM 1

/*ϵͳ�豸����*/
#define MENU_NET_DEV_TYPE   10  /* ���� */
#define MENU_PROC_DEV_TYPE  11  /* ���� */
#define MENU_APP_DEV_TYPE   12  /* Ӧ�� */


/*ϵͳ�¼�״̬*/
#define MENU_SYS_NET_ERROR  50  /* ������� */
#define MENU_SYS_NET_OK 51  /* ����ָ� */
#define MENU_SYS_PROC_ERROR 52  /* ���̹��� */
#define MENU_SYS_PROC_OK    53  /* ���ָ̻� */
#define MENU_SYS_APP_SWITCH 54  /* Ӧ���л� */
#define MENU_SYS_APP_ERROR  55  /* Ӧ�ù��� */
#define MENU_SYS_APP_OK 56  /* Ӧ�ûָ� */


static bool app_switch_alarm(const char *app_name, const char *app_status);
static bool app_switch_alarm(int app_id, const char *app_status)
{
    char str_tmp[32];
    sprintf(str_tmp, "%d", app_id);
    return (app_switch_alarm(str_tmp, app_status));
}

static bool app_switch_alarm(const char *app_name, const char *app_status)
{
    if (g_bMsgInit)
    {
        APP_TO_ALARM_SERVER_MESSAGE_STRU alarm_msg;
        char alarm_str[160];
        char host[64];

        sprintf(alarm_str, "%s Ӧ��%s �л���%s", g_hostname, app_name, app_status);

        struct timeb now_b;
        ftime(&now_b);

        alarm_msg.alarm_num = 1;
        alarm_msg.seq_alarm_message.length(alarm_msg.alarm_num);

        alarm_msg.seq_alarm_message[0].alarm_type = "SYSTEM_ALARM_TYPE";
        alarm_msg.seq_alarm_message[0].app_no = PUBLIC;
        alarm_msg.seq_alarm_message[0].is_restrain = 0;

        alarm_msg.seq_alarm_message[0].if_ack_on_rtn = 0;
        alarm_msg.seq_alarm_message[0].del_act_on_ack = 0;
        alarm_msg.seq_alarm_message[0].if_never_alm_on_rtn = 0;
        alarm_msg.seq_alarm_message[0].if_water_alm = 0;

        alarm_msg.seq_alarm_message[0].alarm_style = MENU_ALARM_AND_EVENT;

        alarm_msg.seq_alarm_message[0].reservered_1 = 0;
        alarm_msg.seq_alarm_message[0].reservered_2 = 0;

        alarm_msg.seq_alarm_message[0].seq_field_info.length(9);
        alarm_msg.seq_alarm_message[0].seq_field_info[0].c_time(now_b.time);
        alarm_msg.seq_alarm_message[0].seq_field_info[1].c_int(now_b.millitm);
        alarm_msg.seq_alarm_message[0].seq_field_info[2].c_int(g_send_alarm_domain);
        alarm_msg.seq_alarm_message[0].seq_field_info[3].c_int(g_location_id);
        alarm_msg.seq_alarm_message[0].seq_field_info[4].c_int(REGION_SYSTEM);
        alarm_msg.seq_alarm_message[0].seq_field_info[5].c_int(MENU_APP_DEV_TYPE);
        alarm_msg.seq_alarm_message[0].seq_field_info[6].c_int(0);
        alarm_msg.seq_alarm_message[0].seq_field_info[7].c_int(MENU_SYS_APP_SWITCH);
        alarm_msg.seq_alarm_message[0].seq_field_info[8].c_string(CORBA::string_dup(alarm_str));
        alarm_msg.seq_alarm_message[0].source_tag = CORBA::string_dup(g_allTag);

        char *send_buf = NULL;
        int buf_size;
        int ret_code;

        // ȡPUBLIC����
        ret_code = g_sm.RequestPublicService(REQUEST_DUTY, host);
        if (ret_code != 1)
        {
            log_printf(LOG_WARN, 41000, "libnodemng_cal::app_switch_alarm :Can not get duty host of PUBLIC");
            return false;
        }

        CNodeInfo *ptr_ni = new CNodeInfo();
        if (ptr_ni == NULL)
        {
            log_printf(LOG_WARN, 41001, "libnodemng_cal::app_switch_alarm: new CNodeInfo error");
            delete ptr_ni;
            return false;
        }
        if (!ptr_ni ->init(host))
        {
            log_printf(LOG_WARN, 41002, "libnodemng_cal::app_switch_alarm: Can not init CNodeInfo host(%s)",
                       host);
            delete ptr_ni;
            return false;
        }
        vector<int> temp_domain;
        if (ptr_ni->getDomainID(temp_domain) < 0)
        {
            log_printf(LOG_WARN, 41003, "libnodemng_cal::app_switch_alarm: Can not getDomainID in CNodeInfo");
            delete ptr_ni;
            return false;
        }
        g_send_alarm_domain = temp_domain[0];
        if (ptr_ni != NULL)
        {
            delete ptr_ni;
        }
        alarm_msg.seq_alarm_message[0].seq_field_info[2].c_int(g_send_alarm_domain);

        MARSHAL(alarm_msg, send_buf, buf_size);

        ret_code = g_msg.send_to_host(host, "alarm_server", "alarm_server",
                                      send_buf, buf_size, APP_TO_ALARM_SERVER_TYPE);

        if (ret_code < 0)
        {
            log_printf(LOG_ERROR, 41004, "libnodemng_cal::app_switch_alarm :msg error, return");
            delete [] send_buf;
            return false;
        }
        else if (ret_code == 0)
        {
            log_printf(LOG_WARN, 41005, "libnodemng_cal::app_switch_alarm :send alarm error: %s", alarm_str);
            delete [] send_buf;
            return false;
        }
        delete [] send_buf;
        log_printf(LOG_NORMAL, 41006, "libnodemng_cal::app_switch_alarm :send alarm success: %s",
                   alarm_str);
    }

    return true;
}


static bool peer_net_alarm(char *node_name, int net_status)
{
    if (g_bMsgInit)
    {
        APP_TO_ALARM_SERVER_MESSAGE_STRU alarm_msg;
        char alarm_str[160];
        char host[64];
        if (net_status == MENU_SYS_NET_ERROR)
        {
            sprintf(alarm_str, "%s ���� ����(%s����)", node_name, g_hostname);
        }
        else
        {
            sprintf(alarm_str, "%s ���� �ָ�(%s����)", node_name, g_hostname);
        }

        struct timeb now_b;
        ftime(&now_b);

        alarm_msg.alarm_num = 1;
        alarm_msg.seq_alarm_message.length(alarm_msg.alarm_num);

        alarm_msg.seq_alarm_message[0].alarm_type = "SYSTEM_ALARM_TYPE";
        alarm_msg.seq_alarm_message[0].app_no = PUBLIC;
        alarm_msg.seq_alarm_message[0].is_restrain = 0;

        alarm_msg.seq_alarm_message[0].if_ack_on_rtn = 0;
        alarm_msg.seq_alarm_message[0].del_act_on_ack = 0;
        alarm_msg.seq_alarm_message[0].if_never_alm_on_rtn = 0;
        alarm_msg.seq_alarm_message[0].if_water_alm = 0;

        alarm_msg.seq_alarm_message[0].alarm_style = MENU_ALARM_AND_EVENT;

        alarm_msg.seq_alarm_message[0].reservered_1 = 0;
        alarm_msg.seq_alarm_message[0].reservered_2 = 0;

        alarm_msg.seq_alarm_message[0].seq_field_info.length(9);
        alarm_msg.seq_alarm_message[0].seq_field_info[0].c_time(now_b.time);
        alarm_msg.seq_alarm_message[0].seq_field_info[1].c_int(now_b.millitm);
        alarm_msg.seq_alarm_message[0].seq_field_info[2].c_int(g_send_alarm_domain);
        alarm_msg.seq_alarm_message[0].seq_field_info[3].c_int(g_location_id);
        alarm_msg.seq_alarm_message[0].seq_field_info[4].c_int(REGION_SYSTEM);
        alarm_msg.seq_alarm_message[0].seq_field_info[5].c_int(MENU_NET_DEV_TYPE);
        alarm_msg.seq_alarm_message[0].seq_field_info[6].c_int(0);
        alarm_msg.seq_alarm_message[0].seq_field_info[7].c_int(net_status);
        alarm_msg.seq_alarm_message[0].seq_field_info[8].c_string(CORBA::string_dup(alarm_str));
        alarm_msg.seq_alarm_message[0].source_tag = CORBA::string_dup(g_allTag);

        char *send_buf = NULL;
        int buf_size;
        int ret_code;

        // ȡPUBLIC����
        ret_code = g_sm.RequestPublicService(REQUEST_DUTY, host);
        if (ret_code != 1)
        {
            log_printf(LOG_WARN, 41007, "libnodemng_cal::peer_net_alarm :Can not get duty host of PUBLIC");
            return false;
        }
        CNodeInfo *ptr_ni = new CNodeInfo();
        if (ptr_ni == NULL)
        {
            log_printf(LOG_WARN, 41008, "libnodemng_cal::peer_net_alarm: new CNodeInfo error");
            delete ptr_ni;
            return false;
        }
        if (!ptr_ni ->init(host))
        {
            log_printf(LOG_WARN, 41009, "libnodemng_cal::peer_net_alarm : Can not init CNodeInfo host(%s)",
                       host);
            delete ptr_ni;
            return false;
        }
        vector<int> temp_domain;
        if (ptr_ni->getDomainID(temp_domain) < 0)
        {
            log_printf(LOG_WARN, 41010, "libnodemng_cal::peer_net_alarm : Can not getDomainID in CNodeInfo");
            delete ptr_ni;
            return false;
        }
        g_send_alarm_domain = temp_domain[0];
        if (ptr_ni != NULL)
        {
            delete ptr_ni;
        }
        alarm_msg.seq_alarm_message[0].seq_field_info[2].c_int(g_send_alarm_domain);

        MARSHAL(alarm_msg, send_buf, buf_size);

        ret_code = g_msg.send_to_host(host, "alarm_server", "alarm_server",
                                      send_buf, buf_size, APP_TO_ALARM_SERVER_TYPE);

        if (ret_code < 0)
        {
            log_printf(LOG_ERROR, 41011, "libnodemng_cal::peer_net_alarm :msg error, return");
            delete [] send_buf;
            return false;
        }
        else if (ret_code == 0)
        {
            log_printf(LOG_WARN, 41012, "libnodemng_cal::peer_net_alarm :send alarm error: %s", alarm_str);
            delete [] send_buf;
            return false;
        }
        delete [] send_buf;
        log_printf(LOG_NORMAL, 41013, "libnodemng_cal::peer_net_alarm :send alarm success: %s", alarm_str);
    }

    return true;
}

CNodemngCal::CNodemngCal()
{

}
CNodemngCal::~CNodemngCal()
{
    //NODEMNG_SHM *pshm = (NODEMNG_SHM*)m_pshm;
    ////�ѱ����ĺܶ��ʼ״̬��Ϊ��
    ////��ʼ��public�Ĺ����ڴ�
    //if (((pshm->nodemng_public.localhost.app_info&(RUN_MASK)) == RUN_FORCE_DUTY)||((pshm->nodemng_public.localhost.app_info&(RUN_MASK)) == RUN_DUTY))
    //{
    //  pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info&(~RUN_MASK)) + RUN_BACK;
    //  log_printf(LOG_SENSOR, 41014, "libnodemng_cal::exit: set local app public from DUTY to BACK");
    //}
    ////��ʼ������Ӧ�ù����ڴ�
    //for(int j=0;j<pshm->domain_count;j++)
    //{
    //  if (pshm->nodemng_domain[j].usage != 1)
    //           continue;
    //  int i;
    //  for(i=0; i<MAX_APP_NUM; i++)
    //  {
    //      if (pshm->nodemng_domain[j].localhost.usage != 1)
    //       continue;
    //      if (((pshm->nodemng_domain[j].localhost.app_info[i]&(RUN_MASK)) == RUN_FORCE_DUTY)||((pshm->nodemng_domain[j].localhost.app_info[i]&(RUN_MASK)) == RUN_DUTY))
    //      {
    //          pshm->nodemng_domain[j].localhost.app_info[i] = (pshm->nodemng_domain[j].localhost.app_info[i]&(~RUN_MASK)) + RUN_BACK;
    //          log_printf(LOG_SENSOR, 41015, "libnodemng_cal::exit: set local app %d from DUTY to BACK",i);
    //      }
    //  }
    //}

    if (NULL != m_pcshm )
    {
        delete m_pcshm;
    }
    if (NULL != m_psem)
    {
        delete m_psem;
    }
    log_printf(LOG_SENSOR, 41016, "libnodemng_cal::CServiceManage destruction");
}

/***************************
      log:41045~~~41069
***************************/
int  CNodemngCal::init(bool bMsgInit)
{
    rt21_context_sim();
    g_bMsgInit = bMsgInit;
    m_pshm = NULL;
    m_pcshm = new CShm();
    if (m_pcshm == NULL)
    {
        if (!log_printf(LOG_ERROR, 41017, "CNodemngCal::init: Create CShm error"))
        {
            CPubCommon::local_log(LOG_ERROR, 41045, "CNodemngCal::init: Create CShm error");
        }
        return -1;
    }
    m_pshm = m_pcshm->AttachShm("nodemng", sizeof(struct NODEMNG_SHM));
    if (m_pshm == NULL)
    {
        if (!log_printf(LOG_ERROR, 41018, "CNodemngCal::init: Attach ShareMemory nodemng error"))
        {
            CPubCommon::local_log(LOG_ERROR, 41046, "CNodemngCal::init: Attach ShareMemory nodemng error.\n");
        }
        return -1;
    }
    m_psem = new CSem();
    if (m_psem == NULL)
    {
        log_printf(LOG_ERROR, 41019, "CNodemngCal::init: Can not create semaphore");
        _exit(-1);
    }
    if (!m_psem->init(NODEMNG_KEY))
    {
        log_printf(LOG_ERROR, 41020, "CNodemngCal::init: Can not init semaphore");
        _exit(-1);
    }



    int RET = m_ni.init();
    if (RET < 0)
    {
        log_printf(LOG_ERROR, 41021, "CNodemngCal::init: CNodeInfo init error");
        return -1;
    }
    RET = m_ni.getLocalServerGroupId(m_local_sergrp_id);
    if (RET < 0)
    {
        log_printf(LOG_ERROR, 41022, "CNodemngCal::init: CNodeInfo getLocalServerGroupId error");
        return -1;
    }
    strcpy(m_hostname, m_ni.getHostname());
    strcpy(g_hostname, m_ni.getHostname());

    g_location_id = m_ni.getLocationId();
    vector<int> domain_ids;
    RET = m_ni.getDomainID(domain_ids);
    if (RET < 0)
    {
        log_printf(LOG_ERROR, 41023, "CNodemngCal::init: CNodeInfo getDomainID error");
        return -1;
    }
    g_send_alarm_domain = domain_ids[0];
    RET = m_si.Init();
    if (RET < 0)
    {
        log_printf(LOG_ERROR, 41024, "CNodemngCal::init: CSysInfoInfo init error");
        return -1;
    }
    if (bMsgInit)
    {
        if (!g_msg.init("nodemng", "nodemng", MSG_PUT))
        {
            log_printf(LOG_ERROR, 41025, "CNodemngCal::init: Msg init error");
            return -1;
        }
#ifdef WIN32
        DWORD pid = getpid();
#else
        pid_t pid = getpid();
#endif
        sprintf(g_allTag, "%s%c%s%c%u%c%s", m_hostname, ':', "hb_mng", '_', pid, ':',
                "hb_mng::SendAlarm()");
        log_printf(LOG_SENSOR, 41026, "hb_mng::libnodemng_cal init::Print source_tag:%s", g_allTag);
    }
    //��ʼ������������ڵ��checktime
    m_last_neighbour_check.time = 0;
    m_last_neighbour_check.millitm = 0;
    m_neighbour_check_interval.time = 1;
    m_neighbour_check_interval.millitm = 0;
    m_neighbor_lose.time = 4;//��3��Ϊ4
    m_neighbor_lose.millitm = 0;

    //��ʼ��Զ�˹���������������ڵ��checktime
    m_last_sergrp_check.time = 0;
    m_last_sergrp_check.millitm = 0;
    m_sergrp_check_interval.time = 1;
    m_sergrp_check_interval.millitm = 0;
    m_sergrp_lose.time = 10;
    m_sergrp_lose.millitm = 0;

    // ��ʼ��ȫ�ֱ���
    struct timeval timeout = {0, 20 * 1000}; // 100������
    struct timeb last_broad, nowb, broad_interval;
    last_broad.time = 0;
    last_broad.millitm = 0;
    broad_interval.time = 1;
    broad_interval.millitm = 0;

    struct timeb net_ok_delay_start;
    struct timeb net_ok_delay = {3, 0};


    //    bool m_start_up = true;
    log_printf(LOG_SENSOR, 41027, "CNodemngCal::init success");

    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    ftime(&nowb);
    // ��������������ʧЧ�ڵ�
    if (m_pt.TimebCheck(&nowb, &pshm->refresh_time, &m_neighbor_lose) >= 0) //��ʾ���˺ܾ���
    {
        //��ʼ��public�Ĺ����ڴ�
        //if (((pshm->nodemng_public.localhost.app_info&(RUN_MASK)) == RUN_FORCE_DUTY)||((pshm->nodemng_public.localhost.app_info&(RUN_MASK)) == RUN_DUTY))
        {
            g_count_force_back_public = 0;
            pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
                    (~RUN_MASK)) + RUN_FORCE_BACK;
            log_printf(LOG_NORMAL, 41028, "libnodemng_cal::exit: set local app public from DUTY to FORCE_BACK");
        }

        //��ʼ������Ӧ�ù����ڴ�
        for (int j = 0; j < pshm->domain_count; j++)
        {
            if (pshm->nodemng_domain[j].usage != 1)
            {
                continue;
            }
            int i;
            for (i = 0; i < MAX_APP_NUM; i++)
            {
                if (pshm->nodemng_domain[j].localhost.usage != 1)
                {
                    continue;
                }
                //if (((pshm->nodemng_domain[j].localhost.app_info[i]&(RUN_MASK)) == RUN_FORCE_DUTY)||((pshm->nodemng_domain[j].localhost.app_info[i]&(RUN_MASK)) == RUN_DUTY))
                {
                    g_count_force_back = 0;
                    pshm->nodemng_domain[j].localhost.app_info[i] = (pshm->nodemng_domain[j].localhost.app_info[i] &
                            (~RUN_MASK)) + RUN_FORCE_BACK;
                    log_printf(LOG_NORMAL, 41029, "libnodemng_cal::exit: set local app %d from DUTY to FORCE_BACK", i);
                }
            }
        }
    }


    //NODEMNG_SHM *pshm = (NODEMNG_SHM*)m_pshm;
    //ftime(&nowb);
    //// ��������������ʧЧ�ڵ�
    //if(m_pt.TimebCheck(&nowb, &pshm->refresh_time, &m_neighbor_lose) >= 0)//��ʾ���˺ܾ���
    //{
    //  //��ʼ��public�Ĺ����ڴ�
    //  if ((pshm->nodemng_public.localhost.app_info&(RUN_MASK)) == RUN_FORCE_DUTY)
    //  {
    //      pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info&(~RUN_MASK)) + RUN_BACK;
    //      log_printf(LOG_NORMAL, 41030, "libnodemng_cal::exit: set local app public from DUTY to BACK");
    //  }
    //  if ((pshm->nodemng_public.localhost.app_info&(RUN_MASK)) == RUN_DUTY)
    //  {
    //      pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info&(~RUN_MASK)) + RUN_BACK;
    //      log_printf(LOG_NORMAL, 41031, "libnodemng_cal::exit: set local app public from DUTY to BACK");
    //  }

    //  //��ʼ������Ӧ�ù����ڴ�
    //  for(int j=0;j<pshm->domain_count;j++)
    //  {
    //      if (pshm->nodemng_domain[j].usage != 1)
    //          continue;
    //      int i;
    //      for(i=0; i<MAX_APP_NUM; i++)
    //      {
    //          if (pshm->nodemng_domain[j].localhost.usage != 1)
    //              continue;
    //          if (((pshm->nodemng_domain[j].localhost.app_info[i]&(RUN_MASK)) == RUN_FORCE_DUTY)||((pshm->nodemng_domain[j].localhost.app_info[i]&(RUN_MASK)) == RUN_DUTY))
    //          {
    //              pshm->nodemng_domain[j].localhost.app_info[i] = (pshm->nodemng_domain[j].localhost.app_info[i]&(~RUN_MASK)) + RUN_BACK;
    //              log_printf(LOG_NORMAL, 41032, "libnodemng_cal::exit: set local app %d from DUTY to BACK",i);
    //          }
    //      }
    //  }
    //}
    return 1;
}

void  CNodemngCal::WriteLocalServer(const NM_LOCAL_PACKET_SERVER &nm_local_packet)//�յ�������д
{
    time_t now;
    time(&now);
    timeb nowb;
    ftime(&nowb);
    //�ж��Ƿ���3s��ʱ�ɿ���
    //if((now-ntohl(nm_local_packet.time)>2)||(now-ntohl(nm_local_packet.time)<-2))
    //{
    //  log_printf(LOG_WARN, 41033, "local node(%s) from sergrp(%d) send to this node(%s) time is not corrent",nm_local_packet.head.hostname,ntohl(nm_local_packet.local_service_groupId),m_hostname);
    //  return;
    //}
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);
    // NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    if (sizeof(struct NM_LOCAL_PACKET_SERVER) != sizeof(nm_local_packet)) //���size���Ա�ʾ����
    {
        log_printf(LOG_WARN, 41034, "the receive packet size is not correct with  NM_LOCAL_PACKET");
        return;
    }
    if (ntohl(nm_local_packet.head.isValid) ==
            HB_SHM_ERROR) //���յ��Ļ��������ڴ�������ڱ����϶�Ӧ��λ��usage����0��
    {
        SetNodeShmError(std::string(
                            nm_local_packet.head.hostname).c_str());//��packet�����hostname���룬����ʧЧ
        if (!log_printf(LOG_WARN, 41035, "WriteLocal set node(%s) shm error success",
                        nm_local_packet.head.hostname))
        {
            CPubCommon::local_log(LOG_WARN, 41071, "WriteLocal set node(%s) shm error success",
                                  nm_local_packet.head.hostname);
        }
        return;
    }
    if (ntohl(nm_local_packet.head.isValid) == HB_NET_ERROR)
    {
        if (!log_printf(LOG_SENSOR, 41036,
                        " CNodemngCal::WriteLocalServer ,this node have not receive from local packet"))
        {
            CPubCommon::local_log(LOG_SENSOR, 41072,
                                  "CNodemngCal::WriteLocalServer ,this node have not receive from local packet");
        }
        //DutyCal();
        //��ʾ�յ��İ��������жϲ��Ҳ��Ǳ�������
        ClearInValidNode();//����������������Ч�ڵ�
        ClearInValidSerGrp();
        //���¹����ڴ�ʱ��
        pshm->refresh_time.time = nowb.time;
        pshm->refresh_time.millitm = nowb.millitm;
        return;
    }
    if (memcmp(nm_local_packet.head.magic, PACKET_LEAD, 6) != 0) //�յ��ı���magic���ԣ�drop
    {
        log_printf(LOG_WARN, 41037,
                   "WriteLocal Receive an error packet with magic=0x%2d0x%02d0x%2d0x%2d0x%2d0x%2d"
                   , nm_local_packet.head.magic[0], nm_local_packet.head.magic[1], nm_local_packet.head.magic[2],
                   nm_local_packet.head.magic[3], nm_local_packet.head.magic[4], nm_local_packet.head.magic[5]);
        return;
    }
    if (strcmp(m_hostname, nm_local_packet.head.hostname) == 0) //�յ��������͵ı��ģ�drop������
    {
        if (!log_printf(LOG_SENSOR, 41038,
                        " CNodemngCal::WriteLocalServer: this node  receive local_host ,drop"))
        {
            CPubCommon::local_log(LOG_SENSOR, 41074,
                                  "CNodemngCal::WriteLocalServer :this node  receive local_host ,drop");
        }
        DutyCal();
        ClearInValidNode();//����������������Ч�ڵ�
        ClearInValidSerGrp();

        //���¹����ڴ�ʱ��
        pshm->refresh_time.time = nowb.time;
        pshm->refresh_time.millitm = nowb.millitm;
        //m_start_up = false;
        return;
    }
    if (nm_local_packet.head.packet_type != htonl(LOCAL_REPORT)) //���Ǳ��صı�������
    {
        log_printf(LOG_WARN, 41039,
                   "the receive packet packet_type is not correct type with  LOCAL_REPORT");
        return;
    }
    int i, j, k;
    //if (m_ni.getNodeType()==CNodeInfo::CLIENT)//�ͻ���
    //{
    //  //������publicרҵ
    //  for (k=0;k<pshm->domain_count;k++)
    //  {
    //      if (pshm->nodemng_domain[k].usage ==0)
    //          continue;
    //      for (j=0;j<MAX_NODE_NUM;j++)
    //      {
    //          for (m=0;m<MAX_DM_IN_SG;m++)
    //          {
    //              if (pshm->nodemng_domain[k].local_domain_id!=ntohl(nm_local_packet.neibourgh_report[m][j].domain_id))
    //                  continue;
    //              else
    //                  break;
    //          }
    //          if (m==MAX_DM_IN_SG)
    //              continue;
    //          else
    //          {
    //              pshm->nodemng_domain[k].neighbors[j].usage = ntohl(nm_local_packet.neibourgh_report[m][j].usage);
    //              pshm->nodemng_domain[k].neighbors[j].host_info = nm_local_packet.neibourgh_report[m][j].host_info;
    //              for (i=0;i<MAX_APP_NUM;i++)
    //              {
    //                  if (i==PUBLIC)
    //                      continue;
    //                  pshm->nodemng_domain[k].neighbors[j].app_info[i] = nm_local_packet.neibourgh_report[m][j].app_info[i];
    //                  pshm->nodemng_domain[k].neighbors[j].app_order[i] = nm_local_packet.neibourgh_report[m][j].app_order[i];
    //              }
    //              strcpy(pshm->nodemng_domain[k].neighbors[j].hostname,nm_local_packet.neibourgh_report[m][j].hostname);
    //              pshm->nodemng_domain[k].neighbors[j].refresh_time.time = nowb.time;
    //              pshm->nodemng_domain[k].neighbors[j].refresh_time.millitm = nowb.millitm;
    //          }
    //      }
    //  }
    //  //����publicרҵ
    //  pshm->nodemng_public.usage = 1;
    //  //ע����̨��������״ֵ̬(k=0��neibou��)
    //  pshm->nodemng_public.neighbors[0].usage = ntohl(nm_local_packet.local_public_report.usage);
    //  pshm->nodemng_public.neighbors[0].app_info = nm_local_packet.local_public_report.app_info;
    //  pshm->nodemng_public.neighbors[0].app_order = nm_local_packet.local_public_report.app_order;
    //  pshm->nodemng_public.neighbors[0].host_info = nm_local_packet.local_public_report.host_info;
    //  strcpy(pshm->nodemng_public.neighbors[0].hostname,nm_local_packet.local_public_report.hostname);
    //  pshm->nodemng_public.neighbors[0].refresh_time.time = nowb.time;
    //  pshm->nodemng_public.neighbors[0].refresh_time.millitm = nowb.millitm;
    //  for(j=1;j<MAX_NODE_NUM;j++)
    //  {
    //      pshm->nodemng_public.neighbors[j].usage = ntohl(nm_local_packet.neibourgh_public_report[j-1].usage);
    //      pshm->nodemng_public.neighbors[j].app_info = nm_local_packet.neibourgh_public_report[j-1].app_info;
    //      pshm->nodemng_public.neighbors[j].app_order = nm_local_packet.neibourgh_public_report[j-1].app_order;
    //      pshm->nodemng_public.neighbors[j].host_info = nm_local_packet.neibourgh_public_report[j-1].host_info;
    //      strcpy(pshm->nodemng_public.neighbors[j].hostname,nm_local_packet.neibourgh_public_report[j-1].hostname);
    //      pshm->nodemng_public.neighbors[j].refresh_time.time = nowb.time;
    //      pshm->nodemng_public.neighbors[j].refresh_time.millitm = nowb.millitm;
    //  }
    //}
    if (m_ni.getNodeType() == CNodeInfo::SERVER) // �����
    {
        //�����յ������ı���
        for (k = 0; k < MAX_DM_IN_SG; k++)
        {
            int firstunused_domain = -1;
            if (pshm->local_sergrp_id != ntohl(nm_local_packet.local_service_groupId))
            {
                log_printf(LOG_WARN, 41040,
                           "CNodemngCal::WriteLocalServer: Receive pacekt's service_group_id(%d) is not equal with local_sergrp_id(%d)",
                           ntohl(nm_local_packet.local_service_groupId), pshm->local_sergrp_id);
                break;
            }
            if (ntohl(nm_local_packet.nodemng_report[k].usage) == 0) //��ʾ�˰�ĳdomainû����
            {
                continue;
            }
            for (j = 0; j < pshm->domain_count; j++)
            {
                if ((pshm->nodemng_domain[j].local_domain_id == ntohl(nm_local_packet.nodemng_report[k].domain_id))
                        && (pshm->nodemng_domain[j].usage == 1)) //��ʾ��domain�ҵ����ҿ���
                {
                    break;
                }
                if ((firstunused_domain == -1) && (pshm->nodemng_domain[j].usage == 0))
                {
                    firstunused_domain    = j;
                }
            }
            if (j == pshm->domain_count)// ����δ�ҵ����ݰ��е������
            {
                if (firstunused_domain != -1)// new host add to host
                {
                    int firstunused1 = -1;
                    pshm->nodemng_domain[firstunused_domain].usage = 1;
                    pshm->nodemng_domain[firstunused_domain].local_domain_id = ntohl(
                                nm_local_packet.nodemng_report[k].domain_id);
                    for (i = 0; i < MAX_NODE_NUM; i++)
                    {
                        if ((pshm->nodemng_domain[firstunused_domain].neighbors[i].usage == 1)
                                && (strcmp(pshm->nodemng_domain[firstunused_domain].neighbors[i].hostname,
                                           nm_local_packet.head.hostname) == 0))
                        {
                            break;
                        }
                        if ((firstunused1 == -1) && (pshm->nodemng_domain[firstunused_domain].neighbors[i].usage == 0))
                        {
                            firstunused1 = i;
                        }
                    }
                    if (i == MAX_NODE_NUM) // δ�ҵ�
                    {
                        if (firstunused1 != -1) // new host add to host
                        {
                            pshm->nodemng_domain[firstunused_domain].neighbors[firstunused1].usage = 1;
                            strcpy(pshm->nodemng_domain[firstunused_domain].neighbors[firstunused1].hostname,
                                   nm_local_packet.head.hostname);
                            for (int n = 0; n < MAX_APP_NUM; n++)
                            {
                                if (n == PUBLIC)
                                {
                                    continue;
                                }
                                pshm->nodemng_domain[firstunused_domain].neighbors[firstunused1].app_info[n] =
                                    nm_local_packet.nodemng_report[k].app_info[n];
                                pshm->nodemng_domain[firstunused_domain].neighbors[firstunused1].app_order[n] =
                                    nm_local_packet.nodemng_report[k].app_order[n];
                            }
                            pshm->nodemng_domain[firstunused_domain].neighbors[firstunused1].host_info =
                                nm_local_packet.nodemng_report[k].host_info;
                            ftime(&pshm->nodemng_domain[firstunused_domain].neighbors[firstunused1].refresh_time);
                        }
                        else  // �������̫�࣬����־
                        {
                            log_printf(LOG_WARN, 41041, "CNodemngCal::WriteLocalServer: Too many host number");
                        }
                    }
                    else
                    {
                        for (int n = 0; n < MAX_APP_NUM; n++)
                        {
                            if (n == PUBLIC)
                            {
                                continue;
                            }
                            pshm->nodemng_domain[firstunused_domain].neighbors[i].app_info[n] =
                                nm_local_packet.nodemng_report[k].app_info[n];
                            pshm->nodemng_domain[firstunused_domain].neighbors[i].app_order[n] =
                                nm_local_packet.nodemng_report[k].app_order[n];;
                        }
                        pshm->nodemng_domain[firstunused_domain].neighbors[i].host_info =
                            nm_local_packet.nodemng_report[k].host_info;
                        ftime(&pshm->nodemng_domain[firstunused_domain].neighbors[i].refresh_time);
                    }
                }
                else  // �����̫�࣬����MAX_DM_IN_SG ����־
                {
                    log_printf(LOG_WARN, 41042, "CNodemngCal::WriteLocalServer: Too many domain number��over %d",
                               MAX_DM_IN_SG);
                }
            }
            else//��ʾ�ҵ��˽ڵ�,��ʱ�˽ڵ�Ϊk
            {
                int firstunused = -1;
                for (i = 0; i < MAX_NODE_NUM; i++)
                {
                    if ((pshm->nodemng_domain[j].neighbors[i].usage == 1)
                            && (strcmp(pshm->nodemng_domain[j].neighbors[i].hostname, nm_local_packet.head.hostname) == 0))
                    {
                        break;
                    }
                    if ((firstunused == -1) && (pshm->nodemng_domain[j].neighbors[i].usage == 0))
                    {
                        firstunused = i;
                    }
                }
                if (i == MAX_NODE_NUM) // δ�ҵ�
                {
                    if (firstunused != -1) // new host add to host
                    {
                        pshm->nodemng_domain[j].neighbors[firstunused].usage = 1;
                        strcpy(pshm->nodemng_domain[j].neighbors[firstunused].hostname, nm_local_packet.head.hostname);
                        for (int n = 0; n < MAX_APP_NUM; n++)
                        {
                            if (n == PUBLIC)
                            {
                                continue;
                            }
                            pshm->nodemng_domain[j].neighbors[firstunused].app_info[n] =
                                nm_local_packet.nodemng_report[k].app_info[n];
                            pshm->nodemng_domain[j].neighbors[firstunused].app_order[n] =
                                nm_local_packet.nodemng_report[k].app_order[n];
                        }
                        pshm->nodemng_domain[j].neighbors[firstunused].host_info =
                            nm_local_packet.nodemng_report[k].host_info;
                        ftime(&pshm->nodemng_domain[j].neighbors[firstunused].refresh_time);
                    }
                    else  // �������̫�࣬����־
                    {
                        log_printf(LOG_WARN, 41043, "CNodemngCal::WriteLocalServer: Too many host number");
                    }
                }
                else
                {
                    for (int n = 0; n < MAX_APP_NUM; n++)
                    {
                        if (n == PUBLIC)
                        {
                            continue;
                        }
                        pshm->nodemng_domain[j].neighbors[i].app_info[n] = nm_local_packet.nodemng_report[k].app_info[n];
                        pshm->nodemng_domain[j].neighbors[i].app_order[n] = nm_local_packet.nodemng_report[k].app_order[n];;
                    }
                    pshm->nodemng_domain[j].neighbors[i].host_info = nm_local_packet.nodemng_report[k].host_info;
                    ftime(&pshm->nodemng_domain[j].neighbors[i].refresh_time);
                }
            }
        }
        //����public��Ϣ���ж��Ƿ񱾻�����������local_host����������public_neighbors
        {
            //���Ǳ����Լ�������
            if (strcmp(pshm->nodemng_public.localhost.hostname, nm_local_packet.head.hostname) != 0)
            {
                int firstunused_public = -1;
                int same_use = -1;
                for (i = 0; i < MAX_NODE_NUM; i++)
                {
                    if (strcmp(pshm->nodemng_public.neighbors[i].hostname, nm_local_packet.head.hostname) == 0)
                    {
                        if (pshm->nodemng_public.neighbors[i].usage == 1)
                        {
                            break;
                        }
                        else if (firstunused_public == -1)
                        {
                            same_use = i;
                        }
                    }
                    if ((firstunused_public == -1) && (pshm->nodemng_public.neighbors[i].usage == 0))
                    {
                        firstunused_public = i;
                    }

                    //if((pshm->nodemng_public.neighbors[i].usage == 1)
                    //  && (strcmp(pshm->nodemng_public.neighbors[i].hostname, nm_local_packet.head.hostname) == 0))
                    //  break;
                    //if((firstunused_public == -1) && (pshm->nodemng_public.neighbors[i].usage == 0))
                    //  firstunused_public = i;
                }
                if (i == MAX_NODE_NUM) // δ�ҵ�
                {
                    if (same_use != -1)//��ʾ�ҵ��˸���ͬ����hostname��������usage ==0
                    {
                        pshm->nodemng_public.neighbors[same_use].usage = 1;
                        strcpy(pshm->nodemng_public.neighbors[same_use].hostname, nm_local_packet.head.hostname);
                        pshm->nodemng_public.neighbors[same_use].host_info = nm_local_packet.local_public_report.host_info;
                        pshm->nodemng_public.neighbors[same_use].app_info = nm_local_packet.local_public_report.app_info;
                        pshm->nodemng_public.neighbors[same_use].app_order = nm_local_packet.local_public_report.app_order;
                        ftime(&pshm->nodemng_public.neighbors[same_use].refresh_time);
                        if (((pshm->nodemng_public.localhost.host_info & NETSTATUS_MASK) == NETSTATUS_OK)
                                && ((pshm->nodemng_public.neighbors[same_use].host_info & NETSTATUS_MASK) !=
                                    NETSTATUS_OK)) //������������&&��һ̨�������粻����
                        {
                            //��һ���ָ��ı���
                            peer_net_alarm(pshm->nodemng_public.neighbors[same_use].hostname, MENU_SYS_NET_OK);
                        }
                    }
                    else
                    {
                        if (firstunused_public != -1) // new host add to host
                        {
                            pshm->nodemng_public.neighbors[firstunused_public].usage = 1;
                            strcpy(pshm->nodemng_public.neighbors[firstunused_public].hostname, nm_local_packet.head.hostname);
                            pshm->nodemng_public.neighbors[firstunused_public].host_info =
                                nm_local_packet.local_public_report.host_info;
                            pshm->nodemng_public.neighbors[firstunused_public].app_info =
                                nm_local_packet.local_public_report.app_info;
                            pshm->nodemng_public.neighbors[firstunused_public].app_order =
                                nm_local_packet.local_public_report.app_order;
                            ftime(&pshm->nodemng_public.neighbors[firstunused_public].refresh_time);
                        }
                        else  // �������̫�࣬����־
                        {
                            log_printf(LOG_WARN, 41044, "Too many host number");
                        }
                    }
                }
                else
                {
                    pshm->nodemng_public.neighbors[i].host_info = nm_local_packet.local_public_report.host_info;
                    pshm->nodemng_public.neighbors[i].app_info = nm_local_packet.local_public_report.app_info;
                    pshm->nodemng_public.neighbors[i].app_order = nm_local_packet.local_public_report.app_order;
                    ftime(&pshm->nodemng_public.neighbors[i].refresh_time);
                }
            }
        }
    }
    else
    {
        log_printf(LOG_WARN, 41045, "Receive packet from db_server hostname:%s",
                   std::string(nm_local_packet.head.hostname).c_str());
        return;
    }
    DutyCal();
    ClearInValidNode();//����������������Ч�ڵ�
    ClearInValidSerGrp();

    //���¹����ڴ�ʱ��
    pshm->refresh_time.time = nowb.time;
    pshm->refresh_time.millitm = nowb.millitm;
    m_start_up = false;
    if (g_count_force_duty > 100)
    {
        g_count_force_duty = 0 ;
    }
    else
    {
        g_count_force_duty++;
    }

    if (g_count_force_duty_public > 100)
    {
        g_count_force_duty_public = 0 ;
    }
    else
    {
        g_count_force_duty_public++;
    }

    if (g_count_force_back > 100)
    {
        g_count_force_back = 0 ;
    }
    else
    {
        g_count_force_back++;
    }

    if (g_count_force_back_public > 100)
    {
        g_count_force_back_public = 0 ;
    }
    else
    {
        g_count_force_back_public++;
    }

    return ;
    //���������任��������״̬
}


void  CNodemngCal::WriteLocalClient(const NM_LOCAL_PACKET_CLIENT &nm_local_packet)//�յ�������д
{
    time_t now;
    time(&now);
    timeb nowb;
    ftime(&nowb);
    //�ж��Ƿ���3s��ʱ�ɿ���
    //if((now-ntohl(nm_local_packet.time)>2)||(now-ntohl(nm_local_packet.time)<-2))
    //{
    //  log_printf(LOG_WARN, 41046, "local node(%s) from sergrp(%d) send to this node(%s) time is not corrent",nm_local_packet.head.hostname,ntohl(nm_local_packet.local_service_groupId),m_hostname);
    //  return;
    //}
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);
    // NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    if (sizeof(struct NM_LOCAL_PACKET_CLIENT) != sizeof(nm_local_packet)) //���size���Ա�ʾ����
    {
        log_printf(LOG_WARN, 41047, "the receive packet size is not correct with  NM_LOCAL_PACKET");
        return;
    }
    if (ntohl(nm_local_packet.head.isValid) ==
            HB_SHM_ERROR) //���յ��Ļ��������ڴ�������ڱ����϶�Ӧ��λ��usage����0��
    {
        SetNodeShmError(std::string(
                            nm_local_packet.head.hostname).c_str());//��packet�����hostname���룬����ʧЧ
        log_printf( LOG_NORMAL, 41048, "WriteLocal set node(%s) shm error success",
                    nm_local_packet.head.hostname);
        return;
    }
    if (ntohl(nm_local_packet.head.isValid) == HB_NET_ERROR)
    {
        //DutyCal();
        //��ʾ�յ��İ��������жϲ��Ҳ��Ǳ�������
        ClearInValidNode();//����������������Ч�ڵ�
        ClearInValidSerGrp();
        //���¹����ڴ�ʱ��
        pshm->refresh_time.time = nowb.time;
        pshm->refresh_time.millitm = nowb.millitm;
        return;
    }
    if (memcmp(nm_local_packet.head.magic, PACKET_LEAD, 6) != 0) //�յ��ı���magic���ԣ�drop
    {
        log_printf(LOG_WARN, 41049,
                   "WriteLocal Receive an error packet with magic=0x%2d0x%02d0x%2d0x%2d0x%2d0x%2d"
                   , nm_local_packet.head.magic[0], nm_local_packet.head.magic[1], nm_local_packet.head.magic[2],
                   nm_local_packet.head.magic[3], nm_local_packet.head.magic[4], nm_local_packet.head.magic[5]);
        return;
    }
    //if(strcmp(m_hostname, nm_local_packet.head.hostname) == 0)//�յ��������͵ı��ģ�drop������
    //  return;
    if (nm_local_packet.head.packet_type != htonl(LOCAL_REPORT)) //���Ǳ��صı�������
    {
        log_printf(LOG_WARN, 41050,
                   "the receive packet packet_type is not correct type with  LOCAL_REPORT");
        return;
    }
    int i, j, k, m;
    if (m_ni.getNodeType() == CNodeInfo::CLIENT) //�ͻ���
    {
        //������publicרҵ
        for (k = 0; k < pshm->domain_count; k++)
        {
            if (pshm->nodemng_domain[k].usage == 0)
            {
                continue;
            }
            //����localhost
            for (m = 0; m < MAX_DM_IN_SG; m++)
            {
                if (pshm->nodemng_domain[k].local_domain_id != ntohl(nm_local_packet.nodemng_report[m].domain_id))
                {
                    continue;
                }
                else
                {
                    break;
                }
            }
            if (m == MAX_DM_IN_SG)
            {
                continue;
            }
            else
            {
                pshm->nodemng_domain[k].neighbors[0].usage = ntohl(nm_local_packet.nodemng_report[m].usage);
                pshm->nodemng_domain[k].neighbors[0].host_info = nm_local_packet.nodemng_report[m].host_info;
                for (i = 0; i < MAX_APP_NUM; i++)
                {
                    if (i == PUBLIC)
                    {
                        continue;
                    }
                    pshm->nodemng_domain[k].neighbors[0].app_info[i] = nm_local_packet.nodemng_report[m].app_info[i];
                    pshm->nodemng_domain[k].neighbors[0].app_order[i] = nm_local_packet.nodemng_report[m].app_order[i];
                }
                strcpy(pshm->nodemng_domain[k].neighbors[0].hostname, nm_local_packet.nodemng_report[m].hostname);
                pshm->nodemng_domain[k].neighbors[0].refresh_time.time = nowb.time;
                pshm->nodemng_domain[k].neighbors[0].refresh_time.millitm = nowb.millitm;
            }
            for (j = 0; j < MAX_NODE_NUM; j++)
            {
                for (m = 0; m < MAX_DM_IN_SG; m++)
                {
                    if (pshm->nodemng_domain[k].local_domain_id != ntohl(
                                nm_local_packet.neibourgh_report[m][j].domain_id))
                    {
                        continue;
                    }
                    else
                    {
                        break;
                    }
                }
                if (m == MAX_DM_IN_SG)
                {
                    continue;
                }
                else
                {
                    pshm->nodemng_domain[k].neighbors[j + 1].usage = ntohl(
                                nm_local_packet.neibourgh_report[m][j].usage);
                    pshm->nodemng_domain[k].neighbors[j + 1].host_info =
                        nm_local_packet.neibourgh_report[m][j].host_info;
                    for (i = 0; i < MAX_APP_NUM; i++)
                    {
                        if (i == PUBLIC)
                        {
                            continue;
                        }
                        pshm->nodemng_domain[k].neighbors[j + 1].app_info[i] =
                            nm_local_packet.neibourgh_report[m][j].app_info[i];
                        pshm->nodemng_domain[k].neighbors[j + 1].app_order[i] =
                            nm_local_packet.neibourgh_report[m][j].app_order[i];
                    }
                    strcpy(pshm->nodemng_domain[k].neighbors[j + 1].hostname,
                           nm_local_packet.neibourgh_report[m][j].hostname);
                    pshm->nodemng_domain[k].neighbors[j + 1].refresh_time.time = nowb.time;
                    pshm->nodemng_domain[k].neighbors[j + 1].refresh_time.millitm = nowb.millitm;
                }
            }
        }
        //����publicרҵ
        pshm->nodemng_public.usage = 1;
        //ע����̨��������״ֵ̬(k=0��neibou��)
        pshm->nodemng_public.neighbors[0].usage = ntohl(nm_local_packet.local_public_report.usage);
        pshm->nodemng_public.neighbors[0].app_info = nm_local_packet.local_public_report.app_info;
        pshm->nodemng_public.neighbors[0].app_order = nm_local_packet.local_public_report.app_order;
        pshm->nodemng_public.neighbors[0].host_info = nm_local_packet.local_public_report.host_info;
        strcpy(pshm->nodemng_public.neighbors[0].hostname, nm_local_packet.local_public_report.hostname);
        pshm->nodemng_public.neighbors[0].refresh_time.time = nowb.time;
        pshm->nodemng_public.neighbors[0].refresh_time.millitm = nowb.millitm;
        for (j = 1; j < MAX_NODE_NUM; j++)
        {
            pshm->nodemng_public.neighbors[j].usage = ntohl(nm_local_packet.neibourgh_public_report[j -
                    1].usage);
            pshm->nodemng_public.neighbors[j].app_info = nm_local_packet.neibourgh_public_report[j -
                    1].app_info;
            pshm->nodemng_public.neighbors[j].app_order = nm_local_packet.neibourgh_public_report[j -
                    1].app_order;
            pshm->nodemng_public.neighbors[j].host_info = nm_local_packet.neibourgh_public_report[j -
                    1].host_info;
            strcpy(pshm->nodemng_public.neighbors[j].hostname,
                   nm_local_packet.neibourgh_public_report[j - 1].hostname);
            pshm->nodemng_public.neighbors[j].refresh_time.time = nowb.time;
            pshm->nodemng_public.neighbors[j].refresh_time.millitm = nowb.millitm;
        }
    }
    else
    {
        log_printf(LOG_WARN, 41051, "Receive packet from db_server hostname:%s",
                   std::string(nm_local_packet.head.hostname).c_str());
        return;
    }
    DutyCal();
    ClearInValidNode();//����������������Ч�ڵ�
    ClearInValidSerGrp();

    //���¹����ڴ�ʱ��
    pshm->refresh_time.time = nowb.time;
    pshm->refresh_time.millitm = nowb.millitm;
    m_start_up = false;
    return ;
    //���������任��������״̬
}

void  CNodemngCal::WriteRemote(const NM_REMOTE_PACKET &nm_remote_packet)
{
    time_t now;
    time(&now);
    timeb nowb;
    ftime(&nowb);
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    if (sizeof(struct NM_REMOTE_PACKET) != sizeof(nm_remote_packet)) //���size���Ա�ʾ����
    {
        log_printf(LOG_WARN, 41052, "the receive packet size is not correct with  NM_REMOTE_PACKET");
        return;
    }
    if (ntohl(nm_remote_packet.head.isValid) ==
            HB_NET_ERROR) //hb_manageû���յ����ģ����ϴ˱�־����ʱҪ�жϳ�ʱ
    {
        //DutyCal();
        ClearInValidNode();//����������������Ч�ڵ�
        ClearInValidSerGrp();
        //���¹����ڴ�ʱ��
        pshm->refresh_time.time = nowb.time;
        pshm->refresh_time.millitm = nowb.millitm;
        return;
    }
    long temp_now = long(now);
    long remote_time = ntohl(nm_remote_packet.time);
    //�ж��Ƿ���3s��ʱ�ɿ���
    if (temp_now - remote_time - 3 > 0)
    {
        log_printf(LOG_WARN, 41053,
                   "remote node(%s) from sergrp(%d) send to this node(%s) time is not corrent..... local_time =%ld,remote_time =%ld",
                   nm_remote_packet.head.hostname, ntohl(nm_remote_packet.local_service_groupId), m_hostname, temp_now,
                   remote_time);
        return;
    }
    if (temp_now - remote_time + 3 < 0)
    {
        log_printf(LOG_WARN, 41054,
                   "remote node(%s) from sergrp(%d) send to this node(%s) time is not corrent..... local_time =%ld,remote_time =%ld",
                   nm_remote_packet.head.hostname, ntohl(nm_remote_packet.local_service_groupId), m_hostname, temp_now,
                   remote_time);
        return;
    }

    if (ntohl(nm_remote_packet.head.isValid) ==
            HB_SHM_ERROR) //���յ��Ļ��������ڴ�������ڱ����϶�Ӧ��λ��usage����0��
    {
        SetNodeShmError(std::string(
                            nm_remote_packet.head.hostname).c_str());//��packet�����hostname���룬����ʧЧ
        log_printf( LOG_NORMAL, 41055, "WriteRemote set node(%s) shm error success",
                    nm_remote_packet.head.hostname);
        return;
    }
    if (memcmp(nm_remote_packet.head.magic, PACKET_LEAD, 6) != 0) //�յ��ı���magic���ԣ�drop
    {
        log_printf(LOG_WARN, 41056,
                   "WriteRemote Receive an error packet with magic=0x%2d0x%02d0x%2d0x%2d0x%2d0x%2d"
                   , nm_remote_packet.head.magic[0], nm_remote_packet.head.magic[1], nm_remote_packet.head.magic[2],
                   nm_remote_packet.head.magic[3], nm_remote_packet.head.magic[4], nm_remote_packet.head.magic[5]);
        return;
    }
    if (nm_remote_packet.head.packet_type != htonl(REMOTE_REPORT)) //���Ǳ��صı�������
    {
        log_printf(LOG_WARN, 41057,
                   "the receive packet packet_type is not correct type with  REMOTE_REPORT");
        return;
    }
    if (strcmp(m_hostname, nm_remote_packet.head.hostname) == 0) //�յ��������͵ı��ģ�drop������
    {
        return;
    }

    log_printf(LOG_SENSOR, 41058, "�����������鱨��: host=%s, src_sergrp=%d",
               nm_remote_packet.head.hostname,
               ntohl(nm_remote_packet.local_service_groupId));
    int i, j, k;
    int firstunused = -1;
    for (i = 0; i < MAX_SERGRP_NUM; i++)
    {
        if ((pshm->remote_sergrp[i].usage)
                && (pshm->remote_sergrp[i].sergrp_id == ntohl(nm_remote_packet.local_service_groupId)))
        {
            pshm->remote_sergrp[i].refresh_time.time = nowb.time;
            log_printf(LOG_SENSOR, 41059, "Receive nodemng packet from sergrp %d",
                       pshm->remote_sergrp[i].sergrp_id);
            pshm->remote_sergrp[i].remote_public.usage = 1;//����public��usage=1
            strcpy(pshm->remote_sergrp[i].remote_public.duty_hostname,
                   nm_remote_packet.public_info.duty_hostname);
            ftime(&pshm->remote_sergrp[i].remote_public.refresh_time);
            for (j = 0; j < MAX_DM_IN_SG; j++)
            {
                pshm->remote_sergrp[i].remote_domains[j].usage = ntohl(nm_remote_packet.app_info[j].usage);
                if (pshm->remote_sergrp[i].remote_domains[j].usage == 1)
                {
                    pshm->remote_sergrp[i].remote_domains[j].domain_id = ntohl(nm_remote_packet.app_info[j].domain_id);
                    for (k = 0; k < MAX_APP_NUM; k++)
                    {
                        pshm->remote_sergrp[i].remote_domains[j].duty_host[k].usage = ntohl(
                                    nm_remote_packet.app_info[j].duty_host[k].usage);
                        if (pshm->remote_sergrp[i].remote_domains[j].duty_host[k].usage == 1)
                        {
                            strcpy(pshm->remote_sergrp[i].remote_domains[j].duty_host[k].hostname,
                                   nm_remote_packet.app_info[j].duty_host[k].hostname);
                        }
                    }
                    ftime(&pshm->remote_sergrp[i].remote_domains[j].refresh_time);
                }
            }
            break;
        }
        if ((firstunused == -1) && (pshm->remote_sergrp[i].usage == 0))
        {
            firstunused = i;
        }
    }
    if ((i == MAX_SERGRP_NUM) && (firstunused != -1))
    {
        log_printf(LOG_NORMAL, 41060, "Receive nodemng packet from new sergrp %d",
                   ntohl(nm_remote_packet.local_service_groupId));
        pshm->remote_sergrp[firstunused].refresh_time.time = nowb.time;
        pshm->remote_sergrp[firstunused].remote_public.usage = 1;//����public��usage=1
        strcpy(pshm->remote_sergrp[firstunused].remote_public.duty_hostname,
               nm_remote_packet.public_info.duty_hostname);
        ftime(&pshm->remote_sergrp[firstunused].remote_public.refresh_time);
        for (j = 0; j < MAX_DM_IN_SG; j++)
        {
            pshm->remote_sergrp[firstunused].remote_domains[j].usage = ntohl(
                        nm_remote_packet.app_info[j].usage);
            if (pshm->remote_sergrp[firstunused].remote_domains[j].usage == 1)
            {
                pshm->remote_sergrp[firstunused].remote_domains[j].domain_id = ntohl(
                            nm_remote_packet.app_info[j].domain_id);
                for (k = 0; k < MAX_APP_NUM; k++)
                {
                    pshm->remote_sergrp[firstunused].remote_domains[j].duty_host[k].usage = ntohl(
                                nm_remote_packet.app_info[j].duty_host[k].usage);
                    if (pshm->remote_sergrp[firstunused].remote_domains[j].duty_host[k].usage == 1)
                    {
                        strcpy(pshm->remote_sergrp[firstunused].remote_domains[j].duty_host[k].hostname,
                               nm_remote_packet.app_info[j].duty_host[k].hostname);
                    }
                }
                ftime(&pshm->remote_sergrp[firstunused].remote_domains[j].refresh_time);
            }
            pshm->remote_sergrp[firstunused].sergrp_id = ntohl(nm_remote_packet.local_service_groupId);
            pshm->remote_sergrp[firstunused].usage = 1;
        }
    }
    ClearInValidNode();
    ClearInValidSerGrp();//������Ч��������
    // ���¹����ڴ�ʱ��
    pshm->refresh_time.time = nowb.time;
    pshm->refresh_time.millitm = nowb.millitm;
    m_start_up = false;
    return ;
}

void CNodemngCal::WriteDutySwitch(const NM_SWITCH_PACKET
                                  *nm_switch_packet) //������յ�duty_switch������
{
    time_t now;
    time(&now);
    timeb nowb;
    ftime(&nowb);
    bool isLocalHost = true; //�Ƿ�duty_switch����������

    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);
    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    if (memcmp(nm_switch_packet->head.magic, PACKET_LEAD, 6) != 0) //�յ��ı���magic���ԣ�drop
    {
        log_printf(LOG_WARN, 41061,
                   "WriteDutySwitch Receive an error packet with magic=0x%2d0x%02d0x%2d0x%2d0x%2d0x%2d"
                   , nm_switch_packet->head.magic[0], nm_switch_packet->head.magic[1], nm_switch_packet->head.magic[2],
                   nm_switch_packet->head.magic[3], nm_switch_packet->head.magic[4], nm_switch_packet->head.magic[5]);
        return;
    }
    if (nm_switch_packet->head.packet_type != htonl(APP_SWITCH)) //����duty_switch�ı�������
    {
        log_printf(LOG_WARN, 41062, "the receive packet packet_type is not correct type with  APP_SWITCH");
        return;
    }
    if (strcmp(pshm->nodemng_public.localhost.hostname,
               nm_switch_packet->hostname) != 0)//��Ҫ�������л��������뱾����һ��
    {
        log_printf(LOG_NORMAL, 41063, "need to duty_switch host(%s) is not this host(%s)",
                   nm_switch_packet->hostname, pshm->nodemng_public.localhost.hostname);
        isLocalHost = false;
        //return;
    }
    int  j, m;
    char str_force[64];
    string app_name;
    int app_pos = ntohl(nm_switch_packet->app_num);
    int command = ntohl(nm_switch_packet->command);



    if (isLocalHost)
    {
        if (m_ni.getNodeType() == CNodeInfo::SERVER) // �����
        {
            if (app_pos == PUBLIC) //���Ҫ�л�����public
            {
                if ((pshm->nodemng_public.localhost.usage == 1)
                        && (pshm->nodemng_public.localhost.app_info != APP_NOT_RUN)
                        && ((pshm->nodemng_public.localhost.app_info & PROCESS_MASK) == PROCESS_OK)
                        && ((pshm->nodemng_public.localhost.app_info & RUN_MASK) != RUN_START)
                        && ((pshm->nodemng_public.localhost.app_info & RUN_MASK) != RUN_STOP)
                        && ((pshm->nodemng_public.localhost.app_info & RUN_MASK) != RUN_FAIL))
                {
                    if (command == 0)
                    {
                        if (m_si.GetAppNameByNo(app_pos, app_name) < 0)
                        {
                            log_printf(LOG_NORMAL, 41064, "PUBLIC change to FORCE_DUTY by command from %s",
                                       nm_switch_packet->head.hostname);
                            sprintf(str_force, "%s(������:%s)", "ǿ������", nm_switch_packet->head.hostname);
                            if (!app_switch_alarm(app_pos, str_force))
                            {
                                log_printf(LOG_WARN, 41065, "Send app_switch_alarm error");
                            }
                        }
                        else
                        {
                            log_printf(LOG_NORMAL, 41066, "App %s change to FORCE_DUTY by command from %s", app_name.c_str(),
                                       nm_switch_packet->head.hostname);
                            sprintf(str_force, "%s(������:%s)", "ǿ������", nm_switch_packet->head.hostname);
                            if (!app_switch_alarm(app_name.c_str(), str_force))
                            {
                                log_printf(LOG_WARN, 41067, "Send app_switch_alarm error");
                            }
                        }
                        pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
                                (~RUN_MASK)) + RUN_FORCE_DUTY;
                    }
                    else
                    {
                        if (m_si.GetAppNameByNo(app_pos, app_name) < 0)
                        {
                            log_printf(LOG_NORMAL, 41068, "PUBLIC change to FORCE_BACK by command from %s",
                                       nm_switch_packet->head.hostname);
                            if (command == 1) //������
                            {
                                sprintf(str_force, "%s(������:%s)", "ǿ�Ʊ���", nm_switch_packet->head.hostname);
                                if (!app_switch_alarm(app_pos, str_force))
                                {
                                    log_printf(LOG_WARN, 41069, "Send app_switch_alarm error");
                                }
                            }
                        }
                        else
                        {
                            log_printf(LOG_NORMAL, 41070, "App %s change to FORCE_BACK by command from %s", app_name.c_str(),
                                       nm_switch_packet->head.hostname);
                            if (command == 1) //������
                            {
                                sprintf(str_force, "%s(������:%s)", "ǿ�Ʊ���",  nm_switch_packet->head.hostname);
                                if (!app_switch_alarm(app_name.c_str(), str_force))
                                {
                                    log_printf(LOG_WARN, 41071, "Send app_switch_alarm error");
                                }
                            }
                        }
                        pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
                                (~RUN_MASK)) + RUN_FORCE_BACK;
                    }
                }
            }
            else
            {
                for (m = 0; m < MAX_DM_IN_SG; m++)
                {
                    if (pshm->nodemng_domain[m].usage == 0)
                    {
                        continue;
                    }
                    if (pshm->nodemng_domain[m].local_domain_id != ntohl(nm_switch_packet->domain_id))
                    {
                        continue;
                    }
                    else
                    {
                        break;
                    }
                }
                if (m == MAX_DM_IN_SG)
                {
                    return;
                }
                if ((pshm->nodemng_domain[m].localhost.app_info[app_pos] != APP_NOT_RUN)
                        && ((pshm->nodemng_domain[m].localhost.app_info[app_pos]&PROCESS_MASK) == PROCESS_OK)
                        && ((pshm->nodemng_domain[m].localhost.app_info[app_pos]&RUN_MASK) != RUN_START)
                        && ((pshm->nodemng_domain[m].localhost.app_info[app_pos]&RUN_MASK) != RUN_STOP)
                        && ((pshm->nodemng_domain[m].localhost.app_info[app_pos]&RUN_MASK) != RUN_FAIL))
                {
                    if (command == 0)
                    {
                        if (m_si.GetAppNameByNo(app_pos, app_name) < 0)
                        {
                            log_printf(LOG_NORMAL, 41072, "App %d change to FORCE_DUTY by command from %s", app_pos,
                                       nm_switch_packet->head.hostname);
                            sprintf(str_force, "%s(������:%s)", "ǿ������", nm_switch_packet->head.hostname);
                            if (!app_switch_alarm(app_pos, str_force))
                            {
                                log_printf(LOG_WARN, 41073, "Send app_switch_alarm error");
                            }
                        }
                        else
                        {
                            log_printf(LOG_NORMAL, 41074, "App %s change to FORCE_DUTY by command from %s", app_name.c_str(),
                                       nm_switch_packet->head.hostname);
                            sprintf(str_force, "%s(������:%s)", "ǿ������", nm_switch_packet->head.hostname);
                            if (!app_switch_alarm(app_name.c_str(), str_force))
                            {
                                log_printf(LOG_WARN, 41075, "Send app_switch_alarm error");
                            }
                        }
                        pshm->nodemng_domain[m].localhost.app_info[app_pos] =
                            (pshm->nodemng_domain[m].localhost.app_info[app_pos] & (~RUN_MASK)) + RUN_FORCE_DUTY;
                    }
                    else
                    {
                        if (m_si.GetAppNameByNo(app_pos, app_name) < 0)
                        {
                            log_printf(LOG_NORMAL, 41076, "App %d change to FORCE_BACK by command from %s", app_pos,
                                       nm_switch_packet->head.hostname);
                            if (command == 1) //������
                            {
                                sprintf(str_force, "%s(������:%s)", "ǿ�Ʊ���", nm_switch_packet->head.hostname);
                                if (!app_switch_alarm(app_pos, str_force))
                                {
                                    log_printf(LOG_WARN, 41077, "Send app_switch_alarm error");
                                }
                            }
                        }
                        else
                        {
                            log_printf(LOG_NORMAL, 41078, "App %s change to FORCE_BACK by command from %s", app_name.c_str(),
                                       nm_switch_packet->head.hostname);
                            if (command == 1) //������
                            {
                                sprintf(str_force, "%s(������:%s)", "ǿ�Ʊ���",  nm_switch_packet->head.hostname);
                                if (!app_switch_alarm(app_name.c_str(), str_force))
                                {
                                    log_printf(LOG_WARN, 41079, "Send app_switch_alarm error");
                                }
                            }
                        }
                        pshm->nodemng_domain[m].localhost.app_info[app_pos] =
                            (pshm->nodemng_domain[m].localhost.app_info[app_pos] & (~RUN_MASK)) + RUN_FORCE_BACK;
                    }
                }
            }
        }
        g_count_force_duty = 0;
        g_count_force_duty_public = 0;
        g_count_force_back = 0;
        g_count_force_back_public = 0;
    }
    else
    {
        if (m_ni.getNodeType() == CNodeInfo::SERVER) // �����
        {
            if (app_pos == PUBLIC) //���Ҫ�л�����public
            {
                for (j = 0; j < MAX_NODE_NUM; j++)
                {
                    if (pshm->nodemng_public.neighbors[j].usage != 1)
                    {
                        continue;
                    }
                    if (strcmp(pshm->nodemng_public.neighbors[j].hostname, nm_switch_packet->hostname) != 0)
                    {
                        continue;
                    }
                    if ((pshm->nodemng_public.neighbors[j].app_info != APP_NOT_RUN)
                            && ((pshm->nodemng_public.neighbors[j].app_info & PROCESS_MASK) == PROCESS_OK)
                            && ((pshm->nodemng_public.neighbors[j].app_info & RUN_MASK) != RUN_START)
                            && ((pshm->nodemng_public.neighbors[j].app_info & RUN_MASK) != RUN_STOP)
                            && ((pshm->nodemng_public.neighbors[j].app_info & RUN_MASK) != RUN_FAIL))
                    {
                        if (command == 0) //ǿ��
                        {
                            pshm->nodemng_public.neighbors[j].app_info = (pshm->nodemng_public.neighbors[j].app_info &
                                    (~RUN_MASK)) + RUN_FORCE_DUTY;
                            log_printf(LOG_NORMAL, 41080, "PUBLIC of host(%s) change to FORCE_DUTY by command from %s",
                                       nm_switch_packet->hostname, nm_switch_packet->head.hostname);
                        }
                        else//ǿ��
                        {
                            pshm->nodemng_public.neighbors[j].app_info = (pshm->nodemng_public.neighbors[j].app_info &
                                    (~RUN_MASK)) + RUN_FORCE_BACK;
                            log_printf(LOG_NORMAL, 41081, "PUBLIC  of host(%s) change to FORCE_BACK by command from %s",
                                       nm_switch_packet->hostname, nm_switch_packet->head.hostname);
                        }
                        break;
                    }
                }
                if (j == MAX_NODE_NUM)
                {
                    log_printf(LOG_WARN, 41082, "PUBLIC is not active in  host(%s) in this node(%s)",
                               nm_switch_packet->hostname, m_hostname);
                }
            }
            else
            {
                for (m = 0; m < MAX_DM_IN_SG; m++)
                {
                    if (pshm->nodemng_domain[m].usage == 0)
                    {
                        continue;
                    }
                    if (pshm->nodemng_domain[m].local_domain_id != ntohl(nm_switch_packet->domain_id))
                    {
                        continue;
                    }
                    else
                    {
                        break;
                    }
                }
                if (m == MAX_DM_IN_SG)
                {
                    return;
                }
                for (j = 0; j < MAX_NODE_NUM; j++)
                {
                    if (pshm->nodemng_domain[m].neighbors[j].usage != 1)
                    {
                        continue;
                    }
                    if (strcmp(pshm->nodemng_domain[m].neighbors[j].hostname, nm_switch_packet->hostname) != 0)
                    {
                        continue;
                    }
                    if ((pshm->nodemng_domain[m].neighbors[j].app_info[app_pos] != APP_NOT_RUN)
                            && ((pshm->nodemng_domain[m].neighbors[j].app_info[app_pos]&PROCESS_MASK) == PROCESS_OK)
                            && ((pshm->nodemng_domain[m].neighbors[j].app_info[app_pos]&RUN_MASK) != RUN_START)
                            && ((pshm->nodemng_domain[m].neighbors[j].app_info[app_pos]&RUN_MASK) != RUN_STOP)
                            && ((pshm->nodemng_domain[m].neighbors[j].app_info[app_pos]&RUN_MASK) != RUN_FAIL))
                    {
                        if (command == 0) //ǿ��
                        {
                            pshm->nodemng_domain[m].neighbors[j].app_info[app_pos] =
                                (pshm->nodemng_domain[m].neighbors[j].app_info[app_pos] & (~RUN_MASK)) + RUN_FORCE_DUTY;
                            log_printf(LOG_NORMAL, 41083, "PUBLIC of host(%s) change to FORCE_DUTY by command from %s",
                                       nm_switch_packet->hostname, nm_switch_packet->head.hostname);
                        }
                        else//ǿ��
                        {
                            pshm->nodemng_domain[m].neighbors[j].app_info[app_pos] =
                                (pshm->nodemng_domain[m].neighbors[j].app_info[app_pos] & (~RUN_MASK)) + RUN_FORCE_BACK;
                            log_printf(LOG_NORMAL, 41084, "PUBLIC  of host(%s) change to FORCE_BACK by command from %s",
                                       nm_switch_packet->hostname, nm_switch_packet->head.hostname);
                        }
                        break;
                    }
                }
                if (j == MAX_NODE_NUM)
                {
                    log_printf(LOG_WARN, 41085, "PUBLIC is not active in  host(%s) in this node(%s)",
                               nm_switch_packet->hostname, m_hostname);
                }
            }
        }
    }
    DutyCal();
    ClearInValidNode();//����������������Ч�ڵ�
    ClearInValidSerGrp();

    //���¹����ڴ�ʱ��
    pshm->refresh_time.time = nowb.time;
    pshm->refresh_time.millitm = nowb.millitm;
    m_start_up = false;


    return ;

}
int  CNodemngCal::ReadLocalServer(NM_LOCAL_PACKET_SERVER &nm_local_packet)
{
    timeb nowb;
    ftime(&nowb);
    if (m_ni.getNodeType() != CNodeInfo::SERVER)//���Ƿ���˲�����
    {
        return -3;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);
    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    if (pshm->shm_error_flag)//�����ڴ�д���ˣ������ⷢ��
    {
        return HB_SHM_ERROR;
    }
    memset(&nm_local_packet, 0, sizeof(NM_LOCAL_PACKET_SERVER));
    memcpy(nm_local_packet.head.magic, PACKET_LEAD, 6);
    nm_local_packet.local_service_groupId = htonl(m_local_sergrp_id);
    strcpy(nm_local_packet.head.hostname, m_ni.getHostname());
    nm_local_packet.head.packet_type = htonl(LOCAL_REPORT);
    time_t now;
    time(&now);
    nm_local_packet.time = htonl(now);//�ѱ���ʱ�䴫�����Ľṹ��,����ʱ��
    nm_local_packet.local_service_groupId = htonl(m_local_sergrp_id);


    //�ѱ�����public״̬�ŵ����Ͱ���
    nm_local_packet.local_public_report.app_info = pshm->nodemng_public.localhost.app_info;
    nm_local_packet.local_public_report.app_order = pshm->nodemng_public.localhost.app_order;
    nm_local_packet.local_public_report.usage = htonl(pshm->nodemng_public.localhost.usage);
    strcpy(nm_local_packet.local_public_report.hostname, pshm->nodemng_public.localhost.hostname);
    nm_local_packet.local_public_report.host_info = pshm->nodemng_public.localhost.host_info;
    //��neibough��public״̬�ŵ����Ͱ���
    for (int j = 0; j < MAX_NODE_NUM; j++)
    {
        nm_local_packet.neibourgh_public_report[j].app_info = pshm->nodemng_public.neighbors[j].app_info;
        nm_local_packet.neibourgh_public_report[j].app_order = pshm->nodemng_public.neighbors[j].app_order;
        nm_local_packet.neibourgh_public_report[j].usage = htonl(pshm->nodemng_public.neighbors[j].usage);
        strcpy(nm_local_packet.neibourgh_public_report[j].hostname,
               pshm->nodemng_public.neighbors[j].hostname);
        nm_local_packet.neibourgh_public_report[j].host_info = pshm->nodemng_public.neighbors[j].host_info;
    }

    for (int j = 0; j < pshm->domain_count; j++)
    {
        if (pshm->nodemng_domain[j].usage == 0) //��ǰ�򲻿���continue��
        {
            nm_local_packet.nodemng_report[j].usage = htonl(0); //�ö�Ӧ�����е�domain��usageΪ0
            continue;
        }
        nm_local_packet.nodemng_report[j].usage = htonl(1); //�ö�Ӧ�����е�domain��usageΪ1,�ſ���
        nm_local_packet.nodemng_report[j].domain_id = htonl(pshm->nodemng_domain[j].local_domain_id);
        nm_local_packet.nodemng_report[j].host_info = pshm->nodemng_domain[j].localhost.host_info;
        for (int i = 0; i < MAX_APP_NUM; i++)
        {
            nm_local_packet.nodemng_report[j].app_info[i] = pshm->nodemng_domain[j].localhost.app_info[i];
            nm_local_packet.nodemng_report[j].app_order[i] = pshm->nodemng_domain[j].localhost.app_order[i];
        }
    }

    //for(int j=0;j<pshm->domain_count;j++)
    //{
    //  for (int k=0;k<MAX_NODE_NUM;k++)
    //  {
    //      if (pshm->nodemng_domain[j].usage==0)//��ǰ�򲻿���continue��
    //      {
    //          nm_local_packet.neibourgh_report[j][k].usage =htonl(0);//�ö�Ӧ�����е�domain��usageΪ0
    //          continue;
    //      }
    //      nm_local_packet.neibourgh_report[j][k].usage =htonl(pshm->nodemng_domain[j].neighbors[k].usage);
    //      nm_local_packet.neibourgh_report[j][k].domain_id = htonl(pshm->nodemng_domain[j].local_domain_id);
    //      nm_local_packet.neibourgh_report[j][k].host_info = pshm->nodemng_domain[j].neighbors[k].host_info;
    //      strcpy(nm_local_packet.neibourgh_report[j][k].hostname ,pshm->nodemng_domain[j].neighbors[k].hostname);
    //      for(int i=0; i<MAX_APP_NUM; i++)
    //      {
    //          nm_local_packet.neibourgh_report[j][k].app_info[i] = pshm->nodemng_domain[j].neighbors[k].app_info[i];
    //          nm_local_packet.neibourgh_report[j][k].app_order[i] = pshm->nodemng_domain[j].neighbors[k].app_order[i];
    //      }
    //  }
    //}
    m_start_up = false;
    return 1;
}
int  CNodemngCal::ReadLocalClient(NM_LOCAL_PACKET_CLIENT &nm_local_packet)//���͸�client
{
    timeb nowb;
    ftime(&nowb);
    if (m_ni.getNodeType() != CNodeInfo::SERVER)//���Ƿ���˲�����
    {
        return -3;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);
    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    if (pshm->shm_error_flag)//�����ڴ�д���ˣ������ⷢ��
    {
        return HB_SHM_ERROR;
    }
    memset(&nm_local_packet, 0, sizeof(NM_LOCAL_PACKET_CLIENT));
    memcpy(nm_local_packet.head.magic, PACKET_LEAD, 6);
    nm_local_packet.local_service_groupId = htonl(m_local_sergrp_id);
    strcpy(nm_local_packet.head.hostname, m_ni.getHostname());
    nm_local_packet.head.packet_type = htonl(LOCAL_REPORT);
    time_t now;
    time(&now);
    nm_local_packet.time = htonl(now);//�ѱ���ʱ�䴫�����Ľṹ��,����ʱ��
    nm_local_packet.local_service_groupId = htonl(m_local_sergrp_id);


    //�ѱ�����public״̬�ŵ����Ͱ���
    nm_local_packet.local_public_report.app_info = pshm->nodemng_public.localhost.app_info;
    nm_local_packet.local_public_report.app_order = pshm->nodemng_public.localhost.app_order;
    nm_local_packet.local_public_report.usage = htonl(pshm->nodemng_public.localhost.usage);
    strcpy(nm_local_packet.local_public_report.hostname, pshm->nodemng_public.localhost.hostname);
    nm_local_packet.local_public_report.host_info = pshm->nodemng_public.localhost.host_info;
    //��neibough��public״̬�ŵ����Ͱ���
    for (int j = 0; j < MAX_NODE_NUM; j++)
    {
        nm_local_packet.neibourgh_public_report[j].app_info = pshm->nodemng_public.neighbors[j].app_info;
        nm_local_packet.neibourgh_public_report[j].app_order = pshm->nodemng_public.neighbors[j].app_order;
        nm_local_packet.neibourgh_public_report[j].usage = htonl(pshm->nodemng_public.neighbors[j].usage);
        strcpy(nm_local_packet.neibourgh_public_report[j].hostname,
               pshm->nodemng_public.neighbors[j].hostname);
        nm_local_packet.neibourgh_public_report[j].host_info = pshm->nodemng_public.neighbors[j].host_info;
    }

    for (int j = 0; j < pshm->domain_count; j++)
    {
        if (pshm->nodemng_domain[j].usage == 0) //��ǰ�򲻿���continue��
        {
            nm_local_packet.nodemng_report[j].usage = htonl(0); //�ö�Ӧ�����е�domain��usageΪ0
            continue;
        }
        nm_local_packet.nodemng_report[j].usage = htonl(1); //�ö�Ӧ�����е�domain��usageΪ1,�ſ���
        nm_local_packet.nodemng_report[j].domain_id = htonl(pshm->nodemng_domain[j].local_domain_id);
        nm_local_packet.nodemng_report[j].host_info = pshm->nodemng_domain[j].localhost.host_info;
        strcpy(nm_local_packet.nodemng_report[j].hostname, pshm->nodemng_domain[j].localhost.hostname);
        for (int i = 0; i < MAX_APP_NUM; i++)
        {
            nm_local_packet.nodemng_report[j].app_info[i] = pshm->nodemng_domain[j].localhost.app_info[i];
            nm_local_packet.nodemng_report[j].app_order[i] = pshm->nodemng_domain[j].localhost.app_order[i];
        }
    }

    for (int j = 0; j < pshm->domain_count; j++)
    {
        for (int k = 0; k < MAX_NODE_NUM; k++)
        {
            if (pshm->nodemng_domain[j].usage == 0) //��ǰ�򲻿���continue��
            {
                nm_local_packet.neibourgh_report[j][k].usage = htonl(0); //�ö�Ӧ�����е�domain��usageΪ0
                continue;
            }
            nm_local_packet.neibourgh_report[j][k].usage = htonl(pshm->nodemng_domain[j].neighbors[k].usage);
            nm_local_packet.neibourgh_report[j][k].domain_id = htonl(pshm->nodemng_domain[j].local_domain_id);
            nm_local_packet.neibourgh_report[j][k].host_info = pshm->nodemng_domain[j].neighbors[k].host_info;
            strcpy(nm_local_packet.neibourgh_report[j][k].hostname ,
                   pshm->nodemng_domain[j].neighbors[k].hostname);
            for (int i = 0; i < MAX_APP_NUM; i++)
            {
                nm_local_packet.neibourgh_report[j][k].app_info[i] =
                    pshm->nodemng_domain[j].neighbors[k].app_info[i];
                nm_local_packet.neibourgh_report[j][k].app_order[i] =
                    pshm->nodemng_domain[j].neighbors[k].app_order[i];
            }
        }
    }
    m_start_up = false;
    return 1;
}
int  CNodemngCal::ReadRemote(NM_REMOTE_PACKET &nm_remote_packet)
{
    timeb nowb;
    ftime(&nowb);
    if (m_ni.getNodeType() != CNodeInfo::SERVER)//���Ƿ���˲�����
    {
        return -3;
    }
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    if (pshm->shm_error_flag)//�����ڴ�д���ˣ������ⷢ��
    {
        return HB_SHM_ERROR;
    }
    memset(&nm_remote_packet, 0, sizeof(NM_REMOTE_PACKET));
    memcpy(nm_remote_packet.head.magic, PACKET_LEAD, 6);
    nm_remote_packet.local_service_groupId = htonl(m_local_sergrp_id);
    strcpy(nm_remote_packet.head.hostname, m_ni.getHostname());
    nm_remote_packet.head.packet_type = htonl(REMOTE_REPORT);

    time_t now;
    time(&now);
    nm_remote_packet.time = htonl(now);//�ѱ���ʱ�䴫�����Ľṹ��,����ʱ��
    nm_remote_packet.local_service_groupId = htonl(m_local_sergrp_id);

    for (int j = 0; j < pshm->domain_count; j++)
    {
        if (pshm->nodemng_domain[j].usage == 0)
        {
            nm_remote_packet.app_info[j].usage = htonl(0);
            continue;
        }
        for (int i = 0; i < MAX_APP_NUM; i++)
        {
            nm_remote_packet.app_info[j].usage = htonl(1);
            nm_remote_packet.app_info[j].domain_id = htonl(pshm->nodemng_domain[j].local_domain_id);
            if (pshm->nodemng_domain[j].local_domain_apps[i].usage == 1)
            {
                if (pshm->nodemng_domain[j].local_domain_apps[i].duty_host == -1)
                {
                    strcpy(nm_remote_packet.app_info[j].duty_host[i].hostname,
                           pshm->nodemng_domain[j].localhost.hostname);
                    nm_remote_packet.app_info[j].duty_host[i].usage = htonl(1);
                }
                else if (pshm->nodemng_domain[j].local_domain_apps[i].duty_host != -2)
                {
                    strcpy(nm_remote_packet.app_info[j].duty_host[i].hostname,
                           pshm->nodemng_domain[j].neighbors[pshm->nodemng_domain[j].local_domain_apps[i].duty_host].hostname);
                    nm_remote_packet.app_info[j].duty_host[i].usage = htonl(1);
                }
                else
                {
                    nm_remote_packet.app_info[j].duty_host[i].usage = htonl(0);
                }
            }
            else
            {
                nm_remote_packet.app_info[j].duty_host[i].usage = htonl(0);
            }
        }
    }
    if (pshm->nodemng_public.usage == 1)
    {
        if (pshm->nodemng_public.local_domain_apps.duty_host == -1)
        {
            nm_remote_packet.public_info.usage =  htonl(1);
            strcpy(nm_remote_packet.public_info.duty_hostname, pshm->nodemng_public.localhost.hostname);
            //nm_remote_packet.public_info.refresh_time = pshm->nodemng_public.localhost.refresh_time;
        }
    }
    m_start_up = false;
    return 1;
}

int  CNodemngCal::ClearInValidNode()// ��Ҫ�����Ľڵ���
{
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    struct timeb nowb;
    ftime(&nowb);
    bool isSend = false;
    // ��������������ʧЧ�ڵ�
    if (m_pt.TimebCheck(&nowb, &m_last_neighbour_check, &m_neighbour_check_interval) >= 0)
    {
        //if (m_ni.getNodeType() == CNodeInfo::SERVER)//�ж�public
        {
            for (int i = 0; i < MAX_NODE_NUM; i++)
            {
                if (pshm->nodemng_public.neighbors[i].usage == 0)
                {
                    continue;
                }
                if (m_pt.TimebCheck(&nowb, &pshm->nodemng_public.neighbors[i].refresh_time, &m_neighbor_lose) >= 0)
                {
                    //if(!m_start_up)
                    //{
                    //  if((pshm->nodemng_public.localhost.host_info&NETSTATUS_MASK) == NETSTATUS_OK)
                    //      peer_net_alarm(pshm->nodemng_public.neighbors[i].hostname,MENU_SYS_NET_ERROR);
                    //  log_printf(LOG_NORMAL, 41086, "host %s does not send heart beat for long: now %d %d; last %d %d.", pshm->nodemng_public.neighbors[i].hostname,
                    //      nowb.time, nowb.millitm, pshm->nodemng_public.neighbors[i].refresh_time.time, pshm->nodemng_public.neighbors[i].refresh_time.millitm);
                    //}
                    pshm->nodemng_public.neighbors[i].usage = 0;
                    pshm->nodemng_public.neighbors[i].host_info = (pshm->nodemng_public.neighbors[i].host_info &
                            (~NETSTATUS_MASK)) + NETSTATUS_BAD;
                    if (m_ni.getNodeType() == CNodeInfo::SERVER)
                    {
                        DutyCal();
                    }
                }
            }
        }

        for (int j = 0; j < pshm->domain_count; j++)
        {
            if (pshm->nodemng_domain[j].usage == 0) //��ǰ�򲻿���continue��
            {
                continue;
            }
            for (int i = 0; i < MAX_NODE_NUM; i++)
            {
                if (pshm->nodemng_domain[j].neighbors[i].usage == 0)
                {
                    continue;
                }
                if (m_pt.TimebCheck(&nowb, &pshm->nodemng_domain[j].neighbors[i].refresh_time,
                                    &m_neighbor_lose) >= 0)
                {
                    if (!m_start_up)
                    {
                        if ((m_ni.getNodeType() == CNodeInfo::SERVER)
                                && ((pshm->nodemng_domain[j].localhost.host_info & NETSTATUS_MASK) == NETSTATUS_OK) && (!isSend))
                        {
                            peer_net_alarm(pshm->nodemng_domain[j].neighbors[i].hostname, MENU_SYS_NET_ERROR);
                            isSend = true;
                        }
                        log_printf(LOG_NORMAL, 41087, "host %s does not send heart beat for long: now %d %d; last %d %d.",
                                   pshm->nodemng_domain[j].neighbors[i].hostname,
                                   nowb.time, nowb.millitm, pshm->nodemng_domain[j].neighbors[i].refresh_time.time,
                                   pshm->nodemng_domain[j].neighbors[i].refresh_time.millitm);
                    }
                    pshm->nodemng_domain[j].neighbors[i].usage = 0;
                    pshm->nodemng_domain[j].neighbors[i].host_info = (pshm->nodemng_domain[j].neighbors[i].host_info &
                            (~NETSTATUS_MASK)) + NETSTATUS_BAD;

                    DutyCal();
                }
            }
        }

        m_last_neighbour_check.time = nowb.time;
        m_last_neighbour_check.millitm = nowb.millitm;
    }
    //    isSend = false;
    return 1;
}

int  CNodemngCal::ClearInValidSerGrp()//����ʧЧ��������
{
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    struct timeb nowb;
    ftime(&nowb);
    if (m_pt.TimebCheck(&nowb, &m_last_sergrp_check, &m_sergrp_check_interval) >= 0)
    {
        //if (m_ni.getNodeType() == CNodeInfo::SERVER)//�ж�public
        {
            for (int i = 0; i < MAX_SERGRP_NUM; i++)
            {
                if (pshm->remote_sergrp[i].usage == 0)
                {
                    continue;
                }
                if (m_pt.TimebCheck(&nowb, &pshm->remote_sergrp[i].refresh_time, &m_neighbor_lose) >= 0)
                {
                    pshm->remote_sergrp[i].usage = 0;
                    if (m_ni.getNodeType() == CNodeInfo::SERVER)
                    {
                        DutyCal();
                    }
                }
            }
        }

        for (int i = 0; i < MAX_SERGRP_NUM; i++)
        {
            if (pshm->remote_sergrp[i].usage == 0)
            {
                continue;
            }
            if (m_pt.TimebCheck(&nowb, &pshm->remote_sergrp[i].refresh_time, &m_sergrp_lose) >= 0)
            {
                log_printf(LOG_NORMAL, 41088, "domain %d does not send data for long: now %u %u; last %u %u.",
                           pshm->remote_sergrp[i].sergrp_id, nowb.time, nowb.millitm, pshm->remote_sergrp[i].refresh_time.time,
                           pshm->remote_sergrp[i].refresh_time.millitm);
                pshm->remote_sergrp[i].usage = 0;
                DutyCal();
            }
        }
    }

    m_last_sergrp_check.time = nowb.time;
    m_last_sergrp_check.millitm = nowb.millitm;
    return 1;
}

int  CNodemngCal::SetNodeShmError(const char *hostname)//��shmд��ʱ���û���shm��Ч
{
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    for (int j = 0; j < pshm->domain_count; j++)
    {
        if (pshm->nodemng_domain[j].usage == 0) //��ǰ�򲻿���continue��
        {
            continue;
        }
        for (int i = 0; i < MAX_NODE_NUM; i++)
        {
            if (pshm->nodemng_domain[j].neighbors[i].usage == 0)
            {
                continue;
            }
            if (strcmp(pshm->nodemng_domain[j].neighbors[i].hostname, hostname) == 0) //��ʾ�ҵ��˻��Ľڵ�
            {
                pshm->nodemng_domain[j].neighbors[i].usage = 0;
                return 1;
            }
        }
    }
    log_printf(LOG_NORMAL, 41089,
               "can not find this node(%s) in current node(%s),may it not be actived", hostname, m_hostname);
    return 0;
}

struct HOST_APP_INFO
{
    int host_pos;
    unsigned char app_order;
    unsigned char app_status;
    char host_name[64];
};

static bool host_compare(const struct HOST_APP_INFO &first, const struct HOST_APP_INFO &second)
{
    // Solaris�»��ͬһ���ڵ���бȽϣ����뷵��false������ȽϺ���ڴ�ͻ��ҡ�
    // Windows�²����ͬһ���ڵ���бȽϣ����Բ����ߵ����
    if (first.host_pos == second.host_pos)
    {
        return false;
    }
    if ((first.app_status == RUN_FORCE_DUTY)
            && (second.app_status == RUN_FORCE_DUTY)) // �����������ǿ������
    {
        if (first.app_order <= second.app_order)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else if ((first.app_status == RUN_FORCE_DUTY)
             && (second.app_status != RUN_FORCE_DUTY)) // ���1��ǿ������
    {
        return true;
    }
    else if ((first.app_status != RUN_FORCE_DUTY)
             && (second.app_status == RUN_FORCE_DUTY)) // ���2��ǿ������
    {
        return false;
    }
    else if ((first.app_status == RUN_DUTY) && (second.app_status == RUN_DUTY)) // ���������������
    {
        if (first.app_order <= second.app_order)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else if ((first.app_status == RUN_DUTY) && (second.app_status != RUN_DUTY)) // ���1������
    {
        return true;
    }
    else if ((first.app_status != RUN_DUTY) && (second.app_status == RUN_DUTY)) // ���2������
    {
        return false;
    }
    else if ((first.app_status == RUN_BACK) && (second.app_status == RUN_FORCE_BACK))
    {
        return true;
    }
    else if ((first.app_status == RUN_FORCE_BACK) && (second.app_status == RUN_BACK))
    {
        return false;
    }
    else if ((first.app_status == RUN_FORCE_BACK) && (second.app_status == RUN_FORCE_BACK))
    {
        if (first.app_order <= second.app_order)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else if ((first.app_status == RUN_BACK) && (second.app_status == RUN_BACK)) // ������Ǳ���
    {
        if (first.app_order <= second.app_order)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else if (((first.app_status == RUN_BACK) || (first.app_status == RUN_FORCE_BACK))
             && ((second.app_status == RUN_START) || (second.app_status == RUN_STOP)))
    {
        return true;
    }
    else if (((first.app_status == RUN_START) || (first.app_status == RUN_STOP))
             && ((second.app_status == RUN_BACK) || (second.app_status == RUN_FORCE_BACK)))
    {
        return false;
    }

    log_printf(LOG_WARN, 41090, "Not checked situation with first %d and second %d", first.app_status,
               second.app_status);
    return false;
}

int  CNodemngCal::DutyCal()//����������
{
    NODEMNG_SHM *pshm = reinterpret_cast<NODEMNG_SHM *>(m_pshm);

    //NODEMNG_SHM *pshm = (NODEMNG_SHM *)m_pshm;
    struct HOST_APP_INFO hai;
    list<struct HOST_APP_INFO> hostlist;
    list<struct HOST_APP_INFO>::iterator it;
    list<struct HOST_APP_INFO>::iterator it_list;

    int i, j, k;
    string app_name;
    bool public_error =false;


    /*****Ϊ��RequestPublicService��ϵͳ����������**********/
    /***publicӦ�û�û�к�ʱ����Ҫ����public����************/
    /*************�ҵ������������public������**************/
    /*��pshm->nodemng_public.local_domain_apps.usage = 1****/

    //if (pshm->nodemng_public.usage==0)//��ǰ�ڵ�û��public����������ǿͻ���hb_mngû�е���writelocalclient����usage����1
    //{
    //  log_printf(LOG_WARN, 41091, "current node is not running PUBLIC");
    //  return 0;
    //}
    hostlist.clear();
    for (i = 0; i < MAX_NODE_NUM; i++)
    {
        if (pshm->nodemng_public.neighbors[i].usage == 0) // ��һ�����ڽڵ�û���õ���continue
        {
            continue;
        }
        if (pshm->nodemng_public.neighbors[i].app_order == APP_NOT_RUN) // �˽ڵ��ޱ�Ӧ��
        {
            continue;
        }
        if ((pshm->nodemng_public.neighbors[i].app_info & PROCESS_MASK) ==
                PROCESS_BAD) // �˽ڵ㱾Ӧ���йؼ����̴���
        {
            continue;
        }
        if ((pshm->nodemng_public.neighbors[i].host_info & NETSTATUS_MASK) ==
                NETSTATUS_BAD) // �˽ڵ����������
        {
            continue;
        }
        if (((pshm->nodemng_public.neighbors[i].app_info & RUN_MASK) == RUN_FAIL)
                || ((pshm->nodemng_public.neighbors[i].app_info & RUN_MASK) == RUN_START)
                || ((pshm->nodemng_public.neighbors[i].app_info & RUN_MASK) == RUN_STOP)) // ���������������״̬
        {
            continue;
        }
        hai.host_pos = i;
        hai.app_order = pshm->nodemng_public.neighbors[i].app_order;
        hai.app_status = pshm->nodemng_public.neighbors[i].app_info & RUN_MASK;
        strcpy(hai.host_name, pshm->nodemng_public.neighbors[i].hostname);
        log_printf(LOG_SENSOR, 41092,
                   "Print neighbors host info(Public):hostname:%s, host_pos:%d, app_order:%x ,app_status: %x",
                   hai.host_name, hai.host_pos, hai.app_order, hai.app_status);
        hostlist.push_back(hai);
    }
    if ((pshm->nodemng_public.localhost.usage == 1)
            && (pshm->nodemng_public.localhost.app_order != APP_NOT_RUN)
            && ((pshm->nodemng_public.localhost.app_info & PROCESS_MASK) == PROCESS_OK)
            /*&& ((pshm->nodemng_public.localhost.host_info&NETSTATUS_MASK) == NETSTATUS_OK)  && ((pshm->nodemng_public.localhost.extra_info&NET_OK_DELAY_MASK)== NET_OK_DELAY_CLEAR)*/
            && ((pshm->nodemng_public.localhost.app_info & RUN_MASK) != RUN_START)
            && ((pshm->nodemng_public.localhost.app_info & RUN_MASK) != RUN_STOP)
            && ((pshm->nodemng_public.localhost.app_info & RUN_MASK) != RUN_FAIL))
    {
        hai.host_pos = -1;
        hai.app_order = pshm->nodemng_public.localhost.app_order;
        hai.app_status = pshm->nodemng_public.localhost.app_info & RUN_MASK;
        strcpy(hai.host_name, pshm->nodemng_public.localhost.hostname);
        log_printf(LOG_SENSOR, 41093,
                   "Print local host info(Public):hostname:%s, host_pos:%d, app_order:%x ,app_status: %x",
                   hai.host_name, hai.host_pos, hai.app_order, hai.app_status);
        hostlist.push_back(hai);
    }
    else
    {
        log_printf(LOG_SENSOR, 41094,
                   "this local host not to duty_cal(Public) maybe following cause:localhost.usage = %d,app_order = %x,app_info = %x",
                   pshm->nodemng_public.localhost.usage, pshm->nodemng_public.localhost.app_order,
                   pshm->nodemng_public.localhost.app_info);
    }
    if ((pshm->nodemng_public.localhost.app_info & RUN_MASK) == 0x00) //0x00�Ƿ���д���˹����ڴ�
    {
        log_printf(LOG_WARN, 41095, "the shm write the wrong code ,where app = PUBLIC,app_info=0x00");
        pshm->shm_error_flag = true;
        return HB_SHM_ERROR;
    }
    //if ((strncmp(pshm->lead, PACKET_LEAD, 6) != 0)||(strncmp(pshm->middle1, PACKET_LEAD, 6) != 0)||
    //  (strncmp(pshm->middle2, PACKET_LEAD, 6) != 0)||(strncmp(pshm->middle3, PACKET_LEAD, 6) != 0)||
    //  (strncmp(pshm->end, PACKET_LEAD, 6) != 0))
    //{
    //  log_printf(LOG_WARN, 41096, "the shm write the wrong code ,the symbol is not RTNM02");
    //  pshm->shm_error_flag = true;
    //  return HB_SHM_ERROR;
    //}
    if (hostlist.empty()) // ���������û�л�ڵ�
    {
        pshm->nodemng_public.local_domain_apps.usage = 0;
        pshm->nodemng_public.local_domain_apps.duty_host = -2;
        pshm->nodemng_public.local_domain_apps.standby_host[0] = -2;
		public_error =true;
    }
	if (!public_error)
	{
		for (it_list = hostlist.begin(); it_list != hostlist.end(); ++it_list)
		{
			log_printf(LOG_SENSOR, 41097,
				"Before sort(Public):host_name:%s, host_pos:%d, app_order:%x ,app_status: %x", it_list->host_name,
				it_list->host_pos, it_list->app_order, it_list->app_status);
		}
		hostlist.sort(host_compare);
		for (it_list = hostlist.begin(); it_list != hostlist.end(); ++it_list)
		{
			log_printf(LOG_SENSOR, 41098,
				"After sort(Public): host_name:%s,host_pos:%d, app_order:%x ,app_status: %x", it_list->host_name,
				it_list->host_pos, it_list->app_order, it_list->app_status);
		}
		log_printf(LOG_SENSOR, 41099, "Host num(%d)to duty_cal", hostlist.size());
		pshm->nodemng_public.local_domain_apps.duty_host = hostlist.front().host_pos;
		pshm->nodemng_public.local_domain_apps.usage = 1;
		if (pshm->nodemng_public.local_domain_apps.duty_host == -1)
		{
			log_printf(LOG_SENSOR, 41100, "duty host is %s in Public",
				pshm->nodemng_public.localhost.hostname);
		}
		else
		{
			log_printf(LOG_SENSOR, 41101, "duty host is %s in Public",
				pshm->nodemng_public.neighbors[pshm->nodemng_public.local_domain_apps.duty_host].hostname);
		}
		hostlist.pop_front();

		j = 0;
		for (it = hostlist.begin(); it != hostlist.end(); ++it)
		{
			pshm->nodemng_public.local_domain_apps.standby_host[j] = it->host_pos;
			if (pshm->nodemng_public.local_domain_apps.standby_host[j] == -1)
			{
				log_printf(LOG_SENSOR, 41102, "standby host %d is %s in Public", j,
					pshm->nodemng_public.localhost.hostname);
			}
			else
			{
				log_printf(LOG_SENSOR, 41103, "standby host %d is %s in Public", j,
					pshm->nodemng_public.neighbors[pshm->nodemng_public.local_domain_apps.standby_host[j]].hostname);
			}
			j++;
		}
		pshm->nodemng_public.local_domain_apps.standby_host[j] = -2;

		if (pshm->nodemng_public.localhost.app_order != APP_NOT_RUN) // �������״̬��Ҫ�ı�
		{
			if ((((pshm->nodemng_public.localhost.app_info & RUN_MASK) == RUN_DUTY) //��-����
				|| ((pshm->nodemng_public.localhost.app_info & RUN_MASK) == RUN_FORCE_DUTY))
				&& (pshm->nodemng_public.local_domain_apps.duty_host != -1))
			{
				log_printf(LOG_NORMAL, 41104, "duty host is %s with order %d",
					pshm->nodemng_public.neighbors[pshm->nodemng_public.local_domain_apps.duty_host].hostname,
					pshm->nodemng_public.neighbors[pshm->nodemng_public.local_domain_apps.duty_host].app_order);
				log_printf(LOG_NORMAL, 41105, "app PUBLIC on local host change to BACK");
				if (!app_switch_alarm("PUBLIC", "����"))
				{
					log_printf(LOG_WARN, 41106, "Send app_switch_alarm(app PUBLIC change to back) error");
				}

				//if((pshm->nodemng_public.localhost.app_info&PROCESS_MASK) == PROCESS_OK)
				//{
				//  log_printf(LOG_NORMAL, 41107, "app PUBLIC on local host change to BACK");
				//  if(!app_switch_alarm("PUBLIC", "����"))
				//  {
				//      log_printf(LOG_WARN, 41108, "Send app_switch_alarm(app PUBLIC change to back) error");
				//  }
				//}
				//else
				//{
				//  log_printf(LOG_NORMAL, 41109, "app PUBLIC on local host change to BACK due to process turn bad");
				//  if(!app_switch_alarm("PUBLIC", "�쳣(���̹���)"))
				//  {
				//      log_printf(LOG_WARN, 41110, "Send app_switch_alarm(app PUBLIC change to back) error");
				//  }

				//}
				pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
					(~RUN_MASK)) + RUN_BACK;
			}
			if (((pshm->nodemng_public.localhost.app_info & RUN_MASK) == RUN_BACK) //��-����
				&& (pshm->nodemng_public.local_domain_apps.duty_host == -1))
			{
				log_printf(LOG_NORMAL, 41111, "app PUBLIC on local host change to DUTY");
				if (!app_switch_alarm("PUBLIC", "����"))
				{
					log_printf(LOG_WARN, 41112, "Send app_switch_alarm(app PUBLIC change to duty) error");
				}
				pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
					(~RUN_MASK)) + RUN_DUTY;
			}
			if ((((pshm->nodemng_public.localhost.app_info & RUN_MASK) ==
				RUN_FORCE_BACK)) //ǿ��---������Ҫ��һ��ʱ��
				&& (pshm->nodemng_public.local_domain_apps.duty_host == -1))
			{
				if (g_count_force_back_public < 5)
					;
				else
				{
					log_printf(LOG_NORMAL, 41113, "app PUBLIC on local host from RUN_FORCE_BACK change to DUTY");
					if (!app_switch_alarm("PUBLIC", "����"))
					{
						log_printf(LOG_WARN, 41114, "Send app_switch_alarm(app PUBLIC change to duty) error");
					}
					pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
						(~RUN_MASK)) + RUN_DUTY;
				}
			}

			if (((pshm->nodemng_public.localhost.app_info & RUN_MASK) == RUN_FORCE_DUTY) //ǿ��-����
				&& (pshm->nodemng_public.local_domain_apps.duty_host == -1))
			{
				if (g_count_force_duty_public < 5)
					;
				else
				{
					log_printf(LOG_NORMAL, 41115, "app PUBLIC on local host from RUN_FORCE_DUTY change to DUTY");
					if (!app_switch_alarm("PUBLIC", "����"))
					{
						log_printf(LOG_WARN, 41116,
							"Send app_switch_alarm(app PUBLIC from force_duty change to duty) error");
					}
					pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
						(~RUN_MASK)) + RUN_DUTY;
				}
			}
			if (((pshm->nodemng_public.localhost.app_info & RUN_MASK) == RUN_FORCE_BACK) //ǿ��-����
				&& (pshm->nodemng_public.local_domain_apps.duty_host != -1))
			{
				if (g_count_force_back_public < 5)
					;
				else
				{
					log_printf(LOG_NORMAL, 41117, "app PUBLIC on local host from RUN_FORCE_BACK change to BACK");
					if (!app_switch_alarm("PUBLIC", "����"))
					{
						log_printf(LOG_WARN, 41118,
							"Send app_switch_alarm(app PUBLIC from force_back change to back) error");
					}
					pshm->nodemng_public.localhost.app_info = (pshm->nodemng_public.localhost.app_info &
						(~RUN_MASK)) + RUN_BACK;
				}
			}
		}



	}




    for (k = 0; k < pshm->domain_count; k++)
    {
        if (pshm->nodemng_domain[k].usage == 0) //��ǰ�򲻿���continue��
        {
            continue;
        }
        for (i = 0; i < MAX_APP_NUM; i++)
        {
            if (i == PUBLIC)
            {
                continue;
            }
            hostlist.clear();
            for (j = 0; j < MAX_NODE_NUM; j++)
            {
                if (pshm->nodemng_domain[k].neighbors[j].usage == 0) // �޴˽ڵ�
                {
                    continue;
                }
                if (pshm->nodemng_domain[k].neighbors[j].app_order[i] == APP_NOT_RUN) // �˽ڵ��ޱ�Ӧ��
                {
                    continue;
                }
                if ((pshm->nodemng_domain[k].neighbors[j].app_info[i]&PROCESS_MASK) ==
                        PROCESS_BAD) // �˽ڵ㱾Ӧ���йؼ����̴���
                {
                    continue;
                }
                if ((pshm->nodemng_domain[k].neighbors[j].host_info & NETSTATUS_MASK) ==
                        NETSTATUS_BAD) // �˽ڵ����������
                {
                    continue;
                }
                if (((pshm->nodemng_domain[k].neighbors[j].app_info[i]&RUN_MASK) == RUN_FAIL)
                        || ((pshm->nodemng_domain[k].neighbors[j].app_info[i]&RUN_MASK) == RUN_START)
                        || ((pshm->nodemng_domain[k].neighbors[j].app_info[i]&RUN_MASK) ==
                            RUN_STOP))  // ���������������״̬
                {
                    continue;
                }
                hai.host_pos = j;
                hai.app_order = pshm->nodemng_domain[k].neighbors[j].app_order[i];
                hai.app_status = pshm->nodemng_domain[k].neighbors[j].app_info[i] & RUN_MASK;
                strcpy(hai.host_name, pshm->nodemng_domain[k].neighbors[j].hostname);
                log_printf(LOG_SENSOR, 41119,
                           "Print neighbors host info:hostname:%s, host_pos:%d, app_order:%x ,app_status: %x",
                           pshm->nodemng_domain[k].neighbors[j].hostname, hai.host_pos, hai.app_order, hai.app_status);
                hostlist.push_back(hai);
            }
            if ((pshm->nodemng_domain[k].localhost.usage == 1)
                    && (pshm->nodemng_domain[k].localhost.app_order[i] != APP_NOT_RUN)
                    && ((pshm->nodemng_domain[k].localhost.app_info[i]&PROCESS_MASK) == PROCESS_OK)
                    /*&& ((pshm->nodemng_domain[k].localhost.host_info&NETSTATUS_MASK) == NETSTATUS_OK)  && ((pshm->nodemng_domain[k].localhost.extra_info&NET_OK_DELAY_MASK)== NET_OK_DELAY_CLEAR)*/
                    && ((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) != RUN_START)
                    && ((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) != RUN_STOP)
                    && ((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) != RUN_FAIL))
            {
                hai.host_pos = -1;
                hai.app_order = pshm->nodemng_domain[k].localhost.app_order[i];
                hai.app_status = pshm->nodemng_domain[k].localhost.app_info[i] & RUN_MASK;
                strcpy(hai.host_name, pshm->nodemng_domain[k].localhost.hostname);
                log_printf(LOG_SENSOR, 41120,
                           "Print local host info :hostname:%s, host_pos:%d, app_order:%x ,app_status: %x",
                           pshm->nodemng_domain[k].localhost.hostname, hai.host_pos, hai.app_order, hai.app_status);
                hostlist.push_back(hai);
            }
            else
            {
                log_printf(LOG_SENSOR, 41121,
                           "this local host not to duty_cal maybe following cause:localhost.usage = %d,app_order = %x,app_info = %x",
                           pshm->nodemng_domain[k].localhost.usage, pshm->nodemng_domain[k].localhost.app_order[i],
                           pshm->nodemng_domain[k].localhost.app_info[i]);
            }
            if ((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) == 0x00) //0x00�Ƿ���д���˹����ڴ�
            {
                log_printf(LOG_WARN, 41122, "the shm write the wrong code ,where app_id=%d,app_info=0x00", i);
                pshm->shm_error_flag = true;
                return HB_SHM_ERROR;
            }
            if (hostlist.empty()) // ���������û�л�ڵ�
            {
                pshm->nodemng_domain[k].local_domain_apps[i].usage = 0;
                pshm->nodemng_domain[k].local_domain_apps[i].duty_host = -2;
                pshm->nodemng_domain[k].local_domain_apps[i].standby_host[0] = -2;
                continue;
            }
            for (it_list = hostlist.begin(); it_list != hostlist.end(); ++it_list)
            {
                log_printf(LOG_SENSOR, 41123,
                           "Before sort(app_id =%d,domain_id =%d):host_name:%s ,host_pos:%d, app_order:%x ,app_status: %x", i,
                           pshm->nodemng_domain[k].local_domain_id, it_list->host_name, it_list->host_pos, it_list->app_order,
                           it_list->app_status);
            }
            hostlist.sort(host_compare);
            for (it_list = hostlist.begin(); it_list != hostlist.end(); ++it_list)
            {
                log_printf(LOG_SENSOR, 41124,
                           "After sort(app_id =%d,domain_id =%d): host_name:%s ,host_pos:%d, app_order:%x ,app_status: %x", i,
                           pshm->nodemng_domain[k].local_domain_id, it_list->host_name, it_list->host_pos, it_list->app_order,
                           it_list->app_status);
            }
            log_printf(LOG_SENSOR, 41125, "host num(%d) to duty_cal", hostlist.size());
            pshm->nodemng_domain[k].local_domain_apps[i].duty_host = hostlist.front().host_pos;
            pshm->nodemng_domain[k].local_domain_apps[i].usage = 1;
            if (pshm->nodemng_domain[k].local_domain_apps[i].duty_host == -1)
            {
                log_printf(LOG_SENSOR, 41126, "duty host is %s in app: %d",
                           pshm->nodemng_domain[k].localhost.hostname, i);
            }
            else
            {
                log_printf(LOG_SENSOR, 41127, "duty host is %s in app: %d",
                           pshm->nodemng_domain[k].neighbors[pshm->nodemng_domain[k].local_domain_apps[i].duty_host].hostname,
                           i);
            }
            hostlist.pop_front();

            j = 0;
            for (it = hostlist.begin(); it != hostlist.end(); ++it)
            {
                pshm->nodemng_domain[k].local_domain_apps[i].standby_host[j] = it->host_pos;
                if (pshm->nodemng_domain[k].local_domain_apps[i].standby_host[j] == -1)
                {
                    log_printf(LOG_SENSOR, 41128, "standby host %d is %s in app: %d", j,
                               pshm->nodemng_domain[k].localhost.hostname, i);
                }
                else
                {
                    log_printf(LOG_SENSOR, 41129, "standby host %d is %s in app: %d", j,
                               pshm->nodemng_domain[k].neighbors[pshm->nodemng_domain[k].local_domain_apps[i].standby_host[j]].hostname,
                               i);
                }
                j++;
            }
            pshm->nodemng_domain[k].local_domain_apps[i].standby_host[j] = -2;

            if (pshm->nodemng_domain[k].localhost.app_order[i] != APP_NOT_RUN) // �������״̬��Ҫ�ı�
            {
                if ((((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) == RUN_DUTY)
                        || ((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) == RUN_FORCE_DUTY))
                        && (pshm->nodemng_domain[k].local_domain_apps[i].duty_host != -1))
                {
                    log_printf(LOG_NORMAL, 41130, "duty host is %s with order %d",
                               pshm->nodemng_domain[k].neighbors[pshm->nodemng_domain[k].local_domain_apps[i].duty_host].hostname,
                               pshm->nodemng_domain[k].neighbors[pshm->nodemng_domain[k].local_domain_apps[i].duty_host].app_order[i]);
                    if (m_si.GetAppNameByNo(i, app_name) < 0)
                    {
                        log_printf(LOG_NORMAL, 41131, "app %d on local host change to BACK", i);
                        if (!app_switch_alarm(i, "����"))
                        {
                            log_printf(LOG_WARN, 41132, "Send app_switch_alarm(change to back) error,app_id =%d", i);
                        }
                    }
                    else
                    {
                        log_printf(LOG_NORMAL, 41133, "app %s on local host change to BACK", app_name.c_str());
                        if (!app_switch_alarm(app_name.c_str(), "����"))
                        {
                            log_printf(LOG_WARN, 41134, "Send app_switch_alarm(change to back) error,app_name =%s",
                                       app_name.c_str());
                        }
                    }

                    //if ((pshm->nodemng_domain[k].localhost.app_info[i]&PROCESS_MASK) == PROCESS_OK)
                    //               {
                    //  if(m_si.GetAppNameByNo(i, app_name) < 0)
                    //  {
                    //      log_printf(LOG_NORMAL, 41135, "app %d on local host change to BACK", i);
                    //      if(!app_switch_alarm(i, "����"))
                    //      {
                    //          log_printf(LOG_WARN, 41136, "Send app_switch_alarm(change to back) error,app_id =%d",i);
                    //      }
                    //  }
                    //  else
                    //  {
                    //      log_printf(LOG_NORMAL, 41137, "app %s on local host change to BACK", app_name.c_str());
                    //      if(!app_switch_alarm(app_name.c_str(), "����"))
                    //      {
                    //          log_printf(LOG_WARN, 41138, "Send app_switch_alarm(change to back) error,app_name =%s",app_name.c_str());
                    //      }
                    //  }
                    //               }
                    //else
                    //{
                    //  if(m_si.GetAppNameByNo(i, app_name) < 0)
                    //  {
                    //      log_printf(LOG_NORMAL, 41139, "app %d on local host change to BACK due to process turn bad", i);
                    //      if(!app_switch_alarm(i, "�쳣(���̹���)"))
                    //      {
                    //          log_printf(LOG_WARN, 41140, "Send app_switch_alarm(change to back) error,app_id =%d",i);
                    //      }
                    //  }
                    //  else
                    //  {
                    //      log_printf(LOG_NORMAL, 41141, "app %s on local host change to BACK due to process turn bad", app_name.c_str());
                    //      if(!app_switch_alarm(app_name.c_str(), "�쳣(���̹���)"))
                    //      {
                    //          log_printf(LOG_WARN, 41142, "Send app_switch_alarm(change to back) error,app_name =%s",app_name.c_str());
                    //      }
                    //  }
                    //}
                    pshm->nodemng_domain[k].localhost.app_info[i] = (pshm->nodemng_domain[k].localhost.app_info[i] &
                            (~RUN_MASK)) + RUN_BACK;
                }
                //if((((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) == RUN_BACK)
                //  || ((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) == RUN_FORCE_BACK))
                //  && (pshm->nodemng_domain[k].local_domain_apps[i].duty_host == -1))
                //{

                //  if(m_si.GetAppNameByNo(i, app_name) < 0)
                //  {
                //      log_printf(LOG_NORMAL, 41143, "app %d on local host change to DUTY", i);
                //      if(!app_switch_alarm(i, "����"))
                //      {
                //          log_printf(LOG_WARN, 41144, "Send app_switch_alarm(change to duty) error,app_id =%d",i);
                //      }
                //  }
                //  else
                //  {
                //      log_printf(LOG_NORMAL, 41145, "app %s on local host change to DUTY", app_name.c_str());
                //      if(!app_switch_alarm(app_name.c_str(), "����"))
                //      {
                //          log_printf(LOG_WARN, 41146, "Send app_switch_alarm(change to duty) error,app_name =%s",app_name.c_str());
                //      }
                //  }
                //  pshm->nodemng_domain[k].localhost.app_info[i] = (pshm->nodemng_domain[k].localhost.app_info[i]&(~RUN_MASK)) + RUN_DUTY;
                //}

                if (((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) == RUN_BACK)
                        && (pshm->nodemng_domain[k].local_domain_apps[i].duty_host == -1))
                {

                    if (m_si.GetAppNameByNo(i, app_name) < 0)
                    {
                        log_printf(LOG_NORMAL, 41147, "app %d on local host change to DUTY", i);
                        if (!app_switch_alarm(i, "����"))
                        {
                            log_printf(LOG_WARN, 41148, "Send app_switch_alarm(change to duty) error,app_id =%d", i);
                        }
                    }
                    else
                    {
                        log_printf(LOG_NORMAL, 41149, "app %s on local host change to DUTY", app_name.c_str());
                        if (!app_switch_alarm(app_name.c_str(), "����"))
                        {
                            log_printf(LOG_WARN, 41150, "Send app_switch_alarm(change to duty) error,app_name =%s",
                                       app_name.c_str());
                        }
                    }
                    pshm->nodemng_domain[k].localhost.app_info[i] = (pshm->nodemng_domain[k].localhost.app_info[i] &
                            (~RUN_MASK)) + RUN_DUTY;
                }

                if ((((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) == RUN_FORCE_BACK))
                        && (pshm->nodemng_domain[k].local_domain_apps[i].duty_host == -1))
                {
                    if (g_count_force_back < 5)
                    {
                        continue;
                    }
                    if (m_si.GetAppNameByNo(i, app_name) < 0)
                    {
                        log_printf(LOG_NORMAL, 41151, "app %d on local host change to DUTY", i);
                        if (!app_switch_alarm(i, "����"))
                        {
                            log_printf(LOG_WARN, 41152, "Send app_switch_alarm(change to duty) error,app_id =%d", i);
                        }
                    }
                    else
                    {
                        log_printf(LOG_NORMAL, 41153, "app %s on local host change to DUTY", app_name.c_str());
                        if (!app_switch_alarm(app_name.c_str(), "����"))
                        {
                            log_printf(LOG_WARN, 41154, "Send app_switch_alarm(change to duty) error,app_name =%s",
                                       app_name.c_str());
                        }
                    }
                    pshm->nodemng_domain[k].localhost.app_info[i] = (pshm->nodemng_domain[k].localhost.app_info[i] &
                            (~RUN_MASK)) + RUN_DUTY;
                }
                //��ǿ������ǿ�����������߱�
                if (((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) == RUN_FORCE_DUTY)
                        && (pshm->nodemng_domain[k].local_domain_apps[i].duty_host == -1))
                {
                    if (g_count_force_duty < 5)
                    {
                        continue;
                    }
                    if (m_si.GetAppNameByNo(i, app_name) < 0)
                    {
                        if (!app_switch_alarm(i, "����"))
                        {
                            log_printf(LOG_WARN, 41155,
                                       "Send app_switch_alarm(from force_duty change to duty) error,app_id =%d", i);
                        }
                        log_printf(LOG_NORMAL, 41156, "app %d on local host from FORCE_DUTY change to DUTY", i);
                    }
                    else
                    {
                        if (!app_switch_alarm(app_name.c_str(), "����"))
                        {
                            log_printf(LOG_WARN, 41157,
                                       "Send app_switch_alarm(from force_duty change to duty) error,app_name =%s", app_name.c_str());
                        }
                        log_printf(LOG_NORMAL, 41158, "app %s on local host from FORCE_DUTY change to DUTY",
                                   app_name.c_str());
                    }
                    pshm->nodemng_domain[k].localhost.app_info[i] = (pshm->nodemng_domain[k].localhost.app_info[i] &
                            (~RUN_MASK)) + RUN_DUTY;
                }
                if (((pshm->nodemng_domain[k].localhost.app_info[i]&RUN_MASK) == RUN_FORCE_BACK)
                        && (pshm->nodemng_domain[k].local_domain_apps[i].duty_host != -1))
                {
                    if (g_count_force_back < 5)
                    {
                        continue;
                    }
                    if (m_si.GetAppNameByNo(i, app_name) < 0)
                    {
                        log_printf(LOG_NORMAL, 41159, "app %d on local host from FORCE_BACK change to BACK", i);
                        if (!app_switch_alarm(i, "����"))
                        {
                            log_printf(LOG_WARN, 41160,
                                       "Send app_switch_alarm(from force_back change to back) error,app_id =%d", i);
                        }
                    }
                    else
                    {
                        if (!app_switch_alarm(app_name.c_str(), "����"))
                        {
                            log_printf(LOG_WARN, 41161,
                                       "Send app_switch_alarm(from force_back change to back) error,app_name =%s", app_name.c_str());
                        }
                        log_printf(LOG_NORMAL, 41162, "app %s on local host from FORCE_BACK change to BACK",
                                   app_name.c_str());
                    }
                    pshm->nodemng_domain[k].localhost.app_info[i] = (pshm->nodemng_domain[k].localhost.app_info[i] &
                            (~RUN_MASK)) + RUN_BACK;
                }
            }
        }
    }

    return 0;
}

