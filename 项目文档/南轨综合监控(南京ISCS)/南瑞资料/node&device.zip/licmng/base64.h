#pragma once

#include <string>

char *b64_encode(char *input_string, int length);
char *b64_decode(char *input_string, int length);

void  b64_encode_std( const std::string &input_string, std::string &output_string);
void  b64_decode_std( const std::string &input_string, std::string &output_string);

int   host_uuid_md5( const char *input_string, std::string &output_string);