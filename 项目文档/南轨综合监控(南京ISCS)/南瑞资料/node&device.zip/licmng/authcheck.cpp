#include "libhostuuid.h"
#include "libuuidcrypt.h"
#include <string.h>
#include "libpub.h"
#include "shmkey_define.h"
#include "nodemng_def.h"
#ifdef _SUN
#include <unistd.h>
#endif

int main(int argc, char **argv)
{
    char hostname[256];
#ifdef WIN32
    WORD wVersionRequested;
    WSADATA wsaData;

    wVersionRequested = MAKEWORD(1, 1);
    WSAStartup(wVersionRequested, &wsaData);
#endif
    if (gethostname(hostname, 256) != 0)
    {
        printf("Can not get hostname.\n");
        return -1;
    }
    //��ʼ����ѵ̬
    rt21_context_init(argc, argv);
    if (rt21_context_sim())//��ѵ̬
    {
        argc = argc - 1; //��������֮��ԭ�����еĶ�������Ҫ�䶯
    }

    std::string hostid;
	CHostUuid hid;
	hid.openLogFile();
	if (argc>1)
	{
		printf("usage authcheck ,no argues!!!\n");
        return -1;
	}

	if ((argc==3)&&(strcmp(argv[1],"-code")==0))
	{
            hostid= string(argv[2]);
	}
	else
	{
		if (hid.getHostUuid(hostid) != 0)
		{
			printf("Can not get host id\n");
			return -1;
		}
	}
    CUuidCrypt uc;
    std::string ciphertext;
    if (uc.md5Crypt("RT21", "9987", hostid, ciphertext) != 0)
    {
        printf("Get cipher text error\n");
        return -1;
    }
	if (((argc==3)&&(strcmp(argv[1],"-code")==0))||((argc==2)&&(strcmp(argv[1],"-v")==0)))
	{
		printf("----------hostid =%s.............ciphertext is %s--------\n",hostid.c_str(),ciphertext.c_str());
	}
    char lic_file_name[1024];
    char prt21_home[64];
    if (CPubCommon::getSysHomeEnv(prt21_home) < 0)
    {
        return -1;
    }
    //char *prt21_home;
    //prt21_home = getenv("RT21_HOME");
    //if(prt21_home == NULL)
    //{
    //  printf("RT21_HOME is not set.\n");
    //  return -1;
    //}
    if (!rt21_context_sim())//��ʾ��ʵʱ̬
    {
        sprintf(lic_file_name, "%s/sys/license/%s.lic", prt21_home, hostname);
    }
    else
    {
        sprintf(lic_file_name, "%s/sys_sim/license/%s.lic", prt21_home, hostname);
    }

    FILE *fp;
    fp = fopen(lic_file_name, "r");
    if (fp == NULL)
    {
        printf("Can not find license, check %s\n", lic_file_name);
        return -1;
    }
    char lictext[1024];
    if (fgets(lictext, 1024, fp) == NULL)
    {
        printf("license error, check %s\n", lic_file_name);
        fclose(fp);
        return -1;
    }
    fclose(fp);
    if (strncmp(ciphertext.c_str(), lictext, 54) != 0)
    {
        printf("license invalid.\n");
        return -1;
    }

    CShm cshm;
    struct NODEMNG_SHM *pns;
    pns = (struct NODEMNG_SHM *)cshm.AttachShm("nodemng", sizeof(struct NODEMNG_SHM));
    if (pns == NULL)
    {
        printf("Can not authorize.\n");
        return -1;
    }
    pns->host_validation = 0x21;
    printf("Authorized OK.\n");
    return 0;
}
