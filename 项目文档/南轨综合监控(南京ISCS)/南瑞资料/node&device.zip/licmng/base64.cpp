
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>
#include <openssl/md5.h>
#include <string>

#ifndef WIN32
#include <strings.h>
#endif


/*
 *  Encode a string to base64 and return it
 *  */
char *b64_encode(char *input_string, int length)
{
    BIO *bmem = NULL, *b64 = NULL;
    BUF_MEM *bptr = NULL;
    char *buff = NULL;

    b64 = BIO_new(BIO_f_base64());
    bmem = BIO_new(BIO_s_mem());
    b64 = BIO_push(b64, bmem);
    BIO_write(b64, input_string, length);
    BIO_flush(b64);
    BIO_get_mem_ptr(b64, &bptr);

    buff = (char *)malloc(bptr->length);

#ifdef _WIN32
    memset(buff, 0, sizeof(char *));
    memcpy(buff, bptr->data, bptr->length - 1);
#else
    bzero(buff, sizeof(char *));
    sprintf(buff, "%s", bptr->data);
#endif

    buff[bptr->length - 1] = '\0';
    BIO_free_all(b64);
    return buff;
}



void  b64_encode_std( const std::string &input_string, std::string &output_string)
{
    BIO *bmem = NULL, *b64 = NULL;
    BUF_MEM *bptr = NULL;
    char *buff = NULL;

    b64 = BIO_new(BIO_f_base64());
    bmem = BIO_new(BIO_s_mem());
    b64 = BIO_push(b64, bmem);
    BIO_write(b64, input_string.c_str(), input_string.length());
    BIO_flush(b64);
    BIO_get_mem_ptr(b64, &bptr);

    buff = (char *)malloc(bptr->length);

#ifdef _WIN32
    memset(buff, 0, sizeof(char *));
    memcpy(buff, bptr->data, bptr->length - 1);
#else
    bzero(buff, sizeof(char *));
    sprintf(buff, "%s", bptr->data);
#endif

    buff[bptr->length - 1] = '\0';
    BIO_free_all(b64);
    output_string.clear();
    output_string = buff;
    free( buff );
    //      return buff;
}

/*
 *  Decode a string to plain text and return it
 *  */
char *b64_decode(char *input_string, int length)
{
    BIO *b64, *bmem;

    char *buffer = (char *)malloc(strlen(input_string));
    memset(buffer, 0, length);

    b64 = BIO_new(BIO_f_base64());
    bmem = BIO_new_mem_buf(input_string, length);
    bmem = BIO_push(b64, bmem);

    BIO_read(bmem, buffer, length);

    BIO_free_all(bmem);
    return buffer;
}

void  b64_decode_std( const std::string &input_string, std::string &output_string)
{
    BIO *b64, *bmem;

    char *buffer = (char *)malloc( input_string.length() );
    memset(buffer, 0, input_string.length() );

    b64 = BIO_new(BIO_f_base64());
    bmem = BIO_new_mem_buf((void *)input_string.c_str(), input_string.length());
    bmem = BIO_push(b64, bmem);

    BIO_read(bmem, buffer, input_string.length());

    BIO_free_all(bmem);
    output_string.clear();
    output_string = buffer;
    free( buffer );
    //    return buffer;
}


int  host_uuid_md5( const char *input_string, std::string &output_string)
{
    MD5_CTX ctx;
    unsigned char md[MD5_DIGEST_LENGTH];
    char buf[33];
    char tmp_str[3];

    memset( buf, 0, sizeof( buf) );
    MD5_Init(&ctx);
    MD5_Update(&ctx, ( const unsigned char *)input_string, strlen(input_string));
    MD5_Final(md, &ctx);

    for ( int i = 0; i < 16; i++ )
    {
        memset( tmp_str, 0 , sizeof( tmp_str ) );
        sprintf(tmp_str, "%02X", md[i]);
        strcat(buf, tmp_str);
    }
    output_string = buf;
    return 0;

}