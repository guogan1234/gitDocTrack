#include "gethostid.h"
#include <stdio.h>
#include <string.h>
#include <algorithm>

#if defined WIN32
#include <winsock2.h>
#include <iphlpapi.h>
#include <comdef.h>
#include <Wbemidl.h>
#pragma comment(lib, "IPHLPAPI.lib")
#pragma comment(lib, "wbemuuid.lib")
#define MALLOC(x) HeapAlloc(GetProcessHeap(), 0, (x))
#define FREE(x) HeapFree(GetProcessHeap(), 0, (x))

#elif defined  (_SUN)
#include <unistd.h>
#include <errno.h>
#elif defined (_IBM)
#include <sys/utsname.h>
#include <stdarg.h>
extern "C" {
    int unamex (struct xutsname *Name);
}
#elif defined (_LINUX)
#include <sys/types.h>
#include <sys/param.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/in.h>
#include <net/if_arp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>
#else
#error "not supported OS"
#endif

#define  MAX_HOST_BUFFER_LEN 128
FILE       *g_pErrorLogFd = NULL;

#ifdef WIN32
int getMacAddress( std::string &hostid)
{
    PIP_ADAPTER_INFO pAdapterInfo;
    PIP_ADAPTER_INFO pAdapter = NULL;
    DWORD dwRetVal = 0;
    unsigned int i;
    int retcode = 1;
    ULONG ulOutBufLen = sizeof (IP_ADAPTER_INFO);
    pAdapterInfo = (IP_ADAPTER_INFO *) MALLOC(sizeof (IP_ADAPTER_INFO));
    if (pAdapterInfo == NULL)
    {
        print_error_log( __FILE__, __LINE__,
                         "Win32 Error allocating memory needed to call GetAdaptersinfo\n");
        return 1;
    }
    if (GetAdaptersInfo(pAdapterInfo, &ulOutBufLen) == ERROR_BUFFER_OVERFLOW)
    {
        FREE(pAdapterInfo);
        pAdapterInfo = (IP_ADAPTER_INFO *) MALLOC(ulOutBufLen);
        if (pAdapterInfo == NULL)
        {
            print_error_log( __FILE__, __LINE__,
                             "Win32 Error allocating memory needed to call GetAdaptersinfo\n");
            return 1;
        }
    }

    if ((dwRetVal = GetAdaptersInfo(pAdapterInfo, &ulOutBufLen)) == NO_ERROR)
    {
        pAdapter = pAdapterInfo;
        while (pAdapter)
        {
            if ( pAdapter->Type == MIB_IF_TYPE_ETHERNET )
            {
                char buffer[MAX_HOST_BUFFER_LEN];
                char *p = buffer;
                for ( i = 0; i < pAdapterInfo->AddressLength; i++)
                {
                    _snprintf( p, MAX_HOST_BUFFER_LEN - 2 * i, "%.2X",  (int) pAdapter->Address[i]);
                    p += 2;
                }
                hostid = buffer;
                retcode = 0;
                print_error_log( __FILE__, __LINE__, "Success Win32 GetAdaptersinfo :%s \n", pAdapter->Description);
                break;
            }
            else
            {
                print_error_log(__FILE__, __LINE__, "pAdapter name : %s is not eth\n", pAdapter->Description);
                continue;
            }
            pAdapter = pAdapter->Next;
        }
    }
    else
    {
        print_error_log( __FILE__, __LINE__, "GetAdaptersInfo failed with error: %d\n", dwRetVal);
    }
    if (pAdapterInfo)
    {
        FREE(pAdapterInfo);
    }
    return retcode;
}

int getuuid( std::string &hostid)
{
    HRESULT hres;
    // Initialize COM.
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED);
    if (FAILED(hres))
    {
        print_error_log( __FILE__, __LINE__, "Failed to initialize COM library. Error code = %x\n", hres);
        return 1;
    }

    // Initialize
    hres =  CoInitializeSecurity(
                NULL,
                -1,      // COM negotiates service
                NULL,    // Authentication services
                NULL,    // Reserved
                RPC_C_AUTHN_LEVEL_DEFAULT,    // authentication
                RPC_C_IMP_LEVEL_IMPERSONATE,  // Impersonation
                NULL,             // Authentication info
                EOAC_NONE,        // Additional capabilities
                NULL              // Reserved
            );


    if (FAILED(hres))
    {
        print_error_log( __FILE__, __LINE__,  "Failed to initialize security. Error code = %x\n", hres);
        CoUninitialize();
        return 1;
    }

    IWbemLocator *pLoc = 0;
    hres = CoCreateInstance(
               CLSID_WbemLocator,
               0,
               CLSCTX_INPROC_SERVER,
               IID_IWbemLocator, (LPVOID *) &pLoc);

    if (FAILED(hres))
    {
        print_error_log( __FILE__, __LINE__,  "Failed to create IWbemLocator object.  Error code = %x\n",
                         hres );
        CoUninitialize();
        return 1;
    }
    print_error_log( __FILE__, __LINE__,  "windows trace program 111\n");
    IWbemServices *pSvc = 0;
    // Connect to the root\cimv2 namespace with the
    // current user and obtain pointer pSvc
    // to make IWbemServices calls.
    hres = pLoc->ConnectServer(
               _bstr_t(L"ROOT\\CIMV2"), // WMI namespace
               NULL,                    // User name
               NULL,                    // User password
               0,                       // Locale
               NULL,                    // Security flags
               0,                       // Authority
               0,                       // Context object
               &pSvc                    // IWbemServices proxy
           );

    if (FAILED(hres))
    {
        print_error_log( __FILE__, __LINE__,  "Could not connect. Error code = %x\n" , hres);
        pLoc->Release();
        CoUninitialize();
        return 1;                // Program has failed.
    }
    // Connected to ROOT\\CIMV2 WMI namespace
    print_error_log( __FILE__, __LINE__,  "windows trace program 222\n");
    // Set the IWbemServices proxy so that impersonation
    // of the user (client) occurs.
    hres = CoSetProxyBlanket(
               pSvc,                         // the proxy to set
               RPC_C_AUTHN_WINNT,            // authentication service
               RPC_C_AUTHZ_NONE,             // authorization service
               NULL,                         // Server principal name
               RPC_C_AUTHN_LEVEL_CALL,       // authentication level
               RPC_C_IMP_LEVEL_IMPERSONATE,  // impersonation level
               NULL,                         // client identity
               EOAC_NONE                     // proxy capabilities
           );

    if (FAILED(hres))
    {
        print_error_log( __FILE__, __LINE__,  "Could not set proxy blanket. Error code = %x\n" , hres);
        pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return 1;
    }

    // ��ȡUUid
    IEnumWbemClassObject *pEnumerator = NULL;
    hres = pSvc->ExecQuery(
               bstr_t("WQL"),
               bstr_t("SELECT * FROM Win32_ComputerSystemProduct"),
               WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
               NULL,
               &pEnumerator);

    if (FAILED(hres))
    {
        print_error_log( __FILE__, __LINE__,
                         "Query for ComputerSystemProduct information failed. Error code = %x\n", hres);
        pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return 1;
    }
    IWbemClassObject *pclsObj;
    ULONG uReturn = 0;
    int retcode = 1;
    while (pEnumerator)
    {
        hres = pEnumerator->Next(WBEM_INFINITE, 1,  &pclsObj, &uReturn);
        if (0 == uReturn)
        {
            print_error_log( __FILE__, __LINE__,
                             "Query for ComputerSystemProduct information failed.pEnumerator->Next break\n");
            break;
        }

        VARIANT vtProp;
        BSTR  cmbstr(L"00000000-0000-0000-0000-000000000000");
		if(pclsObj==NULL)
		{
            _exit(-1);
		}
		else
		{
			hres = pclsObj->Get(L"UUID", 0, &vtProp, 0, 0);
		}
        int  res = wcscmp(cmbstr, vtProp.bstrVal);

        if (res == 0) // the uuid is not availabe
        {
            print_error_log( __FILE__, __LINE__,  "UUID: is not available\n");
        }
        else
        {
            _bstr_t bstr( vtProp.bstrVal );
            hostid = bstr;
            print_error_log( __FILE__, __LINE__,  "UUID: is  get success \n");
            retcode = 0;
        }
        if (NULL != pclsObj)
        {
            pclsObj->Release();
            pclsObj = NULL;
        }
        VariantClear(&vtProp);
        if ( retcode == 0 )
        {
            break;
        }
    }
    pSvc->Release();
    pLoc->Release();
	if(pEnumerator!=NULL)
	{
		 pEnumerator->Release();
	}
    if ( pclsObj )
    {
        pclsObj->Release();
    }
    CoUninitialize();

    return retcode;   // Program successfully completed.
}
#endif

void print_error_log(char *filename, int  line, const char *fmt, ...)
{
    if ( g_pErrorLogFd == NULL )
    {
        return;
    }

    fprintf(g_pErrorLogFd, "file :%s, at line :%d,  ", filename, line);
    va_list va;
    va_start(va, fmt);
    vfprintf( g_pErrorLogFd, fmt, va);
    fflush( g_pErrorLogFd );
    va_end(va);
}



int getHostID( std::string &hostid )
{
    int retcode = 0;
#if defined _SUN
    long hostval;
    char buffer[MAX_HOST_BUFFER_LEN];
    memset( buffer, 0, MAX_HOST_BUFFER_LEN);
    if ((unsigned int)(hostval = gethostid()) == -1)
    {
        print_error_log( __FILE__, __LINE__, "Sun ERROR : gethostid error, errno :%d\n", errno);
        return  errno;
    }
    snprintf(buffer, MAX_HOST_BUFFER_LEN, "%08lX", (unsigned long)hostval);

    hostid = buffer;

#elif defined _IBM

    struct xutsname hostinfo;
    retcode = unamex( &hostinfo );
    if ( retcode == -1 )
    {
        print_error_log( __FILE__, __LINE__, "AIX ERROR : gethostid error, errno :%d\n", errno);
        return  errno;
    }
    char buffer[MAX_HOST_BUFFER_LEN];
    memset( buffer, 0, MAX_HOST_BUFFER_LEN);
    snprintf( buffer, MAX_HOST_BUFFER_LEN, "%llX",  hostinfo.longnid);
    hostid = buffer;

#elif defined WIN32
    retcode = getuuid(hostid);
    if ( retcode != 0 )
    {
        print_error_log( __FILE__, __LINE__, "Win32 get host uuid error :%d\n", retcode);
        retcode = getMacAddress(hostid);
        if ( retcode != 0)
        {
            print_error_log( __FILE__, __LINE__, "Win32 get host uuid error :%d\n", retcode);
            return 1;
        }
        print_error_log( __FILE__, __LINE__, "Win32 get another uuid success\n");
    }
#elif defined _LINUX

    int fd;
    struct ifreq ifr;
    fd = socket (AF_INET, SOCK_DGRAM, 0);
    if ( fd == -1 )
    {
        print_error_log( __FILE__, __LINE__, "linux ERROR : gethostid error, errno :%d\n", errno);
        return errno;
    }
    ifr.ifr_addr.sa_family = AF_INET;

    strncpy(ifr.ifr_name, "eth0", IFNAMSIZ - 1);
    if ( !ioctl(fd, SIOCGIFHWADDR, &ifr))
    {
        char buffer[MAX_HOST_BUFFER_LEN];
        memset( buffer, 0, MAX_HOST_BUFFER_LEN);
        snprintf(buffer, MAX_HOST_BUFFER_LEN, "%.2x-%.2x-%.2x-%.2x-%.2x-%.2x",
                 (unsigned char)ifr.ifr_hwaddr.sa_data[0],
                 (unsigned char)ifr.ifr_hwaddr.sa_data[1],
                 (unsigned char)ifr.ifr_hwaddr.sa_data[2],
                 (unsigned char)ifr.ifr_hwaddr.sa_data[3],
                 (unsigned char)ifr.ifr_hwaddr.sa_data[4],
                 (unsigned char)ifr.ifr_hwaddr.sa_data[5]);
        hostid = buffer;
    }
    else
    {
        print_error_log( __FILE__, __LINE__, "ERROR : linux get eth0,error :%d\n" , errno);
        char buffer[MAX_HOST_BUFFER_LEN];
        memset( buffer, 0, MAX_HOST_BUFFER_LEN);
        retcode = errno;
        for ( int i = 1; i < 4; i++ )
        {
            memset( ifr.ifr_name, 0, IFNAMSIZ);
            snprintf( ifr.ifr_name, IFNAMSIZ - 1, "eth%d", i );
            if ( !ioctl(fd, SIOCGIFHWADDR, &ifr))
            {
                char buffer[MAX_HOST_BUFFER_LEN];
                memset( buffer, 0, MAX_HOST_BUFFER_LEN);
                snprintf(buffer, MAX_HOST_BUFFER_LEN, "%.2x-%.2x-%.2x-%.2x-%.2x-%.2x",
                         (unsigned char)ifr.ifr_hwaddr.sa_data[0],
                         (unsigned char)ifr.ifr_hwaddr.sa_data[1],
                         (unsigned char)ifr.ifr_hwaddr.sa_data[2],
                         (unsigned char)ifr.ifr_hwaddr.sa_data[3],
                         (unsigned char)ifr.ifr_hwaddr.sa_data[4],
                         (unsigned char)ifr.ifr_hwaddr.sa_data[5]);
                retcode = 0;
                hostid = buffer;
                break;
            }
            else
            {
				print_error_log( __FILE__, __LINE__, "ERROR : linux get eth :%d ,error :%d\n", i , errno);
            }
        }
		memset( buffer, 0, MAX_HOST_BUFFER_LEN);
		retcode = errno;
		for ( int i = 1; i < 4; i++ )
		{
			memset( ifr.ifr_name, 0, IFNAMSIZ);
			snprintf( ifr.ifr_name, IFNAMSIZ - 1, "em%d", i );
			if ( !ioctl(fd, SIOCGIFHWADDR, &ifr))
			{
				char buffer[MAX_HOST_BUFFER_LEN];
				memset( buffer, 0, MAX_HOST_BUFFER_LEN);
				snprintf(buffer, MAX_HOST_BUFFER_LEN, "%.2x-%.2x-%.2x-%.2x-%.2x-%.2x",
					(unsigned char)ifr.ifr_hwaddr.sa_data[0],
					(unsigned char)ifr.ifr_hwaddr.sa_data[1],
					(unsigned char)ifr.ifr_hwaddr.sa_data[2],
					(unsigned char)ifr.ifr_hwaddr.sa_data[3],
					(unsigned char)ifr.ifr_hwaddr.sa_data[4],
					(unsigned char)ifr.ifr_hwaddr.sa_data[5]);
				retcode = 0;
				hostid = buffer;
				break;
			}
			else
			{
				print_error_log( __FILE__, __LINE__, "ERROR : linux get em :%d ,error :%d\n", i , errno);
				retcode = errno;
			}
		}
    }
    close (fd);
#endif
	std::string s1(hostid);
    if ( retcode == 0 )
    {
        //std::reverse( s1.begin(), s1.end() );
        print_error_log(  __FILE__, __LINE__, "origing information is %s \n", s1.c_str() );
    }
	else
	{
		print_error_log(  __FILE__, __LINE__, "the retcode is not zero(%d),information is %s\n", retcode,s1.c_str());
	}
    return retcode;
}


