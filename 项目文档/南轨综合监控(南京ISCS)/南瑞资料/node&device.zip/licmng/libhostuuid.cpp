#include "libhostuuid.h"
#include "base64.h"
#include "gethostid.h"
#include <errno.h>
#include <stdio.h>
extern FILE *g_pErrorLogFd;

CHostUuid::CHostUuid()
    : m_nIsValid(0)
{
}

CHostUuid::~CHostUuid()
{
    closeLogFile();
}

int CHostUuid::openLogFile()
{
    if ( m_nIsValid == 0 )
    {
        g_pErrorLogFd = fopen("uuid.log", "w");
        if ( g_pErrorLogFd == NULL )
        {
            int errCode ;
            errCode = errno;
            printf( "open file is fail, errno : %d\n", errCode );
            return 1;
        }
        m_nIsValid = 1;
    }
    return 0;
}

int CHostUuid::closeLogFile()
{
    if ( m_nIsValid == 1 )
    {
        fclose( g_pErrorLogFd );
        g_pErrorLogFd = NULL;
        m_nIsValid = 0;
    }
    return 0;
}


int CHostUuid::getHostUuid( std::string &hostuuid )
{
    std::string origin_uuid;
    int retcode = getHostID( origin_uuid );
    if (retcode == 0 )
    {
        host_uuid_md5( origin_uuid.c_str(), hostuuid );
        return 0;
    }
    return retcode;
}