#ifndef __SAM_SEND_THREAD_H__
#define __SAM_SEND_THREAD_H__


#include <JTC/JTC.h>
#include <sys/timeb.h>
#include "libpub.h"

class CSamSendThread: public JTCThread
{
public:
    CSamSendThread();
    ~CSamSendThread();
    virtual void run();
};

#endif