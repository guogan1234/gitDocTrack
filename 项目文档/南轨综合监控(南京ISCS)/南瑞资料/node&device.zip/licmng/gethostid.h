#pragma once
#include <string>
enum HostUUidType { _mac_addr, _hostuuid};
int getHostID( std::string &host_id );
void print_error_log(char *filename, int  line, const char *fmt, ...);
