
#ifdef WIN32
#include <Winsock2.h>
#include <Tlhelp32.h>
#elif defined (_SUN)
#include <procfs.h>
#elif defined (_IBM)
#include <sys/proc.h>
#include <procinfo.h>
#include <sys/sysinfo.h>
#else
#include <stdio.h>
#include <sys/types.h>
#include <net/if.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <linux/sockios.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#endif
#include <stdio.h>
#include <string.h>
#include "nodemng_cal.h"
#include "libpub.h"
#include "liblogger.h"
#include "libnodemng.h"
#include "libmsg.h"
#include "Poco/Net/HostEntry.h"
#include "Poco/Net/NetworkInterface.h"
using Poco::Net::NetworkInterface;
using Poco::Net::HostEntry;
#include <set>
#include "Poco/DOM/Text.h"  
#include "Poco/DOM/Element.h"  
#include "Poco/DOM/Comment.h"  
#include "Poco/DOM/ProcessingInstruction.h"  
#include "Poco/DOM/Attr.h"  
#include "Poco/DOM/Document.h"  
#include "Poco/DOM/DOMParser.h"
#include "Poco/DOM/DOMWriter.h"
#include "Poco/DOM/Document.h"
#include "Poco/DOM/Element.h"
#include "Poco/DOM/AutoPtr.h"
#include "Poco/SAX/InputSource.h"
#include "Poco/XML/XMLWriter.h"
#include "Poco/FileStream.h"

using Poco::FileStream;
using Poco::XML::DOMParser;
using Poco::XML::DOMWriter;
using Poco::XML::XMLReader;
using Poco::XML::XMLWriter;
using Poco::XML::Document;
using Poco::XML::AutoPtr;
using Poco::XML::InputSource;

int main(void)
{

    //   char * m_pshm;
    //CShm m_pcshm;

    //while (1)
    //{
    //  CNodeInfo *m_ni;
    //  m_ni =new CNodeInfo();
    //  m_ni->init();
    //  delete m_ni;

    //  CLIENT_SHM* m_pshm = (CLIENT_SHM*)m_pcshm.AttachShm("msg_bus", sizeof(MSG_SHARE_MEM),rt21::SHM_READONLY);
    //  if(m_pshm == NULL)
    //  {
    //      printf("Shm 'msg_bus' can not attach memory in CNodeInfo::init\n");
    //      return -1;
    //  }

    //       log_init("test_2","test_2");
    //CNodeInfo m_ni;
    //vector<int>a;
    //while(1)
    //{
    //  a.clear();
    //  m_ni.init();
    //  m_ni.getDomainID(a);
    //  Sleep(5000);
    //}
    //   CServicesManage sm;
    //  char host_name[64];
    //  int ret = sm.RequestService(1,REQUEST_DUTY,host_name,99);
    //  if (ret<1)
    //  {
    //      printf("------------------error----------------\n");
    //  }
    //  printf("aaaaaaaaaaaaaaa---host_name =%s\n",host_name);
    //  Sleep(2000);
    //}


    //CNodemngCal g_nm_cal;
    //    g_nm_cal.init(true);
    // NM_LOCAL_PACKET_SERVER nm_local_pkt;
    // memset(&nm_local_pkt, 0, sizeof(NM_LOCAL_PACKET_SERVER));
    // nm_local_pkt.head.isValid = htonl(HB_NET_ERROR);
    // g_nm_cal.WriteLocalServer(nm_local_pkt);

    //multiset<int> nums;
    //nums.insert( -242 );
    //nums.insert( -1 );
    //nums.insert( 0 );
    //nums.insert( 8 );
    //nums.insert( 9 );
    //nums.insert( 8 );
    //nums.insert( 11 );
    //pair<multiset<int>::iterator, multiset<int>::iterator> result;
    //int new_val = 8;
    //result = equal_range( nums.begin(), nums.end(), new_val );
    ////cout  << "The first place that " << new_val << " could be inserted is before " << *result.first << ", and the last place that it could be inserted is before " << *result.second << endl;


    //while (result.first != result.second)
    //{
    //    printf("*******************************:%d\n", *result.first);
    //    ++result.first;
    //}
    //if (result.first == result.second)
    //{
    //    printf("---------------continue:%d\n", *result.first);
    //}

	AutoPtr<Poco::XML::Document> pDoc = new Poco::XML::Document;  
	AutoPtr<Poco::XML::Element> myRoot = pDoc->createElement("NODE");  
	AutoPtr<Poco::XML::Element> myChild = pDoc->createElement("SERVER");  
	AutoPtr<Poco::XML::Element> myGrandChild = pDoc->createElement("GrandChild");  
	AutoPtr<Poco::XML::Text> nameNode = pDoc->createTextNode("my_name_is_xiaoqiang");  
	AutoPtr<Poco::XML::ProcessingInstruction> pi = pDoc->createProcessingInstruction("xml","version='1.0' encoding='UTF-8'" );  
	//AutoPtr<Poco::XML::Comment> comm = pDoc->createComment("new_day");  

	myGrandChild->appendChild(nameNode);  
	myChild->appendChild(myGrandChild);  
	myRoot->appendChild(myChild);  
	pDoc->appendChild(pi);  
	//pDoc->appendChild(comm);  
	pDoc->appendChild(myRoot);  

	DOMWriter write;  
	write.setOptions(XMLWriter::PRETTY_PRINT);  
	FileStream ofs("./example.txt",std::ios::in);  
	write.writeNode(ofs,pDoc);  





    return 1;

}
