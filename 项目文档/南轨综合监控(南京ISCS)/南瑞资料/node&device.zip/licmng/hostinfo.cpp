#include "gethostid.h"
#include "base64.h"
#include "rt21_context.h"
#include "rt21_context_sim.h"
#include <stdio.h>
#include <string.h>
#include "libhostuuid.h"
#ifdef WIN32
#include <Winsock2.h>
#endif
#if defined(_SUN) || defined(_IBM)
#include <unistd.h>
#endif
extern FILE *g_pErrorLogFd;

int main( int argc, char **argv)
{
    char hostname[256];
#ifdef WIN32
    WORD wVersionRequested;
    WSADATA wsaData;

    wVersionRequested = MAKEWORD(1, 1);
    WSAStartup(wVersionRequested, &wsaData);
#endif
    gethostname(hostname, 256);
    //��ʼ����ѵ̬
    rt21_context_init(argc, argv);
    if (rt21_context_sim())//��ѵ̬
    {
        argc = argc - 1; //��������֮��ԭ�����еĶ�������Ҫ�䶯
    }
	CHostUuid hid;
	hid.openLogFile();

    std::string hostid;
    //          g_pErrorLogFd = fopen("uuid.log","w");
    //          fprintf( g_pErrorLogFd,"start to get host info ...\n");
    int retcode = getHostID( hostid );
	if (argc==2)
	{
		printf( "origing string (%s)\n",hostid.c_str() );
	}


    if ( retcode == 0 )
    {
        std::string ostr2;
        host_uuid_md5( hostid.c_str(), ostr2);
        printf( "hostname(%s)  id(%s)\n", hostname, ostr2.c_str() );
        //              fprintf(g_pErrorLogFd,"the system uuid is :%s\n", ostr2.c_str() );
    }
    else
    {
        printf( "Can  not get system uuid,check the log\n");
        //              fprintf(g_pErrorLogFd,"Can  not get system uuid,check the log\n");
    }
    //          fprintf( g_pErrorLogFd,"the end\n");
    //          fclose( g_pErrorLogFd );
    return retcode;
}
