/* Sensor: 51300~51399 */
#include "send_thread.h"
#include "libpara.h"
#include "nodemng_cal.h"
CSamSendThread::CSamSendThread()
{

}

CSamSendThread::~CSamSendThread()
{

}

void CSamSendThread::run()
{
    CNodeInfo* ni;
    int i;
//	char *prt21_home = getenv("RT21_HOME");
//	char  text[128]="";
//	char ininame[128] ="";
    for (i = 0; i < 600; i++)
    {
//		if (prt21_home != NULL)
//		{
//#ifdef WIN32
//			sprintf(text, "%s\\var\\log\\rt21.log", prt21_home);
//			sprintf(ininame, "%s\\sys\\server_group.ini", prt21_home);
//#else
//			sprintf(text, "%s/var/log/rt21.log", prt21_home);
//			sprintf(ininame, "%s/sys/server_group.ini", prt21_home);
//#endif
//		}
//		//time_t long_time;
//		//time(&long_time);
//		//struct tm *ptm;
//		//ptm = localtime(&long_time);
//		//char cur_time[256];
//		//sprintf(cur_time, "%4d-%02d-%02d %02d:%02d:%02d", ptm->tm_year + 1900, ptm->tm_mon + 1, ptm->tm_mday, ptm->tm_hour,
//		//	ptm->tm_min, ptm->tm_sec);
//
//		FILE *stream;
//		if ((stream = fopen(text, "r" )) == NULL)
//		{
//			fprintf(stderr, "iniparser: cannot open %s\n", text);
//			//return  ;
//		}
//		FILE * in;
//		if ((in = fopen(ininame, "r")) == NULL)
//		{
//			fprintf(stderr, "iniparser: cannot open %s\n", ininame);
//			//fclose(stream);
//			//return  ;
//		}
//#ifndef WIN32       //sleep 1s
//		usleep(1000 * 1000);
//#else
//		Sleep(1000*10);
//#endif
//		fclose(stream);
//		fclose(in);

#if 1
		CNodemngCal nm_cal;
		if (nm_cal.init(false) < 0)
		{
			printf("exit_______________thread:i=%d\n",i);
			return;
		}
#endif
		#ifndef WIN32       //sleep 1s
				   usleep(1 * 1000);
		#else
				   Sleep(1);
		#endif

#if 1
		ni =new CNodeInfo();
		if (!ni->init())
		{
			printf("---ni->init()---------error----------\n");
			
		}
		delete ni;
#endif

#if 1
		CSysInfo si;
		if (si.Init()<0)
		{
			printf("------si.Init------error----------\n");
		
		}
#endif
		if (i%10==0)
		{
			printf("current thread:i=%d\n",i);
		}

    }
//	CParaManage::VECT_KEY_VALUE app_num_sec;
//	int retval;
//	CParaManage *pm;
//
//   for (int i=0;i<10000;i++)
//   {
//	   pm = CParaManage::CreateObject("server_group.ini");
//	   if (pm == NULL)
//	   {
//		   printf("Get domain info fail file_domain = NULL\n");
//		   //if(!log_printf(LOG_ERROR, 1001, "CNodeInfo::init error: get domain info fail file_domain = NULL"))
//		   return ;
//	   }
//	  CParaManage::RemoveObject(pm);
//
//#ifndef WIN32       //sleep 1s
//		   usleep(20 * 1000);
//#else
//		   Sleep(100);
//#endif
	while(1)
	{
#ifndef WIN32       //sleep 1s
		usleep(1000 * 1000);
#else
		Sleep(1000);
#endif
		printf("I'm alive.................\n");

	}
	return;
}