#include "libuuidcrypt.h"
#include <openssl/aes.h>
#include <openssl/md5.h>
#include <string.h>
#include <stdio.h>

#define MAX_CIPHER_LEN 128


static unsigned char itoa64[] =
    "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";


static char *to64(unsigned long v, int n)
{
    static char buf[5];
    char *s = buf;

    if (n > 4)
    {
        return (NULL);
    }

    memset(buf, '\0', sizeof(buf));
    while (--n >= 0)
    {
        *s++ = itoa64[v & 0x3f];
        v >>= 6;
    }

    return (buf);
}

size_t strlcat(char *dst, const char *src, size_t siz)
{
    register char *d = dst;
    register const char *s = src;
    register size_t n = siz;
    size_t dlen;

    /* Find the end of dst and adjust bytes left but don't go past end */
    while (n-- != 0 && *d != '\0')
    {
        d++;
    }
    dlen = d - dst;
    n = siz - dlen;

    if (n == 0)
    {
        return (dlen + strlen(s));
    }
    while (*s != '\0')
    {
        if (n != 1)
        {
            *d++ = *s;
            n--;
        }
        s++;
    }
    *d = '\0';

    return (dlen + (s - src));  /* count does not include NUL */
}


CUuidCrypt::CUuidCrypt()
{

}

CUuidCrypt::~CUuidCrypt()
{
}

int CUuidCrypt::md5Crypt(const char *magic, const char *salt, std::string &plaintext,
                         std::string &ciphertext)
{
    char passwd[128], *p;
    const char *sp;
    unsigned char final[16];
    int sl, pl, i, j;
    MD5_CTX ctx, ctx1;
    unsigned long l;


    sp = salt;
    sl = strlen(salt);

    MD5_Init(&ctx);
    MD5_Update(&ctx, plaintext.c_str(), plaintext.length() );
    MD5_Update(&ctx, magic, strlen(magic));
    MD5_Update(&ctx, sp, sl);


    MD5_Init(&ctx1);
    MD5_Update(&ctx1, plaintext.c_str(), plaintext.length() );
    MD5_Update(&ctx1, sp, sl);
    MD5_Update(&ctx1, plaintext.c_str(), plaintext.length() );
    MD5_Final(final, &ctx1);

    for (pl = plaintext.length(); pl > 0; pl -= 16)
    {
        MD5_Update(&ctx, final, pl > 16 ? 16 : pl);
    }

    memset(final, '\0', sizeof(final));

    for (j = 0, i = plaintext.length(); i != 0; i >>= 1)
        if (i & 1)
        {
            MD5_Update(&ctx, final + j, 1);
        }
        else
        {
            MD5_Update(&ctx, plaintext.c_str() + j, 1);
        }

    MD5_Final(final, &ctx);

    for  ( i = 0; i < 16; i++ )
    {
        sprintf( passwd + 2 * i, "%02X", final[i]);
    }

    for (i = 0; i < 1000; i++)
    {
        MD5_Init(&ctx1);
        if (i & 1)
        {
            MD5_Update(&ctx1, plaintext.c_str(), plaintext.length());
        }
        else
        {
            MD5_Update(&ctx1, final, 16);
        }

        if (i % 3)
        {
            MD5_Update(&ctx1, sp, sl);
        }

        if (i % 7)
        {
            MD5_Update(&ctx1, plaintext.c_str(), plaintext.length());
        }

        if (i & 1)
        {
            MD5_Update(&ctx1, final, 16);
        }
        else
        {
            MD5_Update(&ctx1, plaintext.c_str(), plaintext.length());
        }

        MD5_Final(final, &ctx1);
    }

    p = passwd + strlen(passwd);

    l = (final[ 0] << 16) | (final[ 6] << 8) | final[12];
    strlcat(passwd, to64(l, 4), sizeof(passwd));
    l = (final[ 1] << 16) | (final[ 7] << 8) | final[13];
    strlcat(passwd, to64(l, 4), sizeof(passwd));
    l = (final[ 2] << 16) | (final[ 8] << 8) | final[14];
    strlcat(passwd, to64(l, 4), sizeof(passwd));
    l = (final[ 3] << 16) | (final[ 9] << 8) | final[15];
    strlcat(passwd, to64(l, 4), sizeof(passwd));
    l = (final[ 4] << 16) | (final[10] << 8) | final[ 5];
    strlcat(passwd, to64(l, 4), sizeof(passwd));
    l =  final[11]  ;
    strlcat(passwd, to64(l, 2), sizeof(passwd));

    memset(final, 0, sizeof(final));
    memset(&ctx, 0, sizeof(ctx));
    memset(&ctx1, 0, sizeof(ctx1));
    (void)to64(0, 4);

    ciphertext = passwd;
    return 0;
}